/* LoosenUp - 2-minute guided calm breaks. Data stays on this device (localStorage). */
(function () {
  'use strict';

  var VERSION = '2.9.0';
  var KEY = 'loosenup.v1';
  // One home for the website, the mobile website and every app download.
  var PUBLIC_URL = 'https://loosenup.anchit-tandon.com';
  var GET_URL = PUBLIC_URL + '/get';
  var ANDROID_URL = GET_URL;
  var IOS_URL = GET_URL;
  var WEEKLY_FREE_SEEDS = 2;
  var DAILY_NUDGES = 2;
  var MILESTONES = [3, 7, 21, 30];
  var GAME_XP = 5;
  var DAILY_GAME_REWARDS = 3;

  // Every helpline number comes from www/helplines.js (one source, checked by a unit test).
  var HL = window.LoosenUpHelplines || {
    telemanas: { tel: 'tel:14416' }, vandrevala: { tel: 'tel:+919999666555', whatsapp: 'https://wa.me/919999666555' },
    icall: { tel: 'tel:9152987821', email: 'icall@tiss.edu' }, emergency: { tel: 'tel:112' }, elsewhere: 'https://findahelpline.com',
    safetyPlanText: 'Tele-MANAS 14416 (24x7, free)\nVandrevala Foundation +91 9999 666 555 (24x7, call or WhatsApp)\niCall 9152987821 (Mon to Sat, 8am to 9pm)\nEmergency 112'
  };
  function helplineHref(path) {
    var p = path.split('.'), v = HL[p[0]];
    if (p[1] === 'mailto') return v && v.email ? 'mailto:' + v.email : null;
    if (p[1]) v = v && v[p[1]];
    return typeof v === 'string' ? v : null;
  }
  function applyHelplines() {
    var els = document.querySelectorAll('[data-hl]');
    for (var i = 0; i < els.length; i++) { var h = helplineHref(els[i].getAttribute('data-hl')); if (h) els[i].setAttribute('href', h); }
  }

  var TEST = window.__LOOSENUP_TEST__ || {};
  var nowOverride = TEST.now ? new Date(TEST.now) : null;
  var rng = TEST.rng || Math.random;
  function now() { return nowOverride ? new Date(nowOverride.getTime()) : new Date(); }

  /* ---------- Content ---------- */

  var TECH = {
    sigh: {
      id: 'sigh', name: 'Sigh of relief', seconds: 120, unlockAt: 0, color: '#FFB088', kind: 'breath',
      desc: 'Two easy breaths in through the nose, then one long, slow breath out.',
      pattern: [['Breathe in', 2, 1], ['A little more', 1, 1.08], ['Long breath out', 6, 0.6]]
    },
    breeze: {
      id: 'breeze', name: 'Slow breeze', seconds: 120, unlockAt: 0, color: '#8CC8F0', kind: 'breath',
      desc: 'Soft, even breathing. In for five, out for five, like a slow breeze.',
      pattern: [['Breathe in', 5, 1], ['Breathe out', 5, 0.6]]
    },
    here: {
      id: 'here', name: 'Here and now', seconds: 120, unlockAt: 0, color: '#4FA67C', kind: 'steps',
      desc: 'Gently notice the world around you, one sense at a time.',
      steps: ['Look around and name 5 things you can see.', 'Notice 4 things you can feel, like your feet or your sleeves.',
        'Listen for 3 sounds, near or far.', 'Find 2 things you can smell, or 2 favourite scents.', 'Notice 1 taste, or take a sip of water.']
    },
    release: {
      id: 'release', name: 'Soft release', seconds: 120, unlockAt: 0, color: '#C9A7F2', kind: 'steps',
      desc: 'Tense each area for a breath, then let it go soft, from shoulders to toes.',
      steps: ['Lift your shoulders up to your ears. Hold. Let them drop.', 'Make two fists. Squeeze. Open your hands wide and soft.',
        'Scrunch your face. Then let your jaw hang loose.', 'Press your feet into the floor. Then let them rest.', 'Take one long breath and feel your whole body settle.']
    },
    letitout: {
      id: 'letitout', name: 'Let it out', seconds: 120, unlockAt: 0, color: '#FFC857', kind: 'journal',
      desc: 'Two minutes to type whatever is on your mind. Nothing is saved.'
    },
    kind: {
      id: 'kind', name: 'Kind words', seconds: 120, unlockAt: 0, color: '#F28FA0', kind: 'steps', space: 'lowdays',
      desc: 'A gentle self-compassion break for when your inner voice feels harsh.',
      steps: ['Place a hand on your heart or your cheek. Feel its warmth.', 'Name it softly: this is a hard moment.',
        'Remember: everyone has hard moments. You are not alone in this.', 'Say to yourself: may I be kind to myself right now.',
        'Ask: what would I say to a dear friend who felt this way? Say it to you.']
    },
    desk: {
      id: 'desk', name: 'Desk reset', seconds: 120, unlockAt: 0, color: '#8CC8F0', kind: 'steps', space: 'work',
      desc: 'Release the workday from your body without leaving your chair.',
      steps: ['Roll your shoulders back slowly, five times.', 'Tilt one ear toward your shoulder, then the other.',
        'Press your palms together for a breath, then let them go soft.', 'Look at something far away for twenty seconds.',
        'Sit tall, feet flat, and take one long breath out.']
    },
    square: {
      id: 'square', name: 'Steady square', seconds: 120, unlockAt: 0, color: '#6FB3E0', kind: 'breath', space: 'work',
      desc: 'Box breathing: in for four, hold for four, out for four, rest for four.',
      pattern: [['Breathe in', 4, 1], ['Hold gently', 4, 1], ['Breathe out', 4, 0.6], ['Rest', 4, 0.6]]
    },
    pause: {
      id: 'pause', name: 'Pause before replying', seconds: 120, unlockAt: 0, color: '#FFB088', kind: 'steps', space: 'relationships',
      desc: 'A few calm steps so you can answer from care, not from heat.',
      steps: ['Take one slow breath before you say anything.', 'Name the feeling in one word.', 'Ask yourself: what do I need right now?',
        'Ask: what might they be feeling?', 'Choose one kind, honest sentence to begin with.']
    },
    cooldown: {
      id: 'cooldown', name: 'Cool down', seconds: 120, unlockAt: 0, color: '#9ED3C4', kind: 'breath', space: 'relationships',
      desc: 'Long breaths out that help your body settle after a disagreement.',
      pattern: [['Breathe in', 4, 1], ['Long breath out', 7, 0.6]]
    },
    warmth: {
      id: 'warmth', name: 'Warm wishes', seconds: 120, unlockAt: 0, color: '#F7C59F', kind: 'steps', space: 'relationships',
      desc: 'Send kind wishes to someone you love, someone you feel tense with, and yourself.',
      steps: ['Picture someone you care about and smile at them in your mind.', 'Wish them: may you feel safe and at ease.',
        'Now picture the person you feel tense with.', 'Wish them: may you find some ease too.', 'Wish yourself the same: may I feel at ease.']
    },
    // Feeling-led exercises (see www/feelings.js): each one fits a step in a feeling's plan.
    wave: {
      id: 'wave', name: 'Gentle wave', seconds: 120, unlockAt: 0, color: '#B8C7DA', kind: 'breath',
      desc: 'Very slow breaths with a hand on your heart. It is okay to cry.',
      pattern: [['Breathe in', 4, 1], ['Slow breath out', 8, 0.6]]
    },
    name: {
      id: 'name', name: 'Name it', seconds: 120, unlockAt: 0, color: '#9DB4D6', kind: 'steps',
      desc: 'Put the feeling into a word or two, and notice where it sits in your body.',
      steps: ['Say the feeling in a word or two, softly, like: this is worry.', 'Notice where you feel it: chest, throat, stomach or shoulders.',
        'Give it a size from 1 to 10. No need to change it.', 'Tell yourself: it makes sense that I feel this way.', 'Take one long breath out and let the words rest.']
    },
    park: {
      id: 'park', name: 'Park the worry', seconds: 120, unlockAt: 0, color: '#6FB3E0', kind: 'steps',
      desc: 'Write the worry down, choose one next step or a time to come back to it, and let it wait.',
      steps: ['Write the worry in a few words, on paper or in your notes.', 'Ask: is there something I can do about it today?',
        'If yes, choose one small first step and when you will do it.', 'If not today, pick a time to think about it, like 6 pm, and let it wait there.',
        'Breathe out slowly. It is written down, so your mind can put it down too.']
    },
    tomorrow: {
      id: 'tomorrow', name: 'Tomorrow list', seconds: 120, unlockAt: 0, color: '#8CA9F0', kind: 'steps', space: 'sleep',
      desc: 'Write down what tomorrow needs, so your mind can rest tonight.',
      steps: ['Write down what tomorrow needs, one short line each.', 'Put a star by the one thing to start with.',
        'Tell yourself: it is written down, and it can wait until morning.', 'Dim your screen and let your breathing slow down.',
        'With each breath out, let your face, jaw and shoulders go soft.']
    },
    shake: {
      id: 'shake', name: 'Shake it out', seconds: 120, unlockAt: 0, color: '#FFB088', kind: 'steps',
      desc: 'Give restless energy somewhere to go, then let your body settle.',
      steps: ['Shake out your hands loosely for ten seconds.', 'Roll your shoulders, big and slow, five times.',
        'Press your palms together firmly for five seconds, then let go.', 'Let your arms hang heavy by your sides.',
        'Now three long breaths out, each one slower than the last.']
    },
    friend: {
      id: 'friend', name: 'Kind friend voice', seconds: 120, unlockAt: 0, color: '#F28FA0', kind: 'steps', space: 'lowdays',
      desc: 'Look at the facts, then talk to yourself the way a good friend would.',
      steps: ['Notice the harsh words, and start them with: I notice I am telling myself.', 'Ask: what exactly happened? Name only the facts.',
        'Say your own name, then: this was hard, and you are doing your best.', 'Ask what a good friend would say to you right now, and say it to yourself.',
        'Put a hand on your heart and breathe out slowly.']
    },
    reach: {
      id: 'reach', name: 'Reach out', seconds: 120, unlockAt: 0, color: '#F7C59F', kind: 'steps', space: 'relationships',
      desc: 'Think of one person who is kind to you, and send them a small hello.',
      steps: ['Think of one person who was kind to you this month.', 'Picture their face for a breath.',
        'Send something small, like: saw this and thought of you. Or just hello.', 'If no one comes to mind, remember: many people feel this way right now.',
        'Breathe out. You took a step toward someone.']
    },
    lift: {
      id: 'lift', name: 'Gentle lift', seconds: 120, unlockAt: 0, color: '#FFC857', kind: 'steps',
      desc: 'A little movement, daylight and water to wake the body gently.',
      steps: ['Stand up slowly, or sit tall.', 'Go to a window or step outside for some daylight.',
        'Stretch your arms up high as you breathe in, and let them float down.', 'Walk a few steps, or march gently on the spot for twenty seconds.',
        'Have a few sips of water.']
    },
    savour: {
      id: 'savour', name: 'Savour it', seconds: 120, unlockAt: 0, color: '#FFD27A', kind: 'steps',
      desc: 'Stay with a good feeling a little longer, so it is easier to find again.',
      steps: ['Say what feels good right now, in one sentence.', 'Notice where you feel it: a warm chest, easy shoulders, a smile.',
        'Look around and take a picture of this moment in your mind.', 'Ask: what helped me get here? Remember it for another day.',
        'Think of someone who would be glad for you.']
    },
    hope: {
      id: 'hope', name: 'Hope and a first step', seconds: 120, unlockAt: 0, color: '#8CC8F0', kind: 'steps',
      desc: 'Picture it going well, plan for one bump, and choose one small first step.',
      steps: ['Picture it going well. What do you see?', 'Name the best part of that picture.', 'Name one thing that might get in the way.',
        'Choose one small step that helps, and when you will take it.', 'Picture the good part once more, and smile at it.']
    },
    // For a sudden rush of panic: steady the breath, feel the ground, cool down, and wait for the wave to pass.
    panic: {
      id: 'panic', name: 'Ride the wave', seconds: 120, unlockAt: 0, color: '#6FB3E0', kind: 'steps',
      desc: 'For a sudden rush of panic. It feels huge, and it passes. Stay with these five steps.',
      steps: ['This is a wave of panic. It feels huge, and it rises, peaks and passes. You do not have to fight it.',
        'Breathe out slowly, longer than you breathe in. In for four, out for six.',
        'Press your feet into the floor. Name five things you can see, slowly, one by one.',
        'Hold something cold, or splash cool water on your face if you can.',
        'Hand on your chest. Say to yourself: I am safe right now. This will pass.']
    },
    // More to try: breathing from Indian practice, rest for screen-tired eyes, a slow cup and a morning stretch.
    hum: {
      id: 'hum', name: 'Humming breath', seconds: 120, unlockAt: 0, color: '#B9A3F0', kind: 'breath',
      desc: 'Bhramari: breathe in, then hum softly all the way out, like a bee. A gentle way to quieten a busy head.',
      pattern: [['Breathe in', 4, 1], ['Hum softly out', 7, 0.6]]
    },
    nadi: {
      id: 'nadi', name: 'Alternate breath', seconds: 120, unlockAt: 0, color: '#9ED3C4', kind: 'breath',
      desc: 'Nadi shodhana: breathe in one side of the nose and out the other, slowly, in turns.',
      pattern: [['In through the left', 4, 1], ['Out through the right', 6, 0.6], ['In through the right', 4, 1], ['Out through the left', 6, 0.6]]
    },
    night: {
      id: 'night', name: 'Night breath', seconds: 120, unlockAt: 0, color: '#8CA9F0', kind: 'breath', space: 'sleep',
      desc: 'In for four, a soft hold for seven, out for eight. Slow and sleepy.',
      pattern: [['Breathe in', 4, 1], ['Hold softly', 7, 1], ['Breathe out', 8, 0.6]]
    },
    eyes: {
      id: 'eyes', name: 'Eye rest', seconds: 120, unlockAt: 0, color: '#6FB3E0', kind: 'steps', space: 'work',
      desc: 'Two minutes away from the screen for tired eyes: warm palms, far looks and slow blinks.',
      steps: ['Rub your palms together until they feel warm.', 'Cup them gently over your closed eyes. Rest in the dark for a few breaths.',
        'Open your eyes and look at something far away.', 'Blink slowly ten times, like waking up.', 'Look up, down, left and right, slowly, then close your eyes for one breath.']
    },
    chai: {
      id: 'chai', name: 'Mindful chai', seconds: 120, unlockAt: 0, color: '#D9A066', kind: 'steps',
      desc: 'Turn your next cup of chai, coffee or water into two calm minutes.',
      steps: ['Hold the cup in both hands. Feel its warmth.', 'Breathe in the smell. Notice what you can pick out.',
        'Take one small sip and let it rest on your tongue.', 'Swallow slowly and feel the warmth move down.', 'Take the next sips without your phone, just the cup and you.']
    },
    stretch: {
      id: 'stretch', name: 'Morning stretch', seconds: 120, unlockAt: 0, color: '#FFC857', kind: 'steps',
      desc: 'Wake your body gently: reach, fold, twist and roll, at your own pace.',
      steps: ['Reach both arms up high and stretch tall.', 'Let your arms float down and fold forward softly, knees loose.',
        'Come up slowly and twist gently to the left, then the right.', 'Roll your neck in slow half circles.', 'Stand tall, hands on your belly, and take three deep breaths.']
    },
    quick: {
      id: 'quick', name: 'Quick breeze', seconds: 60, unlockAt: 0, color: '#CFE8FF', kind: 'breath', free: true,
      desc: 'Sixty seconds of slow, easy breathing. Always free.',
      pattern: [['Breathe in', 4, 1], ['Breathe out', 6, 0.6]]
    }
  };
  var INTRO = {
    breath: 'Let us begin. Sit comfortably, let your shoulders drop, and follow the sun as it opens and closes.',
    steps: 'Let us begin. Take your time with each step. There is no rush.',
    journal: 'Let us begin. Type whatever is on your mind. Nothing is saved.'
  };
  var OUTRO = 'Lovely. Take a moment to notice how you feel now.';
  var CHOOSABLE = ['sigh', 'breeze', 'here', 'release', 'letitout', 'kind', 'desk', 'square', 'pause', 'cooldown', 'warmth'];

  // Spaces group feelings by what people are carrying: everyday, work, relationships, low days and sleep.
  var SPACES = {
    everyday: { name: 'Everyday', contexts: ['Feeling anxious', 'Busy mind', 'Tight shoulders', 'Big moment ahead', 'Hard to focus', 'Just a quick lift'] },
    work: { name: 'Work', contexts: ['Work pile-up', 'Before a meeting', 'After a tough call', 'Hard to switch off'] },
    relationships: { name: 'Relationships', contexts: ['Tense with someone', 'After a disagreement', 'Before a hard talk', 'Feeling disconnected'] },
    lowdays: { name: 'Low days', contexts: ['Feeling low', 'Low energy', 'Hard on myself'] },
    sleep: { name: 'Sleep', contexts: ['Winding down', 'Mind racing at night'] }
  };
  var SPACE_ORDER = ['everyday', 'work', 'relationships', 'lowdays', 'sleep'];
  var CONTEXTS = [];
  SPACE_ORDER.forEach(function (k) { CONTEXTS = CONTEXTS.concat(SPACES[k].contexts); });
  function spaceOf(context) {
    for (var i = 0; i < SPACE_ORDER.length; i++) if (SPACES[SPACE_ORDER[i]].contexts.indexOf(context) !== -1) return SPACE_ORDER[i];
    return 'everyday';
  }
  var RULES = {
    'Feeling anxious': [['sigh', 'A long, slow breath out is one of the quickest ways to tell an anxious body it can settle.'],
      ['here', 'Noticing what is around you, one sense at a time, brings an anxious mind back to now.']],
    'Busy mind': [['letitout', 'Putting thoughts into words can make a busy mind feel roomier.'],
      ['here', 'Noticing what is around you gently brings a busy mind back to now.']],
    'Tight shoulders': [['release', 'Tensing and softening helps shoulders let go.'],
      ['sigh', 'A long breath out is a quick way to soften tight shoulders.']],
    'Big moment ahead': [['sigh', 'A couple of long breaths out can help you feel steady before a big moment.']],
    'Hard to focus': [['breeze', 'Slow, even breathing gives your attention a calm rhythm to follow.']],
    'Winding down': [['release', 'Letting each muscle go soft is a lovely way to wind down.'],
      ['breeze', 'Slow breathing is a gentle way to wind down.']],
    'Just a quick lift': [['sigh', 'A Sigh of relief is the quickest lift we know.']],
    'Work pile-up': [['square', 'A steady square breath helps you take one thing at a time.']],
    'Before a meeting': [['square', 'Four calm counts in, hold, out and rest help you walk in steady.']],
    'After a tough call': [['desk', 'A quick desk reset helps your body let go of the last call.']],
    'Hard to switch off': [['release', 'Softening each muscle tells your body the workday is done.'],
      ['breeze', 'Slow breathing helps you move from work mode to you mode.']],
    'Tense with someone': [['pause', 'A pause before replying helps you answer from calm.']],
    'After a disagreement': [['cooldown', 'Long breaths out help your body settle after a disagreement.']],
    'Before a hard talk': [['square', 'Steady breaths help you begin a hard talk feeling grounded.']],
    'Feeling disconnected': [['warmth', 'Sending warm wishes can help you feel closer to the people you care about.']],
    'Feeling low': [['kind', 'Kind words to yourself can soften a heavy day.']],
    'Low energy': [['here', 'Gently noticing the world around you can bring a small lift.']],
    'Hard on myself': [['kind', 'Speak to yourself the way you would speak to a dear friend.']],
    'Mind racing at night': [['letitout', 'Putting thoughts on the page can help a racing mind settle.'],
      ['release', 'Softening the body can help a racing mind slow down.'],
      ['breeze', 'Slow breathing helps a racing mind ease toward sleep.']]
  };

  var MOODS = [null, 'Crying', 'Sad', 'Okay', 'Decent', 'Happy'];
  var MOOD_NOTES = [null,
    'Thank you for being honest. It is okay to cry. Kind words or a Small step are here for you, and so is SOS.',
    'Sad days happen. Kind words or a Small step can help a little.',
    'Okay is okay. A Small step could add a little lift.',
    'A decent day. A calm break can keep the good going.',
    'Happy today. Lovely! Maybe share LoosenUp with someone who could use it.'];
  var STEPS = ['Step outside or by a window for two minutes of daylight.', 'Drink a full glass of water, slowly.',
    'Stretch your arms up high, then let them float down.', 'Send a short hello to someone you trust.',
    'Tidy one small thing near you.', 'Play one song you love and let yourself enjoy it.',
    'Wash your face or hands with cool water.', 'Eat something nourishing, even something small.',
    'Open a window and take three easy breaths.', 'Walk to the end of the street and back.',
    'Write one kind line to tomorrow you.', 'Water a plant, or look at something green for a minute.',
    'Change into something comfortable.', 'Give yourself a small smile in the mirror.'];
  var LIFT_XP_PER_DAY = 3;


  // Milestones, in plain words. Ids stay stable so saved progress keeps working.
  var BADGES = {
    first: ['First break', 'Your first calm break'],
    streak3: ['3 calm days', 'Three days with a calm break'],
    streak7: ['7 calm days', 'Seven days with a calm break'],
    streak21: ['21 calm days', 'Twenty one days: a real habit'],
    streak30: ['30 calm days', 'Thirty days with a calm break'],
    goal: ['Weekly goal', 'Met your weekly goal'],
    ten: ['Ten breaks', 'Ten calm breaks taken'],
    bigLift: ['Big lift', 'A Calm gain of +5 or more'],
    explorer: ['Explorer', 'Tried every exercise'],
    sharer: ['Shared LoosenUp', 'Shared LoosenUp with someone'],
    golden: ['Daily reminder', 'Set a daily reminder'],
    playful: ['Playful', 'Played a calm game'],
    programme: ['Finisher', 'Finished a guided programme'],
    daily7: ['Seven days of play', 'Played today\'s game on seven days'],
    collector: ['Game shelf', 'Played every calm game']
  };

  var NOTES = [
    'Two minutes for you is never small.',
    'Your calm is a skill, and you just practised it.',
    'However today goes, you made a little room for yourself.',
    'Small breaks add up to steadier days.',
    'You gave your mind a soft place to land.',
    'Every break plants something good.'
  ];


  var CRISIS = [
    /suicid/i, /\bkill(ing)?\s+my\s*self\b/i, /\bend(ing)?\s+it\s+all\b/i, /\bend(ing)?\s+my\s+life\b/i,
    /\bself[\s-]?harm/i, /\bwant(ed)?\s+to\s+die\b/i, /\bwanna\s+die\b/i, /\bhurt(ing)?\s+my\s*self\b/i,
    /\bharm(ing)?\s+my\s*self\b/i, /\bno\s+reason\s+to\s+live\b/i, /\bbetter\s+off\s+dead\b/i,
    /\b(do\s*n[o']?t|dont)\s+want\s+to\s+(live|be\s+alive|be\s+here)\b/i, /\btake\s+my\s+(own\s+)?life\b/i,
    /\bnot\s+worth\s+living\b/i, /\bcut(ting)?\s+my\s*self\b/i
  ];
  function isCrisis(text) {
    var t = String(text || '');
    for (var i = 0; i < CRISIS.length; i++) if (CRISIS[i].test(t)) return true;
    var hi = (window.LoosenUpI18n && window.LoosenUpI18n.crisis) || [];
    for (var j = 0; j < hi.length; j++) if (hi[j].test(t)) return true;
    return false;
  }

  /* ---------- Dates ---------- */

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayKey(d) { d = new Date(d); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function dayNum(key) { var p = key.split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]) / 86400000; }
  function daysBetween(a, b) { return dayNum(b) - dayNum(a); }
  function weekKey(d) {
    d = new Date(d);
    var t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    var wd = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - wd);
    var y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    var wk = Math.ceil(((t - y0) / 86400000 + 1) / 7);
    return t.getUTCFullYear() + '-W' + pad(wk);
  }
  function bucketOf(ts) {
    var h = new Date(ts).getHours();
    if (h >= 5 && h < 12) return 'Mornings';
    if (h >= 12 && h < 17) return 'Afternoons';
    if (h >= 17 && h < 22) return 'Evenings';
    return 'Quiet nights';
  }

  /* ---------- State ---------- */

  function freshState() {
    return {
      v: 1, name: '', createdAt: null, onboarded: false, seeds: 0, xp: 0, plan: 'free',
      sessions: [], streak: { count: 0, lastDay: null, best: 0 }, rainDayWeek: null,
      rewardSeeds: { week: null, count: 0 }, milestones: [], sunbeamDay: null, referralDay: null,
      nudges: { day: null, count: 0, shown: [] }, goldenHour: null, voice: false, badges: [], purchases: [],
      games: { day: null, count: 0 }, gameBest: { pairs: null, catch: 0, bloom: 0 }, gamePlays: {}, gameLevel: {}, daily: { day: null, days: 0 },
      moods: [], smallSteps: [], goodThings: [], trusted: null, sosLocation: false, jarXp: { day: null, count: 0 },
      careTeam: null, safetyPlan: null, wellbeing: [], toolXp: { day: null, count: 0 }, reframes: 0, theme: 'auto', lang: 'en', programs: {}, org: null, emotions: [], safetyAskedDay: null, lessonsDone: [], chime: true, bed: 'none',
      lengthMin: 2, weeklyGoal: 3, hapticBreath: false, textSize: 'normal', journal: [], sleepAfter: 15, plus: null, payConfig: null,
      lock: { enabled: false, salt: '', hash: '', bio: false }
    };
  }
  function load() {
    var s = freshState();
    try {
      // Carry progress over from the app's earlier names.
      var raw = window.localStorage.getItem(KEY) || window.localStorage.getItem('lightenup.v1') || window.localStorage.getItem('sunpetal.v1') || window.localStorage.getItem('brightside.v1');
      if (raw) {
        var p = JSON.parse(raw);
        for (var k in p) if (Object.prototype.hasOwnProperty.call(s, k)) s[k] = p[k];
      }
    } catch (e) { /* storage unavailable: start fresh in memory */ }
    // The old demo checkout never charged anyone, so it never grants Plus.
    if (s.plan === 'fullbloom') s.plan = 'free';
    return s;
  }
  var state = load();
  function save() {
    try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* private mode */ }
  }

  /* ---------- Engine ---------- */

  function breaksDone() { return state.sessions.length; }
  function isUnlocked(id) { return breaksDone() >= (TECH[id] ? TECH[id].unlockAt : 0); }

  function recommend(context) {
    var ctx = RULES[context] ? context : 'Just a quick lift';
    var stats = {};
    state.sessions.forEach(function (s) {
      var ctxs = s.contexts || [s.context];
      if (ctxs.indexOf(ctx) === -1 || !TECH[s.technique] || s.technique === 'quick' || !isRated(s)) return;
      var st = stats[s.technique] || (stats[s.technique] = { n: 0, sum: 0 });
      st.n++; st.sum += s.gain;
    });
    var best = null;
    CHOOSABLE.forEach(function (id) {
      var st = stats[id];
      if (!st || st.n < 2 || !isUnlocked(id)) return;
      var avg = st.sum / st.n;
      if (!best || avg > best.avg) best = { id: id, avg: avg };
    });
    if (best) {
      var a = (best.avg >= 0 ? '+' : '') + best.avg.toFixed(1);
      return { id: best.id, name: TECH[best.id].name, learned: true,
        reason: 'Picked from your own breaks: ' + TECH[best.id].name + ' averages ' + a + ' Calm gain for "' + ctx + '".' };
    }
    var rules = RULES[ctx];
    for (var i = 0; i < rules.length; i++) {
      if (isUnlocked(rules[i][0])) return { id: rules[i][0], name: TECH[rules[i][0]].name, reason: rules[i][1], learned: false };
    }
    return { id: 'breeze', name: TECH.breeze.name, reason: RULES['Hard to focus'][0][1], learned: false };
  }

  function joinNames(list) {
    if (list.length <= 1) return list.join('');
    return list.slice(0, -1).join(', ') + ' and ' + list[list.length - 1];
  }
  function recommendFor(contexts) {
    var list = (contexts || []).filter(Boolean);
    if (list.length <= 1) return recommend(list[0]);
    var recs = list.map(recommend);
    var tally = {};
    recs.forEach(function (r) { tally[r.id] = (tally[r.id] || 0) + (r.learned ? 1.5 : 1); });
    var best = recs[0];
    recs.forEach(function (r) { if (tally[r.id] > tally[best.id]) best = r; });
    var covers = list.filter(function (c, i) { return recs[i].id === best.id; });
    return { id: best.id, name: best.name, learned: best.learned,
      reason: best.reason + ' Picked for ' + joinNames(list) + (covers.length < list.length ? ', and it suits ' + joinNames(covers) + ' best.' : '.') };
  }

  function addBadge(id, list) {
    if (state.badges.indexOf(id) === -1) { state.badges.push(id); if (list) list.push(id); }
  }

  function completeSession(input) {
    var d = now();
    var dk = dayKey(d);
    // The before rating is optional (Breathe now asks for it in one tap at the end). Without it,
    // the break still counts, but it has no Calm gain and stays out of every average.
    var rated = input.before != null && input.before !== '';
    var after = clampScore(input.after);
    var before = rated ? clampScore(input.before) : null;
    var gain = rated ? after - before : null;
    var r = { gain: gain, shownGain: rated ? Math.max(0, gain) : 0, rated: rated, before: before, after: after, rainDayUsed: false, freshRun: false,
      milestone: null, newBadges: [], unlocked: [] };

    var goalBefore = weekGoal();
    var ctxList = (input.contexts && input.contexts.length ? input.contexts : [input.context || 'Just a quick lift']).slice(0, 8);
    state.sessions.push({ ts: d.getTime(), day: dk, technique: input.technique, context: ctxList[0], contexts: ctxList,
      before: before, after: after, gain: gain });

    // Day streak: once per calendar day; one rest day a week keeps it going.
    var st = state.streak;
    if (st.lastDay !== dk) {
      var gap = st.lastDay ? daysBetween(st.lastDay, dk) : null;
      if (gap === 1) st.count++;
      else if (gap === 2 && state.rainDayWeek !== weekKey(d)) { st.count++; state.rainDayWeek = weekKey(d); r.rainDayUsed = true; }
      else { r.freshRun = st.lastDay !== null; st.count = 1; }
      st.lastDay = dk;
      st.best = Math.max(st.best || 0, st.count);
      if (MILESTONES.indexOf(st.count) !== -1 && state.milestones.indexOf(st.count) === -1) {
        state.milestones.push(st.count);
        r.milestone = st.count;
      }
    }

    var goalAfter = weekGoal();
    r.goalMet = goalBefore.days < goalBefore.goal && goalAfter.days >= goalAfter.goal;
    addBadge('first', r.newBadges);
    // Milestones count calm days in total, never days in a row, so a quiet day never resets anything.
    var calmDays = {};
    state.sessions.forEach(function (x) { calmDays[x.day] = true; });
    var nDays = Object.keys(calmDays).length;
    if (nDays >= 3) addBadge('streak3', r.newBadges);
    if (nDays >= 7) addBadge('streak7', r.newBadges);
    if (nDays >= 21) addBadge('streak21', r.newBadges);
    if (nDays >= 30) addBadge('streak30', r.newBadges);
    if (r.goalMet) addBadge('goal', r.newBadges);
    if (breaksDone() >= 10) addBadge('ten', r.newBadges);
    if (rated && gain >= 5) addBadge('bigLift', r.newBadges);
    var tried = {};
    state.sessions.forEach(function (x) { tried[x.technique] = true; });
    if (CHOOSABLE.every(function (id) { return tried[id]; })) addBadge('explorer', r.newBadges);

    save();
    return r;
  }

  function isRated(s) { return typeof s.gain === 'number'; }
  function ratedOnly(list) { return list.filter(isRated); }
  function avgGain(list) {
    var r = ratedOnly(list);
    return r.length ? Math.round(10 * r.reduce(function (a, x) { return a + Math.max(0, x.gain); }, 0) / r.length) / 10 : 0;
  }
  function clampScore(v) { v = Math.round(Number(v)); return isNaN(v) ? 5 : Math.max(1, Math.min(10, v)); }

  // Every calm break is free, always.
  function canStart(id) { return !!TECH[id]; }

  function nudgeAllowed(type) {
    var dk = dayKey(now());
    if (state.nudges.day !== dk) state.nudges = { day: dk, count: 0, shown: [] };
    if (state.nudges.shown.indexOf(type) !== -1) return true;
    if (state.nudges.count >= DAILY_NUDGES) return false;
    state.nudges.shown.push(type);
    state.nudges.count++;
    save();
    return true;
  }

  /* ---------- DOM helpers ---------- */

  var $ = function (id) { return document.getElementById(id); };
  function setText(id, t) { var el = $(id); if (el) { el.textContent = t; if (isHindi()) translateDom(el); } }
  function mm(q) { try { return !!(window.matchMedia && window.matchMedia(q).matches); } catch (e) { return false; } }
  function prefersReducedMotion() { return mm('(prefers-reduced-motion: reduce)'); }
  function isNative() { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : many); }
  function signed(n) { return (n >= 0 ? '+' : '') + n; }
  var SVGNS = 'http://www.w3.org/2000/svg';
  function svg(tag, attrs, parent) {
    var el = document.createElementNS(SVGNS, tag);
    for (var k in attrs) el.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(el);
    return el;
  }

  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.textContent = tr(msg);
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 2800);
  }

  /* ---------- Navigation ---------- */

  var current = null;
  var TABS = ['today', 'play', 'progress', 'me'];
  var flow = { mode: 'guided', before: 5, context: null, technique: null };

  var lastTab = 'today';
  function go(name) {
    if (name === 'sounds') { calmSeg = 'sounds'; name = 'play'; }
    if (name !== 'game') stopGame();
    if (TABS.indexOf(name) !== -1) lastTab = name;
    var screens = document.querySelectorAll('.screen');
    for (var i = 0; i < screens.length; i++) screens[i].hidden = screens[i].getAttribute('data-screen') !== name;
    current = name;
    var isTab = TABS.indexOf(name) !== -1;
    $('tabbar').hidden = !isTab;
    var tabs = document.querySelectorAll('[data-tab]');
    for (var j = 0; j < tabs.length; j++) tabs[j].setAttribute('aria-selected', String(tabs[j].getAttribute('data-tab') === name));
    renderSeedPill();
    if (RENDER[name]) RENDER[name]();
    if (isHindi()) translateDom(document.body);
    if (document.scrollingElement) document.scrollingElement.scrollTop = 0;
  }

  function renderSeedPill() { /* Seeds were retired in 2.0; kept as a no-op for older call sites. */ }

  /* ---------- Sheets ---------- */

  var lastFocus = null;
  function openSheet(id) {
    closeSheets(true);
    lastFocus = document.activeElement;
    $('scrim').hidden = false;
    var sh = $(id);
    sh.hidden = false;
    if (isHindi()) translateDom(sh);
    var f = sh.querySelector('button, a');
    if (f && f.focus) f.focus();
  }
  function closeSheets(keepFocus) {
    var sheets = document.querySelectorAll('.sheet');
    for (var i = 0; i < sheets.length; i++) sheets[i].hidden = true;
    $('scrim').hidden = true;
    if (!keepFocus && lastFocus && lastFocus.focus && document.contains(lastFocus)) lastFocus.focus();
  }

  /* ---------- LoosenUp Plus: real subscriptions (Razorpay in India, Paddle elsewhere) ---------- */
  // On the website Plus talks to its own server; the phone apps talk to the public one.
  function plusApi() { return (!isNative() && /^https?:$/.test(location.protocol) ? location.origin : PUBLIC_URL) + '/api/plus'; }
  var PLUS_GRACE = 3 * 86400000;
  function plusCall(action, body) {
    if (typeof fetch !== 'function') return Promise.reject(new Error('offline'));
    return fetch(plusApi() + (body ? '' : '?action=' + action), body
      ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({ action: action }, body)) } : {})
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || 'Please try again.'); return j; }, function () { throw new Error('The payment service did not answer. Nothing was charged. Please try again in a moment.'); }); });
  }
  // Plus is on while the paid period lasts (with a few days' grace for a renewal that is still going through).
  function isPlus() {
    var p = state.plus;
    if (!p || !p.active) return false;
    return !p.until || new Date(p.until).getTime() + PLUS_GRACE > now().getTime();
  }
  // Paid parts are locked only when Plus can actually be bought; until then everything stays free.
  function plusRequired() { return !!(state.payConfig && state.payConfig.enabled) && !isPlus(); }
  function loadPayConfig() {
    return plusCall('config').then(function (c) { state.payConfig = { enabled: !!c.enabled, provider: c.provider, currency: c.currency, prices: c.prices }; save(); renderShop(); return state.payConfig; })
      .catch(function () { return state.payConfig; });
  }
  function applyPlus(st) {
    var p = state.plus || {};
    state.plus = { key: p.key, plan: st.plan || p.plan, provider: st.provider || p.provider, active: !!st.active, until: st.until || null,
      cancelAtEnd: !!st.cancelAtEnd, checked: now().getTime() };
    save();
    if (current && RENDER[current]) RENDER[current]();
  }
  function refreshPlus() {
    if (!state.plus || !state.plus.key) return Promise.resolve(false);
    return plusCall('status', { key: state.plus.key }).then(function (st) { var was = isPlus(); applyPlus(st); if (!was && isPlus()) toast('LoosenUp Plus is on. Thank you.'); return isPlus(); })
      .catch(function () { return isPlus(); });
  }
  function renderShop() {
    var c = state.payConfig, on = !!(c && c.enabled);
    if (c && c.prices) { setText('shop-price-monthly', c.prices.monthly); setText('shop-price-yearly', c.prices.yearly); }
    var b = document.querySelectorAll('[data-plus-plan]');
    // Plan buttons show only when Plus can actually be bought.
    for (var i = 0; i < b.length; i++) b[i].hidden = !on || isPlus();
    setText('shop-status', isPlus() ? 'Plus is on. Manage it in Me.'
      : on ? (c.provider === 'razorpay' && c.renews === false ? 'Secure payment with UPI, cards or netbanking. One payment, no renewal.' : c.provider === 'razorpay' ? 'Secure payment with UPI, cards or netbanking. Renews automatically; cancel any time in Me.' : 'Secure payment by card, Apple Pay, Google Pay or PayPal. Renews automatically; cancel any time in Me.')
      : 'LoosenUp Plus opens soon. Until then, everything in LoosenUp is free.');
  }
  function openShop(note) {
    setText('shop-note', note || '');
    $('shop-note').hidden = !note;
    renderShop();
    openSheet('shop-sheet');
    loadPayConfig();
  }
  // Buying: the server makes a Plus key first, then the secure checkout page opens with it.
  // In the phone apps the page opens in the browser; Plus turns on here when the app comes back.
  function buyPlus(plan) {
    if (!state.payConfig || !state.payConfig.enabled) { renderShop(); return Promise.resolve(false); }
    setText('shop-status', 'Opening secure checkout...');
    return plusCall('start', { plan: plan }).then(function (s) {
      state.plus = { key: s.key, plan: s.plan, provider: s.provider, active: false, until: null, cancelAtEnd: false, checked: null };
      save();
      // On the website the checkout stays on this site; the phone apps open it in the browser.
      var base = !isNative() && /^https?:$/.test(location.protocol) ? location.origin : PUBLIC_URL;
      var url = base + '/plus.html#k=' + encodeURIComponent(s.key) + '&plan=' + plan + (state.lang === 'hi' ? '&lang=hi' : '');
      openUrl(url);
      return true;
    }).catch(function (e) { setText('shop-status', e.message === 'offline' ? 'Connect to the internet to continue.' : e.message); return false; });
  }
  function openUrl(url) { window.location.href = url; }
  function restorePlus() {
    var k = ($('plus-restore-key').value || '').trim();
    if (!/^LU[A-Za-z0-9_-]{20,40}$/.test(k)) { setText('plus-status', 'That Plus key does not look right.'); return Promise.resolve(false); }
    setText('plus-status', 'Checking...');
    return plusCall('status', { key: k }).then(function (st) {
      state.plus = { key: k };
      applyPlus(st);
      $('plus-restore-key').value = '';
      setText('plus-status', st.active ? 'LoosenUp Plus is restored on this phone.' : 'That key has no active plan.');
      return !!st.active;
    }).catch(function (e) { setText('plus-status', e.message === 'offline' ? 'Connect to the internet to restore.' : e.message); return false; });
  }
  var cancelArmed = false;
  function cancelPlus() {
    if (!cancelArmed) { cancelArmed = true; setText('plus-cancel', 'Tap again to cancel at the end of this period'); return Promise.resolve(false); }
    cancelArmed = false;
    setText('plus-status', 'Cancelling...');
    return plusCall('cancel', { key: state.plus.key }).then(function (st) {
      applyPlus(st);
      setText('plus-status', 'Cancelled. No more payments, and Plus stays on until the end of this period.');
      return true;
    }).catch(function (e) { setText('plus-status', e.message); return false; });
  }
  function plusDate(iso) { return new Date(iso).toLocaleDateString(locale(), { day: 'numeric', month: 'long', year: 'numeric' }); }
  function renderPlan() {
    var p = state.plus, on = isPlus();
    setText('me-plan', on
      ? 'LoosenUp Plus' + (p.until ? (p.cancelAtEnd ? ': on until ' + plusDate(p.until) + ', then it ends.' : ': on, renews ' + plusDate(p.until) + '.') : ': on.')
      : 'Free: every calm break, tool and SOS, always.');
    $('open-shop').hidden = on;
    $('plus-manage').hidden = !(p && p.key && (on || p.active));
    if (p && p.key) setText('plus-key-view', p.key);
    $('plus-cancel').hidden = !on || !!p.cancelAtEnd;
    setText('plus-cancel', 'Cancel at the end of this period');
    cancelArmed = false;
  }
  function openSupport() {
    renderSos();
    renderOrg();
    var more = $('sos-more');
    if (more) more.open = false;
    openSheet('support-sheet');
  }

  /* ---------- Check-in and pick ---------- */

  var CALM_WORDS = ['', 'A bit tangled', 'A bit tangled', 'A little tense', 'Somewhere in the middle', 'Somewhere in the middle',
    'Fairly settled', 'Fairly calm', 'Calm', 'Very calm', 'Wonderfully calm'];
  function bindSlider(id) {
    var el = $(id);
    var sky = $(id + '-sky');
    var last = null;
    var upd = function () {
      var v = +el.value;
      setText(id + '-out', el.value);
      setText(id + '-word', CALM_WORDS[v] || '');
      // The sky clears as calm rises: rain and heavy clouds at 1, clouds parting in the middle,
      // the petal sun up and glowing at 10. CSS reads --v (0 to 1).
      var t = ((v - 1) / 9).toFixed(3);
      if (sky) sky.style.setProperty('--v', t);
      el.style.setProperty('--fill', (t * 100).toFixed(1) + '%');
      if (last !== null && last !== v) {
        var out = $(id + '-out');
        if (out) { out.classList.remove('pop'); void out.offsetWidth; out.classList.add('pop'); }
        haptic('light');
      }
      last = v;
    };
    el.addEventListener('input', upd);
    el.addEventListener('change', upd);
    upd();
    return upd;
  }

  function activeTab() { return flow.spaceTab || flow.space || 'everyday'; }
  function renderContextChips() {
    // Every feeling stays in the DOM; only the active space's group is visible.
    var tabs = $('space-tabs');
    tabs.textContent = '';
    SPACE_ORDER.forEach(function (k) {
      var t = document.createElement('button');
      t.type = 'button';
      t.className = 'space-tab';
      t.setAttribute('role', 'tab');
      t.setAttribute('data-space-tab', k);
      t.setAttribute('aria-selected', String(k === activeTab()));
      var n = SPACES[k].contexts.filter(function (c) { return (flow.contexts || []).indexOf(c) !== -1; }).length;
      t.textContent = SPACES[k].name + (n ? ' \u00b7 ' + n : '');
      tabs.appendChild(t);
    });
    var box = $('context-chips');
    box.textContent = '';
    SPACE_ORDER.forEach(function (k) {
      var group = document.createElement('div');
      group.className = 'context-group';
      group.setAttribute('data-group', k);
      group.hidden = k !== activeTab();
      var chips = document.createElement('div');
      chips.className = 'chips';
      SPACES[k].contexts.forEach(function (c) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'chip';
        b.setAttribute('data-context', c);
        b.setAttribute('aria-pressed', String((flow.contexts || []).indexOf(c) !== -1));
        b.textContent = c;
        chips.appendChild(b);
      });
      group.appendChild(chips);
      box.appendChild(group);
    });
    renderPicked();
    setText('checkin-step', 'Step 1 of 3' + (flow.space ? ' \u00b7 ' + SPACES[flow.space].name : ''));
  }
  function renderPicked() {
    var list = flow.contexts || [];
    var tray = $('picked-tray');
    tray.textContent = '';
    tray.hidden = !list.length;
    list.forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'picked-chip';
      b.setAttribute('data-unpick', c);
      b.setAttribute('aria-label', 'Remove ' + c);
      b.textContent = c + '  \u00d7';
      tray.appendChild(b);
    });
    setText('context-count', list.length > 1 ? list.length + ' picked' : '');
    var tabs = document.querySelectorAll('[data-space-tab]');
    for (var i = 0; i < tabs.length; i++) {
      var k = tabs[i].getAttribute('data-space-tab');
      var n = SPACES[k].contexts.filter(function (c) { return list.indexOf(c) !== -1; }).length;
      tabs[i].textContent = SPACES[k].name + (n ? ' \u00b7 ' + n : '');
    }
  }
  function toggleContext(ctx) {
    flow.contexts = flow.contexts || [];
    var at = flow.contexts.indexOf(ctx);
    if (at === -1) flow.contexts.push(ctx); else flow.contexts.splice(at, 1);
    flow.context = flow.contexts[0] || null;
    var chip = document.querySelector('[data-context="' + ctx + '"]');
    if (chip) chip.setAttribute('aria-pressed', String(at === -1));
    renderPicked();
    haptic('light');
  }

  // Haptics: native taps on the phone apps, a tiny vibration on Android browsers.
  function haptic(kind) {
    try {
      var H = isNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.Haptics;
      if (H) {
        if (kind === 'success') H.notification({ type: 'SUCCESS' });
        else H.impact({ style: kind === 'medium' ? 'MEDIUM' : 'LIGHT' });
      } else if (navigator.vibrate && /Android/i.test(navigator.userAgent || '')) {
        navigator.vibrate(kind === 'success' ? [12, 40, 12] : 8);
      }
    } catch (e) { /* haptics are a nicety */ }
  }

  function startCheckin(mode, space) {
    flow = { mode: mode, before: 5, context: null, contexts: [], technique: mode === 'quick' ? 'quick' : null, space: space || null, spaceTab: space || null };
    $('calm-before').value = '5';
    $('calm-before').dispatchEvent(new Event('input'));
    go('checkin');
  }

  function renderPick() {
    var rec = flow.picked ? null : recommendFor(flow.contexts);
    // When calm is very low, the body comes first: a long breath out before any thinking or writing.
    if (rec && flow.before != null && +flow.before <= 3 && TECH[rec.id].kind !== 'breath') {
      var many = (flow.contexts || []).filter(Boolean);
      rec = { id: 'sigh', reason: 'When everything feels like a lot, the body comes first. A long, slow breath out helps it settle, and your mind can follow.' +
        (many.length > 1 ? ' Picked for ' + joinNames(many) + '.' : '') };
    }
    if (rec) { flow.technique = rec.id; flow.reason = rec.reason; }
    var t = TECH[flow.technique];
    setText('pick-name', t.name);
    setText('pick-desc', t.desc);
    setText('pick-reason', flow.reason);
    setText('pick-meta', Math.round(t.seconds / 60) + ' minutes');
    $('pick-card').style.setProperty('--badge', t.color);
    var box = $('pick-chips');
    box.textContent = '';
    var sps = (flow.contexts && flow.contexts.length ? flow.contexts : [flow.context]).map(spaceOf);
    CHOOSABLE.forEach(function (id) {
      var tsp = TECH[id].space || 'everyday';
      if (tsp !== 'everyday' && sps.indexOf(tsp) === -1 && id !== flow.technique) return;
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip';
      b.setAttribute('data-pick', id);
      b.setAttribute('aria-pressed', String(id === flow.technique));
      b.textContent = TECH[id].name;
      if (!isUnlocked(id)) {
        b.disabled = true;
        var left = TECH[id].unlockAt - breaksDone();
        var sm = document.createElement('small');
        sm.textContent = 'Opens in ' + plural(left, 'more break', 'more breaks');
        b.appendChild(sm);
      }
      box.appendChild(b);
    });
    var label = 'Begin';
    setText('pick-begin', label);
    renderGuide();
  }

  function beginBreak(id) {
    if (!canStart(id)) return 'unknown';
    save();
    startSession(id);
    return 'started';
  }

  /* ---------- Guided session ---------- */

  var run = null;
  var orbTimer = null;

  /* ---------- Follow-along guides ---------- */
  // How-to tips shown while the exercise gets going.
  var HOW = {
    sigh: ['Breathe in through your nose, then sip in a little more air.', 'Let it all out slowly through your mouth.', 'Let your shoulders drop on every breath out.'],
    breeze: ['Sit comfortably and let your jaw relax.', 'Breathe in through your nose as the circle grows.', 'Breathe out gently as it shrinks.'],
    square: ['Breathe in as the circle grows.', 'Hold gently when it pauses. Never strain.', 'Breathe out, then rest before the next round.'],
    cooldown: ['Breathe in through your nose for four.', 'Breathe out slowly, as if through a straw, for seven.', 'Feel your body settle a little more each round.'],
    quick: ['Breathe in for four as the circle grows.', 'Breathe out for six as it shrinks.', 'That is all. Just follow the circle.'],
    here: ['Go slowly. There are no right answers.', 'Tap a dot each time you notice something.', 'If your mind wanders, come back to the next sense.'],
    release: ['Tense each area firmly, but never to the point of pain.', 'Hold while the circle squeezes, then let go as it opens.', 'Notice the warm, loose feeling after each release.'],
    kind: ['Find a quiet moment, even a short one.', 'Say each line slowly, out loud or in your head.', 'Let your hand rest where it feels comforting.'],
    desk: ['Stay seated, feet flat on the floor.', 'Move gently. Stop if anything feels sore.', 'Follow the timer for each move.'],
    pause: ['Use this before you reply to a message or a person.', 'Take your time on each question.', 'You can always come back to the conversation later.'],
    warmth: ['Close your eyes if that feels okay.', 'Picture each person clearly before you wish them well.', 'Say each wish slowly, in your head.'],
    hum: ['Sit tall and close your eyes if that feels okay.', 'Breathe in through your nose as the circle grows.', 'Hum with your lips closed as it shrinks. Feel the gentle buzz.'],
    nadi: ['Rest your right thumb by your right nostril and your ring finger by the left.', 'Close one side gently and breathe through the other, as the words say.', 'No hand free? Just picture the breath moving side to side.'],
    night: ['Lie down or sit back comfortably.', 'Hold only as long as feels easy. Never strain.', 'Let each breath out be long and slow.']
  };
  // Step exercises: an icon, seconds for each step, tap-to-count dots, or a two-part cue (like tense, then let go).
  var STEP_GUIDE = {
    panic: [{ icon: '🌊', secs: 24 }, { icon: '🌬️', secs: 24, sub: [['Breathe in', 4], ['Breathe out', 6]] }, { icon: '👣', secs: 24, count: 5 }, { icon: '🧊', secs: 24 }, { icon: '🤲', secs: 24 }],
    eyes: [{ icon: '🙌', secs: 24 }, { icon: '🫣', secs: 24 }, { icon: '🔭', secs: 24 }, { icon: '😌', secs: 24, count: 10 }, { icon: '👀', secs: 24 }],
    chai: [{ icon: '☕', secs: 24 }, { icon: '👃', secs: 24 }, { icon: '👅', secs: 24 }, { icon: '🌡️', secs: 24 }, { icon: '📵', secs: 24 }],
    stretch: [{ icon: '🙆', secs: 24 }, { icon: '🙇', secs: 24 }, { icon: '↔️', secs: 24, sub: [['Left side', 6], ['Right side', 6]] }, { icon: '🔄', secs: 24 }, { icon: '🌬️', secs: 24, sub: [['Breathe in', 4], ['Breathe out', 6]] }],
    here: [{ icon: '👀', secs: 24, count: 5 }, { icon: '✋', secs: 24, count: 4 }, { icon: '👂', secs: 24, count: 3 }, { icon: '👃', secs: 24, count: 2 }, { icon: '👅', secs: 24, count: 1 }],
    release: [{ icon: '🤷', secs: 24, sub: [['Tense', 5], ['Let go', 7]] }, { icon: '✊', secs: 24, sub: [['Squeeze', 5], ['Open wide', 7]] },
      { icon: '😖', secs: 24, sub: [['Scrunch', 5], ['Let go', 7]] }, { icon: '🦶', secs: 24, sub: [['Press down', 5], ['Rest', 7]] }, { icon: '🌬️', secs: 24, sub: [['Breathe in', 4], ['Long breath out', 8]] }],
    kind: [{ icon: '🤲', secs: 24 }, { icon: '💬', secs: 24 }, { icon: '🤝', secs: 24 }, { icon: '💗', secs: 24 }, { icon: '🫶', secs: 24 }],
    desk: [{ icon: '🔄', secs: 24, count: 5 }, { icon: '↔️', secs: 24, sub: [['Left side', 6], ['Right side', 6]] }, { icon: '🙏', secs: 24, sub: [['Press', 5], ['Let go', 7]] },
      { icon: '🔭', secs: 24 }, { icon: '🌬️', secs: 24, sub: [['Breathe in', 4], ['Long breath out', 8]] }],
    pause: [{ icon: '🌬️', secs: 24, sub: [['Breathe in', 4], ['Breathe out', 6]] }, { icon: '🏷️', secs: 24 }, { icon: '❓', secs: 24 }, { icon: '🤝', secs: 24 }, { icon: '💬', secs: 24 }],
    warmth: [{ icon: '😊', secs: 24 }, { icon: '🕊️', secs: 24 }, { icon: '🧑', secs: 24 }, { icon: '🌤️', secs: 24 }, { icon: '💛', secs: 24 }]
  };
  var SHORT_PHASE = { 'Breathe in': 'In', 'A little more': 'Top up', 'Long breath out': 'Out', 'Breathe out': 'Out', 'Hold gently': 'Hold', 'Rest': 'Rest' };
  var RING = 289.03; // circumference of r = 46
  function ringTo(el, seconds) {
    if (!el) return;
    el.style.transition = 'none';
    el.style.strokeDashoffset = String(RING);
    void el.getBoundingClientRect();
    if (prefersReducedMotion()) { el.style.strokeDashoffset = '0'; return; }
    el.style.transition = 'stroke-dashoffset ' + seconds + 's linear';
    el.style.strokeDashoffset = '0';
  }
  function renderHow(id) {
    var ul = $('how-list');
    ul.textContent = '';
    (HOW[id] || []).forEach(function (h) { var li = document.createElement('li'); li.textContent = h; ul.appendChild(li); });
    ul.hidden = !(HOW[id] || []).length;
  }
  function renderPatternStrip(t) {
    var box = $('pattern-strip');
    box.textContent = '';
    box.hidden = t.kind !== 'breath';
    if (t.kind !== 'breath') return;
    t.pattern.forEach(function (ph, i) {
      var c = document.createElement('span');
      c.className = 'pchip';
      c.setAttribute('data-phase', String(i));
      c.textContent = (SHORT_PHASE[ph[0]] || ph[0]) + ' ' + ph[1] + 's';
      box.appendChild(c);
    });
  }
  function markPhase(i) {
    var chips = document.querySelectorAll('#pattern-strip .pchip');
    for (var k = 0; k < chips.length; k++) chips[k].classList.toggle('on', k === i);
  }

  function startSession(id) {
    stopRun();
    var t = TECH[id];
    flow.technique = id;
    var cycle = t.pattern ? t.pattern.reduce(function (a, p) { return a + p[1]; }, 0) : 0;
    // The chosen length (1 to 10 minutes) applies to every exercise except the 60 second Quick breeze.
    var secs = id === 'quick' ? t.seconds : (state.lengthMin || 2) * 60;
    run = { id: id, left: secs, scale: secs / t.seconds, paused: false, phase: -1, phaseLeft: 0, step: 0, stepLeft: 0, crisisShown: false,
      ready: t.kind === 'journal' ? 0 : 3, round: 0, rounds: cycle ? Math.max(1, Math.round(secs / cycle)) : 0, sub: 0, subLeft: 0, dots: 0 };
    var scr = $('screen-session');
    scr.classList.toggle('steps', t.kind === 'steps');
    scr.classList.toggle('journal', t.kind === 'journal');
    scr.classList.toggle('breath', t.kind === 'breath');
    setText('session-title', t.name);
    $('step-box').hidden = t.kind !== 'steps';
    $('journal-box').hidden = t.kind !== 'journal';
    $('letitout-text').value = '';
    setText('session-pause', 'Pause');
    $('session-pause').setAttribute('aria-pressed', 'false');
    renderVoiceButtons();
    toggleAudioPanel(false);
    setText('session-finish', 'Finish early');
    renderHow(id);
    renderPatternStrip(t);
    setText('round-count', '');
    go('session');
    var orb = $('orb');
    orb.style.transitionDuration = '0s';
    orb.style.transform = 'scale(0.62)';
    $('orb-petals').style.transitionDuration = '0s';
    $('orb-petals').style.transform = 'scale(0.55)';
    setText('session-kicker', t.free ? 'Always free' : 'Guided break');
    speak(INTRO[t.kind] || INTRO.breath);
    speak(t.desc, true);
    if (state.bed && state.bed !== 'none' && !audio) { sessionBed = playSound(state.bed, 0.35); }
    if (t.kind === 'journal') { setText('cue', ''); setText('orb-count', ''); }
    else {
      // A short get-ready countdown so people can settle and read how it works.
      setText('cue', 'Get ready');
      setText('orb-count', String(run.ready));
      speak('Get ready', true);
      ringTo($('phase-ring'), run.ready);
      if (t.kind === 'steps') { renderStepProgress(t); showStep(0, true); }
    }
    updateTime();
    run.timer = setInterval(tick, 1000);
  }

  function beginGuide() {
    var t = TECH[run.id];
    if (t.kind === 'breath') nextPhase();
    if (t.kind === 'steps') showStep(0);
  }

  function nextPhase() {
    var t = TECH[run.id];
    run.phase = (run.phase + 1) % t.pattern.length;
    if (run.phase === 0) run.round++;
    var ph = t.pattern[run.phase];
    run.phaseLeft = ph[1];
    setText('cue', ph[0]);
    setText('orb-count', String(ph[1]));
    setText('round-count', 'Round ' + Math.min(run.round, run.rounds) + ' of ' + run.rounds);
    markPhase(run.phase);
    var kind = ph[2] >= 1 ? (run.phase > 0 && t.pattern[run.phase - 1][2] >= 1 ? 'hold' : 'in') : 'out';
    $('screen-session').setAttribute('data-phase', kind);
    try { window.dispatchEvent(new CustomEvent('lu:phase', { detail: { kind: kind === 'out' && run.phase > 0 && t.pattern[run.phase - 1][2] < 1 ? 'rest' : kind, secs: ph[1] } })); } catch (e) { /* older browsers */ }
    ringTo($('phase-ring'), ph[1]);
    speak(ph[0], true);
    chime();
    var orb = $('orb');
    var pet = $('orb-petals');
    if (prefersReducedMotion()) { orb.style.transform = ''; pet.style.transform = ''; return; }
    orb.style.transitionDuration = ph[1] + 's';
    pet.style.transitionDuration = ph[1] + 's';
    clearTimeout(orbTimer);
    orbTimer = setTimeout(function () {
      orb.style.transform = 'scale(' + ph[2] + ')';
      pet.style.transform = 'scale(' + (ph[2] >= 1 ? 1.02 : 0.55) + ') rotate(' + (ph[2] >= 1 ? 18 : 0) + 'deg)';
    }, 30);
  }

  function renderStepProgress(t) {
    var box = $('step-progress');
    box.textContent = '';
    t.steps.forEach(function () { box.appendChild(document.createElement('i')); });
  }
  function stepGuide(i) {
    var g = (STEP_GUIDE[run.id] || [])[i] || { icon: '', secs: Math.floor(TECH[run.id].seconds / TECH[run.id].steps.length) };
    var k = run.scale || 1;
    if (k === 1) return g;
    var out = {};
    for (var key in g) out[key] = g[key];
    out.secs = Math.max(5, Math.round(g.secs * k));
    return out;
  }
  function showStep(i, preview) {
    var t = TECH[run.id];
    var g = stepGuide(i);
    run.step = i;
    setText('step-count', 'Step ' + (i + 1) + ' of ' + t.steps.length);
    setText('step-text', t.steps[i]);
    setText('step-icon', g.icon || '');
    var bars = document.querySelectorAll('#step-progress i');
    for (var b = 0; b < bars.length; b++) bars[b].className = b < i ? 'done' : b === i ? 'on' : '';
    $('step-next').hidden = i >= t.steps.length - 1;
    // Tap-to-count dots, for steps like "name 5 things you can see".
    var dots = $('step-dots');
    dots.textContent = '';
    dots.hidden = !g.count;
    run.dots = 0;
    for (var d = 0; d < (g.count || 0); d++) {
      var bt = document.createElement('button');
      bt.type = 'button'; bt.className = 'sdot'; bt.setAttribute('data-dot', String(d));
      bt.setAttribute('aria-label', 'Noticed ' + (d + 1) + ' of ' + g.count);
      bt.setAttribute('aria-pressed', 'false');
      dots.appendChild(bt);
    }
    $('step-sub').hidden = !g.sub;
    if (preview) { setText('step-left', String(run.ready)); return; }
    run.stepLeft = g.secs;
    setText('step-left', String(run.stepLeft));
    ringTo($('step-ring'), g.secs);
    run.sub = 0;
    if (g.sub) startSub(g);
    speak(t.steps[i], true);
    if (i > 0) chime();
    var orb = $('orb');
    if (!prefersReducedMotion() && !g.sub) {
      orb.style.transitionDuration = '1.2s'; orb.style.transform = 'scale(' + (0.7 + 0.06 * i) + ')';
      $('orb-petals').style.transitionDuration = '1.2s'; $('orb-petals').style.transform = 'scale(' + (0.6 + 0.09 * i) + ') rotate(' + (i * 14) + 'deg)';
    }
  }
  // Two-part cues inside a step, such as "Tense" then "Let go", repeated with the circle squeezing and opening.
  function startSub(g) {
    var part = g.sub[run.sub % g.sub.length];
    run.subLeft = part[1];
    setText('step-sub', part[0] + ' · ' + part[1]);
    var squeeze = run.sub % g.sub.length === 0;
    var orb = $('orb');
    if (!prefersReducedMotion()) { orb.style.transitionDuration = part[1] + 's'; orb.style.transform = 'scale(' + (squeeze ? 0.66 : 1) + ')'; }
    if (run.sub > 0) chime();
  }
  function tapDot(i) {
    var g = stepGuide(run.step);
    if (!g.count) return;
    var dots = document.querySelectorAll('#step-dots .sdot');
    if (i !== run.dots) return;
    dots[i].setAttribute('aria-pressed', 'true');
    run.dots++;
    haptic('light');
    if (run.dots >= g.count && run.step < TECH[run.id].steps.length - 1) setTimeout(function () { if (run) showStep(run.step + 1); }, 700);
  }

  function tick() {
    if (!run || run.paused) return;
    var t = TECH[run.id];
    if (run.ready > 0) {
      run.ready--;
      setText('orb-count', run.ready ? String(run.ready) : '');
      if (t.kind === 'steps') setText('step-left', run.ready ? String(run.ready) : '');
      if (!run.ready) beginGuide();
      return;
    }
    run.left--;
    if (t.kind === 'breath') {
      run.phaseLeft--;
      if (run.phaseLeft <= 0) nextPhase(); else setText('orb-count', String(run.phaseLeft));
    }
    if (t.kind === 'steps') {
      var g = stepGuide(run.step);
      run.stepLeft--;
      setText('step-left', String(Math.max(0, run.stepLeft)));
      if (g.sub) { run.subLeft--; if (run.subLeft <= 0) { run.sub++; startSub(g); } else setText('step-sub', g.sub[run.sub % g.sub.length][0] + ' · ' + run.subLeft); }
      if (run.stepLeft <= 0 && run.step < t.steps.length - 1) showStep(run.step + 1);
    }
    updateTime();
    if (run.left <= 0) endSession(true);
  }

  function updateTime() {
    var s = Math.max(0, run.left);
    setText('session-time', Math.floor(s / 60) + ':' + pad(s % 60));
  }

  function stopRun() {
    if (run && run.timer) clearInterval(run.timer);
    clearTimeout(orbTimer);
    stopVoice();
  }

  function endSession(complete) {
    if (!run) return;
    stopRun();
    $('letitout-text').value = '';
    run = null;
    var after = $('calm-after');
    after.value = String(flow.before != null ? flow.before : 5);
    after.dispatchEvent(new Event('input'));
    // Breathe now skips the check-in, so the before rating is one optional tap here.
    var asks = flow.mode === 'now';
    flow.beforeTap = null;
    $('before-tap').hidden = !asks;
    $('after-step').hidden = asks;
    renderBeforeTap();
    go('after');
    if (sessionBed) { stopSound(false); sessionBed = false; }
    speak(OUTRO);
  }

  function renderBeforeTap() {
    var b = document.querySelectorAll('[data-before]');
    for (var i = 0; i < b.length; i++) b[i].setAttribute('aria-pressed', String(+b[i].getAttribute('data-before') === flow.beforeTap));
    setText('after-next', flow.mode === 'now' && flow.beforeTap == null ? 'Finish' : 'See my Calm gain');
  }
  function tapBefore(v) {
    flow.beforeTap = flow.beforeTap === v ? null : v;
    renderBeforeTap();
    haptic('light');
  }

  // One tap from Today or SOS: straight into a guided breath, no check-in and no Pick screen.
  function breatheNow() {
    closeSheets(true);
    flow = { mode: 'now', before: null, beforeTap: null, context: 'Just a quick lift', contexts: ['Just a quick lift'], technique: 'quick', space: null };
    return beginBreak('quick');
  }

  // Voice, chimes and background sound live in a small panel inside the session.
  function toggleAudioPanel(open) {
    var panel = $('session-audio-panel');
    var show = open != null ? !!open : panel.hidden;
    panel.hidden = !show;
    $('session-audio').setAttribute('aria-expanded', String(show));
    if (show) renderGuide();
  }
  function setBed(bed) {
    state.bed = bed;
    save();
    renderGuide();
    if (!run) return;
    if (sessionBed) { stopSound(true); sessionBed = false; }
    if (bed !== 'none' && !audio) sessionBed = playSound(bed, 0.35);
  }

  function togglePause() {
    if (!run) return;
    run.paused = !run.paused;
    setText('session-pause', run.paused ? 'Resume' : 'Pause');
    $('session-pause').setAttribute('aria-pressed', String(run.paused));
    if (run.paused) stopVoice();
  }

  var chimeCtx = null;
  var chimesPlayed = 0;
  function chime() {
    if (!state.chime) return false;
    var AC = window.AudioContext || window.webkitAudioContext;
    chimesPlayed++;
    if (!AC) return false;
    try {
      chimeCtx = chimeCtx || new AC();
      var t0 = chimeCtx.currentTime;
      [528, 792].forEach(function (f, i) {
        var o = chimeCtx.createOscillator(), g = chimeCtx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(i ? 0.025 : 0.05, t0 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.6);
        o.connect(g); g.connect(chimeCtx.destination);
        o.start(t0); o.stop(t0 + 1.7);
      });
      return true;
    } catch (e) { return false; }
  }
  var sessionBed = false;
  function renderGuide() {
    var g = document.querySelectorAll('[data-guide]');
    for (var i = 0; i < g.length; i++) {
      var k = g[i].getAttribute('data-guide');
      g[i].setAttribute('aria-pressed', String(k === 'voice' ? !!state.voice : !!state.chime));
    }
    var b = document.querySelectorAll('[data-bed]');
    for (var j = 0; j < b.length; j++) b[j].setAttribute('aria-pressed', String(b[j].getAttribute('data-bed') === (state.bed || 'none')));
  }

  function canSpeak() { return 'speechSynthesis' in window && typeof window.SpeechSynthesisUtterance === 'function'; }
  // Recorded voice: clips of a real human voice in www/voice/<lang>/<id>.m4a, listed in
  // www/voice/manifest.json. Lines without a clip fall back to the device voice.
  var voiceClips = null;
  var voiceQueue = [];
  var voiceAudio = null;
  function loadVoiceClips() {
    if (typeof fetch !== 'function') return Promise.resolve(null);
    return fetch('voice/manifest.json').then(function (r) { return r.ok ? r.json() : null; })
      .then(function (m) { voiceClips = m && m.lines && m.have ? m : null; return voiceClips; })
      .catch(function () { return null; });
  }
  function clipFor(text) {
    if (!voiceClips) return null;
    var id = voiceClips.lines[text], lang = state.lang === 'hi' ? 'hi' : 'en';
    return id && (voiceClips.have[lang] || []).indexOf(id) !== -1 ? 'voice/' + lang + '/' + id + '.m4a' : null;
  }
  function deviceUtterance(text) {
    var u = new window.SpeechSynthesisUtterance(tr(text));
    u.rate = 0.9; u.pitch = 1.05;
    u.lang = state.lang === 'hi' ? 'hi-IN' : 'en-IN';
    return u;
  }
  function stopVoice() {
    voiceQueue = [];
    if (voiceAudio) { try { voiceAudio.pause(); } catch (e) { /* already stopped */ } voiceAudio = null; }
    if (window.speechSynthesis) { try { window.speechSynthesis.cancel(); } catch (e) { /* no voice */ } }
  }
  function playNextVoice() {
    if (voiceAudio || !voiceQueue.length) return;
    var text = voiceQueue.shift(), src = clipFor(text);
    var next = function () { voiceAudio = null; playNextVoice(); };
    if (src && typeof window.Audio === 'function') {
      var a = new window.Audio(src);
      voiceAudio = a;
      a.onended = next;
      a.onerror = function () { voiceAudio = null; if (canSpeak()) { var u = deviceUtterance(text); u.onend = next; window.speechSynthesis.speak(u); } else next(); };
      var p = a.play();
      if (p && p.catch) p.catch(a.onerror);
    } else if (canSpeak()) {
      voiceAudio = { pause: function () {} };
      var u = deviceUtterance(text);
      u.onend = next;
      window.speechSynthesis.speak(u);
    } else next();
  }
  // force: always speak (sleep sessions are voice-led even when the voice guide is off).
  function speak(text, queue, force) {
    if (!state.voice && !force) return;
    if (voiceClips) {
      // Recorded clips and device voice share one queue so lines never overlap.
      if (!queue) stopVoice();
      voiceQueue.push(text);
      playNextVoice();
      return;
    }
    if (!canSpeak()) return;
    try {
      if (!queue) window.speechSynthesis.cancel();
      window.speechSynthesis.speak(deviceUtterance(text));
    } catch (e) { /* voice not available */ }
  }
  function renderVoiceButtons() {
    var on = !!state.voice;
    renderGuide();
    setText('voice-toggle', on ? 'Voice is on' : 'Voice is off');
    $('voice-toggle').setAttribute('aria-pressed', String(on));
  }
  function toggleVoice() {
    state.voice = !state.voice;
    save();
    renderVoiceButtons();
    if (state.voice && !canSpeak()) toast('Voice guide is not available on this device, the on-screen cues will guide you.');
    else if (state.voice) speak('Voice guide on.');
  }

  /* ---------- Result ---------- */

  function finishAfter() {
    var before = flow.mode === 'now' ? flow.beforeTap : flow.before;
    var after = clampScore($('calm-after').value);
    var r = completeSession({ technique: flow.technique || 'quick', context: flow.context || 'Just a quick lift', contexts: flow.contexts, before: before, after: after });
    completeProgramDay(r);
    var advanced = planDone('tech:' + (flow.technique || 'quick'));
    renderResult(r);
    var close = renderPlanNext('plan-next', advanced);
    if (close) setText('result-note', close);
    go('result');
    haptic('success');
  }

  // The weekly goal: days with at least one break this week (Monday to Sunday), against a goal people choose.
  function weekGoal() {
    var d = now();
    var wd = (d.getDay() + 6) % 7;
    var mon = new Date(d.getFullYear(), d.getMonth(), d.getDate() - wd, 12);
    var days = {};
    state.sessions.forEach(function (s) { days[s.day] = true; });
    var week = [];
    for (var i = 0; i < 7; i++) week.push(!!days[dayKey(new Date(mon.getFullYear(), mon.getMonth(), mon.getDate() + i, 12))]);
    var n = week.filter(Boolean).length;
    return { days: n, goal: state.weeklyGoal || 3, week: week };
  }
  function goalText(g) { g = g || weekGoal(); return g.days + ' of ' + g.goal + ' days this week'; }
  function weekStats() {
    var wk = weekKey(now());
    var ses = state.sessions.filter(function (x) { return weekKey(new Date(x.ts)) === wk; });
    return { n: ses.length, avg: avgGain(ses) };
  }
  // Still feeling it? When calm is still low, or a break did not help, offer something different and someone to talk to.
  function renderStillFeeling(r) {
    var box = $('still-feeling');
    if (!box) return false;
    var show = r.after <= 3 || (r.rated && r.gain <= 0 && r.after <= 5);
    box.hidden = !show;
    if (!show) return false;
    var next = flow && flow.technique === 'panic' ? 'sigh' : 'panic';
    setText('still-try', 'Try ' + TECH[next].name);
    $('still-try').setAttribute('data-now', next);
    return true;
  }
  function renderResult(r) {
    var name = state.name || 'friend';
    setText('result-headline', r.gain > 0 ? 'Lovely, ' + name + '!' : 'You showed up, ' + name + '.');
    var g = $('result-gain');
    g.textContent = signed(r.shownGain);
    g.setAttribute('aria-label', signed(r.shownGain) + ' Calm gain');
    g.parentNode.hidden = !r.rated;
    setText('result-change', r.rated ? 'From ' + r.before + ' to ' + r.after + ' out of 10' : 'Calm now: ' + r.after + ' out of 10');
    var ws = weekStats();
    var gw = weekGoal();
    setText('result-streak', gw.days + ' of ' + gw.goal + ' days');
    setText('result-week', plural(ws.n, 'break this week', 'breaks this week'));
    setText('result-avg', signed(ws.avg) + ' average Calm gain');
    var items = [];
    if (r.rated && r.gain <= 0) items.push('You showed up, and that counts.');
    if (r.goalMet) items.push('Weekly goal met. Lovely.');
    if (r.programNote) items.push(r.programNote);
    r.newBadges.forEach(function (b) { if (b !== 'first' || breaksDone() === 1) items.push('Milestone: ' + BADGES[b][0]); });
    var ul = $('result-rewards');
    ul.textContent = '';
    items.forEach(function (t) { var li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
    ul.hidden = !items.length;
    var note = r.rated && r.gain <= 0 ? 'You made time for yourself today, and that is what matters most.' : NOTES[(breaksDone() - 1) % NOTES.length];
    renderStillFeeling(r);
    setText('result-note', note);
    // Restart the sunrise animation.
    var rise = document.querySelector('.rs-rise');
    if (rise && rise.getBBox !== undefined) { rise.style.animation = 'none'; void rise.getBoundingClientRect(); rise.style.animation = ''; }
  }

  /* ---------- Tabs ---------- */

  function greeting() {
    var b = bucketOf(now().getTime());
    var name = state.name || 'friend';
    return { Mornings: 'Good morning, ', Afternoons: 'Good afternoon, ', Evenings: 'Good evening, ', 'Quiet nights': 'Quiet night, ' }[b] + name;
  }

  var PETAL = 'M0-44C17-52 18-78 0-94-18-78-17-52 0-44Z';
  function addPetals(parent, cx, cy, scale, cls) {
    for (var i = 0; i < 10; i++) {
      var g = svg('g', { transform: 'translate(' + cx + ' ' + cy + ') rotate(' + (i * 36) + ') scale(' + scale + ')' }, parent);
      var pth = svg('path', { d: PETAL, fill: i % 2 ? '#FFB088' : '#FFC857' }, g);
      if (cls) { pth.setAttribute('class', cls); pth.style.setProperty('--i', String(i)); }
    }
  }
  function renderSky() {
    var d = now();
    var b = bucketOf(d.getTime());
    var card = $('today-sky');
    card.setAttribute('data-time', b);
    // The sun travels an arc from 6:00 to 20:00.
    var hrs = d.getHours() + d.getMinutes() / 60;
    var t = Math.max(0, Math.min(1, (hrs - 6) / 14));
    // The sun stays in the right-hand part of the sky so it never sits behind the greeting.
    card.style.setProperty('--sx', (70 + t * 18).toFixed(1) + '%');
    card.style.setProperty('--sy', (34 - Math.sin(t * Math.PI) * 16).toFixed(1) + '%');
    setText('today-date', d.toLocaleDateString(locale(), { weekday: 'long', day: 'numeric', month: 'long' }));
    setText('today-sky-streak', state.sessions.length
      ? goalText() + ' · ' + plural(state.sessions.length, 'break', 'breaks')
      : 'Your first break is two minutes away');
  }

  function renderToday() {
    renderProgramCard();
    renderDaily();
    renderNewTags();
    renderSky();
    setText('today-title', greeting());
    var ul = $('today-recent');
    ul.textContent = '';
    var recent = state.sessions.slice(-3).reverse();
    if (!recent.length) {
      var li0 = document.createElement('li');
      li0.textContent = 'Your breaks will appear here.';
      ul.appendChild(li0);
    }
    recent.forEach(function (s) {
      var li = document.createElement('li');
      var a = document.createElement('span');
      a.textContent = (TECH[s.technique] ? TECH[s.technique].name : 'Break') + ', ' + (s.contexts || [s.context]).join(' + ');
      var g = document.createElement('span');
      g.className = 'g';
      g.textContent = isRated(s) ? signed(Math.max(0, s.gain)) + ' Calm gain' : '';
      li.appendChild(a); li.appendChild(g);
      ul.appendChild(li);
    });
    renderGoldenBanner();
    renderMood();
    renderEmotions();
    renderSupportCard();
    renderForYou();
    renderSteps();
    renderJar();
    $('check-due').hidden = !checkDue();
  }

  function todayMood() {
    var dk = dayKey(now());
    for (var i = 0; i < state.moods.length; i++) if (state.moods[i].day === dk) return state.moods[i].mood;
    return null;
  }
  function setMood(n) {
    var dk = dayKey(now());
    var found = false;
    state.moods.forEach(function (m) { if (m.day === dk) { m.mood = n; found = true; } });
    if (!found) state.moods.push({ day: dk, mood: n });
    if (state.moods.length > 400) state.moods = state.moods.slice(-400);
    save();
    renderMood();
    renderSupportCard();
    renderForYou();
    renderSeedPill();
    // Ask the gentle safety question at most once a day, so the lowest face never feels like a trap.
    if (n === 1 && state.safetyAskedDay !== dk) { state.safetyAskedDay = dk; save(); openSheet('safety-sheet'); }
  }
  function renderMood() {
    var m = todayMood();
    var btns = document.querySelectorAll('[data-mood]');
    for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', String(+btns[i].getAttribute('data-mood') === m));
    var scale = document.querySelector('.mood-scale');
    if (scale) { scale.setAttribute('data-level', String(m || 0)); scale.style.setProperty('--lv', String(m ? (m - 1) / 4 : 0)); }
    var moods = document.querySelector('.moods');
    if (moods) moods.classList.toggle('has-pick', !!m);
    setText('mood-done', m ? MOOD_NOTES[m] : 'One tap is enough. Every answer is welcome here.');
    var mem = $('jar-memory');
    if (m && m <= 2 && state.goodThings.length) {
      var g = state.goodThings[Math.floor(rng() * state.goodThings.length)];
      mem.textContent = 'From your Good things jar: "' + g.text + '"';
      mem.hidden = false;
    } else mem.hidden = true;
  }
  function heavyStretch() {
    // Three check-ins in a row on consecutive days, all heavy, the latest today or yesterday.
    var ms = state.moods.slice().sort(function (a, b) { return a.day < b.day ? -1 : 1; }).slice(-3);
    if (ms.length < 3) return false;
    for (var i = 0; i < 3; i++) if (ms[i].mood > 2) return false;
    if (daysBetween(ms[0].day, ms[1].day) !== 1 || daysBetween(ms[1].day, ms[2].day) !== 1) return false;
    return daysBetween(ms[2].day, dayKey(now())) <= 1;
  }
  function renderSupportCard() { $('support-card').hidden = !heavyStretch(); }

  var stepOffset = 0;
  function currentStep() { return STEPS[(dayNum(dayKey(now())) + stepOffset) % STEPS.length]; }
  function renderSteps() {
    setText('step-idea', currentStep());
    var dk = dayKey(now());
    var today = state.smallSteps.filter(function (x) { return x.day === dk; }).length;
    setText('steps-note', today ? plural(today, 'small step', 'small steps') + ' today. Each one counts.' : 'Tiny actions count, and each one lifts your day a little.');
  }
  function doStep() {
    var dk = dayKey(now());
    var today = state.smallSteps.filter(function (x) { return x.day === dk; }).length;
    state.smallSteps.push({ day: dk, step: currentStep() });
    var xp = today < LIFT_XP_PER_DAY;
    if (xp) state.xp += 3;
    save();
    stepOffset++;
    renderSteps();
    renderSeedPill();
    haptic('success');
    toast('Lovely. That small step counts.');
    planDone('step');
  }
  function renderJar() {
    var n = state.goodThings.length;
    setText('jar-count', n ? plural(n, 'good thing', 'good things') + ' saved in your jar.' : 'Your jar is ready. Today\'s first good thing can be tiny.');
  }
  function openJar() {
    $('good-text').value = '';
    openSheet('jar-sheet');
    var t = $('good-text');
    if (t.focus) t.focus();
  }
  function onGoodInput() {
    if (isCrisis($('good-text').value)) { $('good-text').value = ''; openSupport(); }
  }
  function saveGood() {
    var text = ($('good-text').value || '').trim().replace(/\s+/g, ' ').slice(0, 160);
    if (!text) { toast('Write a word or two first.'); return; }
    if (isCrisis(text)) { $('good-text').value = ''; openSupport(); return; }
    state.goodThings.push({ day: dayKey(now()), text: text });
    if (state.goodThings.length > 200) state.goodThings = state.goodThings.slice(-200);
    var dk = dayKey(now());
    if (state.jarXp.day !== dk) state.jarXp = { day: dk, count: 0 };
    var xp = state.jarXp.count < LIFT_XP_PER_DAY;
    if (xp) { state.jarXp.count++; state.xp += 2; }
    save();
    $('good-text').value = '';
    closeSheets();
    renderJar();
    renderSeedPill();
    toast('Saved in your jar.');
    planDone('jar');
  }

  /* ---------- SOS ---------- */

  function sosHref(loc) {
    var t = state.trusted;
    if (!t) return '#';
    var body = 'Hi ' + t.name + ', it is ' + (state.name && state.name !== 'friend' ? state.name : 'me') +
      '. I am having a really hard time and could really use you right now. Can you call me or come be with me?';
    if (loc) body += ' I am here: https://maps.google.com/?q=' + loc.lat.toFixed(5) + ',' + loc.lon.toFixed(5);
    body = tr(body);
    return 'sms:' + t.phone + '?&body=' + encodeURIComponent(body);
  }
  // SOS: three ranked actions. The middle one texts the trusted person, or Vandrevala on WhatsApp
  // when nobody is set up yet. Everything else waits under More options.
  function renderSos() {
    var t = state.trusted;
    var a = $('sos-alert');
    if (t) {
      setText('sos-text-title', 'Text ' + t.name + ' now');
      setText('sos-text-sub', 'Opens your messages with a note ready to send');
      a.setAttribute('href', sosHref(null));
      a.removeAttribute('target');
    } else {
      setText('sos-text-title', 'Text Vandrevala on WhatsApp');
      setText('sos-text-sub', 'Free, 24x7, if talking is hard');
      a.setAttribute('href', HL.vandrevala.whatsapp);
      a.setAttribute('target', '_blank');
    }
    $('sos-whatsapp').hidden = !t;
    $('sos-add-trusted').hidden = !!t;
    $('sos-location').hidden = !t;
    setText('sos-location', 'Add my location to the message: ' + (state.sosLocation ? 'on' : 'off'));
    $('sos-location').setAttribute('aria-pressed', String(!!state.sosLocation));
  }
  // The trusted person is set up in Me, never inside the crisis sheet.
  function renderTrusted(editing) {
    var t = state.trusted;
    $('trusted-setup').hidden = !!t && !editing;
    $('trusted-edit').hidden = !t || !!editing;
    if (editing && t) { $('trusted-name').value = t.name; $('trusted-phone').value = t.phone; }
    setText('me-trusted', t ? 'Trusted person: ' + t.name + ' (' + t.phone + '). SOS can message them in one tap.'
      : 'Add a trusted person so SOS can message them in one tap.');
  }
  function saveTrusted() {
    var name = ($('trusted-name').value || '').trim().slice(0, 40);
    var phone = ($('trusted-phone').value || '').replace(/[^\d+]/g, '').replace(/(?!^)\+/g, '');
    if (phone.replace(/\D/g, '').length < 6) { toast('Add their phone number, with the country code if you can.'); return; }
    state.trusted = { name: name || 'my trusted person', phone: phone };
    save();
    renderTrusted(false);
    renderSos();
    toast('Saved. SOS can now message ' + state.trusted.name + ' in one tap.');
  }
  function setUpTrusted() {
    closeSheets(true);
    go('me');
    renderTrusted(!!state.trusted);
    var f = $('trusted-name');
    if (f.scrollIntoView) f.scrollIntoView({ block: 'center' });
    if (f.focus) f.focus();
  }
  function sendSos(e) {
    if (!state.trusted) return;
    if (!state.sosLocation || !navigator.geolocation) return; // the link opens the messaging app as it is
    e.preventDefault();
    var go2 = function (loc) { window.location.href = sosHref(loc); };
    navigator.geolocation.getCurrentPosition(function (pos) { go2({ lat: pos.coords.latitude, lon: pos.coords.longitude }); },
      function () { go2(null); }, { timeout: 6000, maximumAge: 60000 });
  }

  function renderGoldenBanner() {
    var show = false;
    if (state.goldenHour) {
      var d = now();
      var hm = pad(d.getHours()) + ':' + pad(d.getMinutes());
      var doneToday = state.streak.lastDay === dayKey(d);
      if (hm >= state.goldenHour && !doneToday) show = nudgeAllowed('golden');
    }
    $('golden-banner').hidden = !show;
  }

  // Small seeded random numbers for stable layouts.
  function seeded(i) {
    var t = (i + 1) * 0x6D2B79F5;
    return function () {
      t += 0x6D2B79F5;
      var r = Math.imul(t ^ (t >>> 15), 1 | t);
      r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
      return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
    };
  }
  function renderMilestones() {
    var ul = $('badges');
    ul.textContent = '';
    // Earned milestones, plus the next one to look forward to.
    var nextShown = false;
    Object.keys(BADGES).forEach(function (id) {
      var has = state.badges.indexOf(id) !== -1;
      if (!has && nextShown) return;
      if (!has) nextShown = true;
      var li = document.createElement('li');
      if (!has) li.className = 'dim';
      var st = document.createElement('strong');
      st.textContent = BADGES[id][0];
      var sp = document.createElement('span');
      sp.textContent = has ? BADGES[id][1] : 'Not yet: ' + BADGES[id][1].toLowerCase();
      li.appendChild(st); li.appendChild(sp);
      ul.appendChild(li);
    });
  }
  function renderProgress() {
    renderShelf();
    var all = state.sessions;
    var gp = weekGoal();
    setText('prog-streak', gp.days + ' / ' + gp.goal);
    setText('prog-best', gp.days >= gp.goal ? 'Goal met this week' : 'Days this week');
    setText('prog-total', String(all.length));
    setText('prog-avg', all.length ? signed(avgGain(all)) : 'Not yet');
    var wb = state.wellbeing && state.wellbeing.length ? state.wellbeing[state.wellbeing.length - 1] : null;
    setText('prog-wb', wb ? wb.score + ' / 100' : 'Not yet');
    setText('prog-wb-note', wb ? wellbeingNote(wb.score).split('. ')[0] + '.' : 'Take the two-week check below.');
    renderWeek();
    renderEmotionStats();
    renderMilestones();
  }

  function renderWeek() {
    var c = $('week-chart');
    while (c.firstChild) c.removeChild(c.firstChild);
    var today = now();
    var days = [];
    for (var i = 6; i >= 0; i--) {
      var d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i, 12);
      days.push({ key: dayKey(d), label: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()], gain: 0, n: 0 });
    }
    var byKey = {};
    days.forEach(function (d) { byKey[d.key] = d; });
    var weekSessions = [];
    state.sessions.forEach(function (s) {
      var d = byKey[s.day];
      if (d) { d.n++; d.gain += isRated(s) ? Math.max(0, s.gain) : 0; weekSessions.push(s); }
    });
    var max = Math.max(5, Math.max.apply(null, days.map(function (d) { return d.gain; })));
    svg('line', { x1: 10, y1: 150, x2: 330, y2: 150, stroke: 'rgba(34,48,56,.15)', 'stroke-width': 2 }, c);
    days.forEach(function (d, i) {
      var x = 18 + i * 45;
      var h = d.n ? Math.max(10, (d.gain / max) * 110) : 4;
      svg('rect', { x: x, y: 150 - h, width: 32, height: h, rx: 10, fill: d.n ? '#4FA67C' : '#CFE8FF' }, c);
      if (d.n) {
        svg('circle', { cx: x + 16, cy: 150 - h - 12, r: 7, fill: '#FFC857' }, c);
        var v = svg('text', { x: x + 16, y: 150 - h - 24, 'text-anchor': 'middle', 'font-size': 12, 'font-weight': 800, fill: '#2E7D5B' }, c);
        v.textContent = signed(d.gain);
      }
      var t = svg('text', { x: x + 16, y: 172, 'text-anchor': 'middle', 'font-size': 13, 'font-weight': 700, fill: '#4A5A63' }, c);
      t.textContent = d.label;
    });
    setText('week-count', String(weekSessions.length));
    setText('week-avg', signed(avgGain(weekSessions)));
    c.setAttribute('aria-label', 'Calm gain for the last 7 days: ' + days.map(function (d) { return d.label + ' ' + signed(d.gain); }).join(', '));
    // Mood line: 1 (very heavy) low on the chart to 5 (bright) high.
    var moodBy = {};
    state.moods.forEach(function (m) { moodBy[m.day] = m.mood; });
    var pts = [];
    days.forEach(function (d, i) { if (moodBy[d.key]) pts.push([18 + i * 45 + 16, 140 - (moodBy[d.key] - 1) * 28, moodBy[d.key]]); });
    if (pts.length > 1) svg('polyline', { points: pts.map(function (p) { return p[0] + ',' + p[1]; }).join(' '), fill: 'none', stroke: '#F28F6B', 'stroke-width': 3, 'stroke-linejoin': 'round', 'stroke-linecap': 'round', opacity: 0.85 }, c);
    pts.forEach(function (p) { svg('circle', { 'class': 'mood-dot', cx: p[0], cy: p[1], r: 5.5, fill: '#fff', stroke: '#F28F6B', 'stroke-width': 3 }, c); });
    var ins = insights();
    setText('insight-tech', ins.tech);
    setText('insight-time', ins.time);
    setText('insight-mood', moodInsight(days.map(function (d) { return moodBy[d.key]; }).filter(Boolean)));
  }

  function moodInsight(ms) {
    if (ms.length < 3) return 'Check in with your mood each day and your trend will appear here as a coral line.';
    var half = Math.floor(ms.length / 2);
    var avg = function (a) { return a.reduce(function (x, y) { return x + y; }, 0) / a.length; };
    var earlier = avg(ms.slice(0, half)), recent = avg(ms.slice(-half));
    if (recent - earlier >= 0.5) return 'Your days have been getting lighter this week. Lovely to see.';
    if (earlier - recent >= 0.5) return 'This week has felt heavier. Small steps, Kind words and SOS are all here for you.';
    return 'Your mood has been steady this week. Small breaks keep it that way.';
  }

  function insights() {
    var all = ratedOnly(state.sessions);
    if (!all.length) return { tech: 'Take a break or two and we will show you what lifts you most.', time: '' };
    var by = function (keyFn) {
      var m = {};
      all.forEach(function (s) { var k = keyFn(s); var e = m[k] || (m[k] = { n: 0, sum: 0 }); e.n++; e.sum += s.gain; });
      var best = null;
      Object.keys(m).forEach(function (k) { var avg = m[k].sum / m[k].n; if (!best || avg > best.avg) best = { key: k, avg: avg, n: m[k].n }; });
      return best;
    };
    var bt = by(function (s) { return s.technique; });
    var bb = by(function (s) { return bucketOf(s.ts); });
    var tname = TECH[bt.key] ? TECH[bt.key].name : 'Your breaks';
    return {
      tech: tname + ' lifts you most, with an average Calm gain of ' + signed(Math.round(Math.max(0, bt.avg) * 10) / 10) + '.',
      time: bb.key + ' are your brightest time for a break.'
    };
  }

  function renderMe() {
    renderOrg();
    renderFocus();
    setText('me-title', state.name ? state.name + '\'s corner' : 'Your corner');
    renderPlan();
    if (state.goldenHour) $('golden-time').value = state.goldenHour;
    $('golden-clear').hidden = !state.goldenHour;
    // The phone apps schedule a local notification; the website sends a Web Push notification where the browser allows it.
    var webPush = !isNative() && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
    setText('golden-help', state.goldenHour
      ? 'Daily reminder set for ' + state.goldenHour + '. ' + (isNative() || webPush ? 'One gentle reminder arrives each day.' : 'A gentle note appears in the app from that time.')
      : (isNative() || webPush ? 'Pick a daily time for one gentle reminder.' : 'Pick a daily time and a gentle note will appear in the app. On iPhone, add LoosenUp to your home screen to get a daily notification.'));
    renderVoiceButtons();
    renderInstall();
    renderLockCard();
    renderTrusted(false);
  }

  var RENDER = { gift: renderGift, programs: renderPrograms, program: renderProgram, learn: renderLearn, support: renderSupport, safety: renderSafety, reframe: startReframe, sounds: function () {}, wellbeing: renderWellbeing,
    today: renderToday, play: renderPlay, progress: renderProgress, me: renderMe, pick: renderPick, checkin: renderContextChips };

  /* ---------- Golden hour, sharing, install ---------- */

  function nativeNotifications() {
    return isNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
  }
  function scheduleGoldenHour() {
    var LN = nativeNotifications();
    if (!LN) return Promise.resolve(false);
    return LN.cancel({ notifications: [{ id: 1 }] }).catch(function () {}).then(function () {
      if (!state.goldenHour) return false;
      return LN.requestPermissions().then(function (p) {
        if (p && p.display && p.display !== 'granted') { toast('Reminders are off in your settings. The in-app note still works.'); return false; }
        var hm = state.goldenHour.split(':');
        // Two buttons on the reminder go straight to a breath or the mood check-in.
        var types = LN.registerActionTypes ? LN.registerActionTypes({ types: [{ id: 'LU_DAILY', actions: [
          { id: 'breathe', title: tr('Breathe now') }, { id: 'checkin', title: tr('How are you?') }] }] }).catch(function () {}) : Promise.resolve();
        return types.then(function () {
          return LN.schedule({ notifications: [{
            id: 1, title: 'LoosenUp', body: tr('Two calm minutes are here for you whenever you like.'), actionTypeId: 'LU_DAILY',
            schedule: { on: { hour: +hm[0], minute: +hm[1] }, allowWhileIdle: true }
          }] });
        }).then(function () { return true; });
      });
    }).catch(function () { return false; });
  }
  function saveGoldenHour() {
    var v = $('golden-time').value;
    if (!/^\d{2}:\d{2}$/.test(v)) { toast('Pick a time first.'); return; }
    state.goldenHour = v;
    addBadge('golden');
    save();
    scheduleGoldenHour();
    renderMe();
    toast('Daily reminder set for ' + v + '.');
  }
  function clearGoldenHour() {
    state.goldenHour = null;
    save();
    scheduleGoldenHour();
    renderMe();
    toast('Daily reminder is off. You can set it again any time.');
  }

  function shareUrl() { return /^https?:$/.test(location.protocol) && !isNative() && location.hostname !== 'localhost' ? location.origin : PUBLIC_URL; }
  function shareSunbeam() {
    var url = shareUrl();
    var text = 'Two calm minutes that help me feel lighter. Try LoosenUp: ' + GET_URL;
    var rewardShare = function () {
      addBadge('sharer');
      state.referralDay = dayKey(now());
      save();
      toast('Thank you for sharing LoosenUp.');
    };
    var copy = function () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text).then(function () { toast('Link copied. Share it anywhere you like.'); rewardShare(); },
          function () { toast('Share this link: ' + url); });
      }
      toast('Share this link: ' + url);
      return Promise.resolve();
    };
    if (navigator.share) {
      return navigator.share({ title: 'LoosenUp', text: text }).then(rewardShare, function (e) {
        if (e && e.name === 'AbortError') return;
        return copy();
      });
    }
    return copy();
  }

  /* ---------- Links into the app: shared breaks, reminder buttons and home-screen shortcuts ---------- */
  // ?go=breathe | checkin | sos | ex:<id> | game:<id> on the web, or loosenup://go/<target> in the Android app.
  function linkTarget(url) {
    var m = /[?&]go=([^&#]+)/.exec(url || '') || /^loosenup:\/\/go\/([^?#]+)/.exec(url || '');
    return m ? decodeURIComponent(m[1]) : '';
  }
  function targetName(t) {
    var p = String(t || '').split(':');
    if (p[0] === 'ex' && TECH[p[1]]) return TECH[p[1]].name;
    if (p[0] === 'game' && GAMES[p[1]]) return GAMES[p[1]].name;
    if (t === 'game:trace') return 'Trace the square';
    return '';
  }
  function goTarget(t) {
    t = String(t || '').trim();
    if (!t) return false;
    // Someone new arriving from a shared link meets the welcome first, then lands on what was shared.
    if (!state.onboarded) { state.pendingGo = t; save(); return false; }
    var p = t.split(':');
    if (t === 'breathe') breatheNow();
    else if (t === 'checkin') {
      go('today');
      var m = $('mood-card');
      if (m) { if (m.scrollIntoView) m.scrollIntoView({ block: 'center' }); m.classList.remove('glow'); void m.offsetWidth; m.classList.add('glow'); }
    } else if (t === 'sos') openSupport();
    else if (p[0] === 'ex' && TECH[p[1]]) startNow(p[1]);
    else if (t === 'game:trace') go('trace');
    else if (p[0] === 'game' && GAMES[p[1]]) openGame(p[1]);
    else return false;
    return true;
  }
  function openFromLink() {
    var t = linkTarget(location.search);
    if (t && window.history && history.replaceState) {
      var rest = location.search.replace(/([?&])go=[^&#]*&?/, '$1').replace(/[?&]$/, '');
      try { history.replaceState(null, '', location.pathname + rest + location.hash); } catch (e) { /* the link still opens */ }
    }
    if (t) goTarget(t);
    var App = isNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (App) {
      if (App.getLaunchUrl) App.getLaunchUrl().then(function (r) { var x = r && linkTarget(r.url); if (x) goTarget(x); }).catch(function () {});
      if (App.addListener) App.addListener('appUrlOpen', function (e) { var x = linkTarget(e && e.url); if (x) goTarget(x); });
    }
    var LN = nativeNotifications();
    if (LN && LN.addListener) LN.addListener('localNotificationActionPerformed', function (e) {
      var a = e && e.actionId;
      if (a === 'breathe' || a === 'checkin') goTarget(a);
    });
  }
  // Send one exercise or game to a friend: the link opens straight into it.
  function shareBreak(target) {
    var name = targetName(target);
    if (!name) return Promise.resolve(false);
    var url = PUBLIC_URL + '/?go=' + encodeURIComponent(target);
    var text = tr('This helped me feel lighter: ' + name + ', two calm minutes on LoosenUp. Free to try.');
    var done = function () { addBadge('sharer'); save(); toast('Thank you for sharing.'); return true; };
    var copy = function () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text + ' ' + url).then(function () { toast('Link copied. Paste it to a friend.'); return true; },
          function () { toast('Share this link: ' + url); return false; });
      }
      toast('Share this link: ' + url);
      return Promise.resolve(false);
    };
    if (navigator.share) {
      return navigator.share({ title: 'LoosenUp', text: text, url: url }).then(done, function (e) {
        if (e && e.name === 'AbortError') return false;
        return copy();
      });
    }
    return copy();
  }

  /* ---------- What brings you here: a few taps on first open shape For you ---------- */
  var FOCUS = [['anxious', '🌊', 'Feeling anxious'], ['sleep', '🌙', 'Better sleep'], ['work', '💼', 'Calmer workdays'], ['people', '💞', 'Relationships'],
    ['heavy', '☁️', 'Heavy days'], ['exams', '📚', 'Exams'], ['calm', '🍃', 'Just some calm'], ['panic', '🫀', 'Sudden panic']];
  var FOCUS_PLANS = {
    sleep: [['tech:night', 'Slow, sleepy breaths with long breaths out tell your body it can slow down.'], ['tech:tomorrow', 'Set tomorrow down on paper, so your mind can rest tonight.']],
    work: [['tech:desk', 'Let the workday go from your shoulders without leaving your chair.'], ['tech:eyes', 'Give your eyes two minutes away from the screen.']],
    people: [['tech:cooldown', 'Long breaths out help you answer from care.'], ['tech:warmth', 'Send kind wishes to someone you care about.']],
    heavy: [['tech:kind', 'A hand on your heart and a few kind words, with nothing to fix.'], ['game:lantern', 'Light a lantern with each slow breath in, and watch it float away.']],
    exams: [['tech:square', 'Steady breathing before a study round.'], ['game:sort', 'Sort the stones for a tidy, calm break.']],
    anxious: [['tech:sigh', 'A long breath out first, so your body can start to settle.'], ['tech:park', 'Write the worry down and give it a time, so it can wait.']],
    panic: [['tech:panic', 'Five steps for a sudden wave: breathe out slowly, feel the ground, let it pass.'], ['game:pond', 'Tap the water and watch the ripples fade, while your breath slows.']]
  };
  function focusPlan() {
    var fs = (state.focus || []).filter(function (k) { return FOCUS_PLANS[k]; });
    if (!fs.length) return null;
    if (isNight()) return fs.indexOf('sleep') !== -1 ? FOCUS_PLANS.sleep : null;
    return FOCUS_PLANS[fs[dayNum(dayKey(now())) % fs.length]];
  }
  function renderFocus() {
    var groups = document.querySelectorAll('[data-focus-group]');
    for (var g = 0; g < groups.length; g++) {
      var box = groups[g];
      if (!box.children.length) FOCUS.forEach(function (f) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'chip focus-chip';
        b.setAttribute('data-focus', f[0]);
        var ic = document.createElement('span'); ic.setAttribute('aria-hidden', 'true'); ic.textContent = f[1] + ' ';
        b.appendChild(ic);
        b.appendChild(document.createTextNode(f[2]));
        box.appendChild(b);
      });
      var chips = box.querySelectorAll('[data-focus]');
      for (var i = 0; i < chips.length; i++) chips[i].setAttribute('aria-pressed', String((state.focus || []).indexOf(chips[i].getAttribute('data-focus')) !== -1));
    }
  }
  function toggleFocus(k) {
    var f = (state.focus || []).slice();
    var i = f.indexOf(k);
    if (i === -1) f.push(k); else f.splice(i, 1);
    state.focus = f;
    save();
    renderFocus();
    haptic('light');
    return f;
  }
  function renderGift() {
    renderFocus();
    var name = targetName(state.pendingGo);
    setText('gift-go', name ? 'Try ' + name : state.pendingGo === 'breathe' ? 'Breathe now' : 'Start my first break');
  }

  var installEvt = null;
  function isStandalone() { return mm('(display-mode: standalone)') || window.navigator.standalone === true || isNative(); }
  function isIosSafari() {
    var ua = navigator.userAgent || '';
    var ios = /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
    return ios && !/CriOS|FxiOS|EdgiOS/.test(ua);
  }
  function renderIosTip() { $('ios-tip').hidden = !(isIosSafari() && !isStandalone()); }

  function renderInstall() {
    var card = $('install-card');
    if (isNative()) { card.hidden = true; return; }
    card.hidden = false;
    var ua = navigator.userAgent || '';
    var ios = /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
    $('install-btn').hidden = !installEvt;
    if (isStandalone()) setText('install-text', 'LoosenUp is installed. Lovely to have you here.');
    else if (installEvt) setText('install-text', 'Add LoosenUp to your home screen for quick, offline breaks.');
    else if (ios) setText('install-text', 'On iPhone: open loosenup.anchit-tandon.com in Safari, tap Share, then Add to Home Screen.');
    else setText('install-text', 'Open the install page on your phone: Download for Android, or Install on iPhone in Safari.');
  }

  function registerSW() {
    if (!('serviceWorker' in navigator) || isNative() || !/^https?:$/.test(location.protocol)) return;
    var reg = function () { navigator.serviceWorker.register('/sw.js').catch(function () { /* offline support is optional */ }); };
    if (document.readyState === 'complete') reg(); else window.addEventListener('load', reg);
  }

  /* ---------- Play: calm mini-games (every round ends kindly) ---------- */

  var GAMES = {
    pairs: { name: 'Calm Pairs', help: 'Turn two cards. Find the pairs.' },
    catch: { name: 'Sunbeam Catch', help: 'Tap the drifting light.' },
    bloom: { name: 'Breathing Ring', help: 'Hold to breathe in. Let go to breathe out.' },
    pop: { name: 'Bubble Pop', help: 'Pop every bubble. No timer.' },
    sort: { name: 'Colour Sort', help: 'Drag or tap each stone into its bowl.' },
    sand: { name: 'Zen Sand', help: 'Draw slow lines. Watch them soften.' },
    stars: { name: 'Star Connect', help: 'Tap the glowing star.' },
    stack: { name: 'Gentle Stack', help: 'Tap to set each block down. Every block lands.' },
    kind: { name: 'Kind Notes', help: 'Tap three kind words for yourself.' },
    rangoli: { name: 'Rangoli Colours', help: 'Pick a colour, then tap a ring to fill it.' },
    tiles: { name: 'Picture Tiles', help: 'Tap two tiles to swap them. Make the picture whole.' },
    chimes: { name: 'Wind Chimes', help: 'Listen to the chimes, then tap the tune back.' },
    spot: { name: 'Spot the Odd One', help: 'One shape is a little different. Tap it.' },
    count: { name: 'Calm Count', help: 'Tap the numbers in order, from 1 to 16.' },
    lantern: { name: 'Sky Lanterns', help: 'Hold a lantern as you breathe in. It rises when fully lit.' },
    pond: { name: 'Ripple Pond', help: 'Tap the water and watch the ripples fade.' },
    mandala: { name: 'Mirror Mandala', help: 'Draw slow lines. Each one is mirrored all the way round.' }
  };
  var FLOWERS = [['Bright sun', '#FFC857'], ['Moon', '#B9A3F0'], ['Cloud', '#8CC8F0'], ['Wave', '#4FA9C8'], ['Star', '#FFB088'], ['Heart', '#F28FA0']];
  var game = null;

  /* ---------- Guided programmes (LoosenUp Plus after the free days) ---------- */
  // One day opens per calendar day. Each day is a short tip plus one exercise.
  var PROGRAM_FREE_DAYS = 3;
  var PROGRAMS = {
    sleep: { id: 'sleep', name: 'Better sleep in 21 days', color: '#8CA9F0', space: 'sleep',
      desc: 'A gentle 21 day plan for falling asleep more easily and waking up fresher.',
      days: [
        ['Set your anchor', 'Pick one wake time and keep it all week, even on weekends. Tonight, just notice when you feel sleepy.', 'breeze'],
        ['Dim the last hour', 'One hour before bed, lower the lights and the screen brightness. Dim light tells your body it is time to rest.', 'release'],
        ['Park your thoughts', 'Write tomorrow\'s top three tasks on paper before bed, so your mind can set them down.', 'letitout'],
        ['A cool, quiet room', 'Make the room a little cooler and darker tonight. Small changes add up.', 'breeze'],
        ['Long breaths out', 'In bed, breathe out for longer than you breathe in, for a few slow rounds.', 'sigh'],
        ['Tea and coffee earlier', 'Try no tea or coffee after 2pm today and notice how the evening feels.', 'here'],
        ['Look back kindly', 'Notice one night this week that went a little better. What helped?', 'kind'],
        ['Morning light', 'Get ten minutes of daylight soon after waking. It helps set your body clock.', 'breeze'],
        ['The bed is for sleep', 'If you have been awake in bed for a long while, get up and do something calm in dim light, then return.', 'release'],
        ['Soften the body', 'Relax each part of the body, from shoulders to toes, as you lie down.', 'release'],
        ['Screens down', 'Put the phone to charge out of reach of the bed tonight.', 'breeze'],
        ['A worry window', 'Give your thoughts ten minutes on paper in the early evening, so they are not saved for bedtime.', 'letitout'],
        ['Gentle movement', 'A short walk or stretch during the day can make sleep come more easily.', 'here'],
        ['Halfway there', 'Two weeks in. Notice what has changed, even slightly.', 'kind'],
        ['Same time, every day', 'Keep the wake time steady, even after a short night. Your body learns the rhythm.', 'breeze'],
        ['Lighter dinners', 'Try finishing dinner two to three hours before bed.', 'sigh'],
        ['A wind down ritual', 'Choose three calm steps for every night, like washing up, a soft sound and slow breathing.', 'release'],
        ['If you wake at night', 'Keep the lights low, skip the clock, and return to slow breathing.', 'breeze'],
        ['Naps with care', 'If you nap, keep it short and before mid afternoon.', 'here'],
        ['Kind words at night', 'Speak to yourself gently tonight, the way you would to a tired friend.', 'kind'],
        ['Your sleep plan', 'Pick the three habits that helped most and keep them. You did this.', 'sigh']
      ] },
    exam: { id: 'exam', name: 'Exam calm', color: '#FFC857', space: 'everyday',
      desc: 'Two weeks of focus, steady breathing and kind self-talk for students.',
      days: [
        ['Map the next two weeks', 'Write every exam date and topic on one page, so it lives on paper, not in your head.', 'letitout'],
        ['Study in rounds', 'Try 25 minutes of focus, then a 5 minute break away from the screen.', 'desk'],
        ['Breathe before you start', 'Before each study round, take one steady square breath.', 'square'],
        ['Sleep is study time', 'Your memory sorts what you learned while you sleep. Protect at least seven hours.', 'breeze'],
        ['One topic at a time', 'When the list feels long, pick only the next small topic.', 'square'],
        ['Move a little', 'A ten minute walk between study rounds can refresh your focus.', 'here'],
        ['Talk to yourself kindly', 'Swap "I will never get this" for "I am still learning this."', 'kind'],
        ['Practise like the real thing', 'Do one past paper with a timer, then rest.', 'square'],
        ['Fuel and water', 'Keep water nearby and eat regular meals. Your brain runs on them.', 'here'],
        ['When your mind goes blank', 'Put the pen down, take a long breath out, and read the question again slowly.', 'sigh'],
        ['Ask for help early', 'Message a teacher or a friend about one topic you are unsure of.', 'kind'],
        ['Phone in another room', 'Keep the phone out of the room during study rounds.', 'desk'],
        ['The night before', 'Light revision only, pack your things, and wind down early.', 'breeze'],
        ['Exam morning', 'Eat something, reach the hall with time to spare, and take three slow breaths before you begin.', 'sigh']
      ] },
    burnout: { id: 'burnout', name: 'Recovering from burnout', color: '#9ED3C4', space: 'work',
      desc: 'Three weeks to rebuild your energy, set clear limits and rest well.',
      days: [
        ['Name what drains you', 'Write down the three things that take the most energy from you right now.', 'letitout'],
        ['One real break', 'Take one break today away from all screens, even for five minutes.', 'desk'],
        ['A clear end to the day', 'Choose a time to stop work today, and close the laptop then.', 'release'],
        ['Sleep first', 'Protect your sleep tonight. Recovery starts there.', 'breeze'],
        ['Say no to one thing', 'Turn down or postpone one task that can wait.', 'pause'],
        ['Move your body', 'Ten minutes of walking or stretching today.', 'here'],
        ['Notice the small wins', 'Write one thing you handled well this week.', 'kind'],
        ['One task at a time', 'Work on one task for an hour with notifications off.', 'square'],
        ['Lunch away from the desk', 'Eat one meal today without a screen.', 'desk'],
        ['Ask for what you need', 'Tell your manager or a colleague one thing that would help.', 'pause'],
        ['Reconnect', 'Spend time with someone who leaves you feeling lighter.', 'warmth'],
        ['Your energy map', 'Notice the hours when you feel most awake, and plan focused work there.', 'here'],
        ['Slow mornings', 'Start the day without email for the first 30 minutes.', 'breeze'],
        ['Halfway check', 'Compare today with day one. What feels a little lighter?', 'kind'],
        ['Limits in writing', 'Put your working hours on your calendar and your status.', 'pause'],
        ['Something just for you', 'Do one thing today purely because you enjoy it.', 'here'],
        ['Soften the body', 'Let your shoulders and jaw go soft a few times today.', 'release'],
        ['Rest is part of the work', 'Treat rest as part of your job, not a reward for finishing it.', 'breeze'],
        ['Talk it through', 'If heavy days keep coming, talking to a counsellor can really help. Find support lists real options.', 'kind'],
        ['Plan next week', 'Put two short breaks a day into next week\'s calendar.', 'desk'],
        ['Keep what works', 'Choose three habits from these weeks to keep going.', 'sigh']
      ] }
  };
  var PROGRAM_ORDER = ['sleep', 'exam', 'burnout'];
  var currentProgram = null;
  function progState(id) { return (state.programs || {})[id] || null; }
  // Which day (1 based) the person is on, and whether it can be done today.
  function programStatus(id) {
    var p = PROGRAMS[id], ps = progState(id), total = p.days.length;
    if (!ps) return { started: false, day: 1, total: total, doneToday: false, finished: false, locked: false };
    var done = ps.done.length;
    var finished = done >= total;
    var doneToday = ps.lastDay === dayKey(now());
    var day = finished ? total : done + 1;
    var locked = !finished && day > PROGRAM_FREE_DAYS && plusRequired();
    return { started: true, day: day, total: total, done: done, doneToday: doneToday, finished: finished, locked: locked };
  }
  function activeProgram() {
    for (var i = 0; i < PROGRAM_ORDER.length; i++) {
      var st = programStatus(PROGRAM_ORDER[i]);
      if (st.started && !st.finished) return PROGRAM_ORDER[i];
    }
    return null;
  }
  function renderPrograms() {
    var box = $('program-list');
    box.textContent = '';
    PROGRAM_ORDER.forEach(function (id) {
      var p = PROGRAMS[id], st = programStatus(id);
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'program-card';
      b.setAttribute('data-program', id);
      b.style.setProperty('--c', p.color);
      var h = document.createElement('strong'); h.textContent = p.name;
      var d = document.createElement('span'); d.className = 'program-desc'; d.textContent = p.desc;
      var m = document.createElement('span'); m.className = 'program-meta';
      m.textContent = st.finished ? 'Completed' : st.started ? 'Day ' + st.day + ' of ' + st.total : st.total + ' days · first ' + PROGRAM_FREE_DAYS + ' free';
      var bar = document.createElement('span'); bar.className = 'program-bar';
      var fill = document.createElement('i'); fill.style.width = Math.round(100 * (st.done || 0) / st.total) + '%';
      bar.appendChild(fill);
      b.appendChild(h); b.appendChild(d); b.appendChild(m); b.appendChild(bar);
      box.appendChild(b);
    });
  }
  function openProgram(id) {
    if (!PROGRAMS[id]) return;
    currentProgram = id;
    go('program');
  }
  function renderProgram() {
    var id = currentProgram || activeProgram() || 'sleep';
    currentProgram = id;
    var p = PROGRAMS[id], st = programStatus(id);
    $('screen-program').style.setProperty('--c', p.color);
    setText('program-name', p.name);
    setText('program-desc', p.desc);
    var day = p.days[st.day - 1];
    setText('program-day-label', st.finished ? 'All ' + st.total + ' days done' : 'Day ' + st.day + ' of ' + st.total);
    setText('program-day-title', st.finished ? 'You finished ' + p.name : day[0]);
    setText('program-day-tip', st.finished ? 'Keep the habits that helped. You can start again any time.' : day[1]);
    setText('program-day-tech', st.finished ? '' : 'Today\'s practice: ' + TECH[day[2]].name);
    var btn = $('program-start');
    btn.hidden = false;
    if (st.finished) setText('program-start', 'Start again');
    else if (st.doneToday) { btn.hidden = true; }
    else if (st.locked) setText('program-start', 'Unlock with LoosenUp Plus');
    else setText('program-start', st.started ? 'Start today\'s practice' : 'Start day 1');
    $('program-wait').hidden = !(st.doneToday && !st.finished);
    setText('program-wait', 'Done for today. Day ' + st.day + ' opens tomorrow.');
    $('program-paywall').hidden = !plusRequired();
    var dots = $('program-days');
    dots.textContent = '';
    for (var i = 1; i <= st.total; i++) {
      var s = document.createElement('span');
      var done = st.started && i <= (st.done || 0);
      var isToday = !st.finished && i === st.day;
      var paid = i > PROGRAM_FREE_DAYS && plusRequired();
      s.className = 'pday' + (done ? ' done' : '') + (isToday ? ' today' : '') + (paid && !done ? ' paid' : '');
      s.textContent = String(i);
      s.setAttribute('aria-label', 'Day ' + i + (done ? ', done' : isToday ? ', today' : paid ? ', LoosenUp Plus' : ''));
      dots.appendChild(s);
    }
  }
  function startProgramDay() {
    var id = currentProgram, p = PROGRAMS[id], st = programStatus(id);
    if (st.finished) { state.programs[id] = null; delete state.programs[id]; save(); renderProgram(); return 'restart'; }
    if (st.doneToday) return 'wait';
    if (st.locked) { openShop('Day ' + (PROGRAM_FREE_DAYS + 1) + ' onwards of every programme is part of LoosenUp Plus.'); return 'shop'; }
    if (!state.programs) state.programs = {};
    if (!state.programs[id]) state.programs[id] = { started: dayKey(now()), done: [], lastDay: null };
    save();
    var tech = p.days[st.day - 1][2];
    startCheckin('guided', TECH[tech].space || null);
    flow.technique = tech; flow.picked = true; flow.chosen = true; flow.program = { id: id, day: st.day };
    flow.reason = 'Day ' + st.day + ' of ' + p.name + '.';
    return 'started';
  }
  // Called when a break finishes. Marks the programme day done (once per calendar day).
  function completeProgramDay(r) {
    var pr = flow.program;
    flow.program = null;
    if (!pr || !state.programs || !state.programs[pr.id]) return;
    var ps = state.programs[pr.id];
    var dk = dayKey(now());
    if (ps.lastDay === dk || ps.done.indexOf(pr.day) !== -1) return;
    ps.done.push(pr.day);
    ps.lastDay = dk;
    state.xp += 5;
    var total = PROGRAMS[pr.id].days.length;
    r.programNote = ps.done.length >= total ? 'You finished ' + PROGRAMS[pr.id].name + '!' : 'Day ' + pr.day + ' of ' + total + ' done.';
    if (ps.done.length >= total) addBadge('programme', r.newBadges);
    save();
  }
  function renderProgramCard() {
    var id = activeProgram(), card = $('program-today');
    if (!card) return;
    card.hidden = !id;
    if (!id) return;
    var p = PROGRAMS[id], st = programStatus(id);
    card.style.setProperty('--c', p.color);
    card.setAttribute('data-program', id);
    setText('program-today-name', p.name);
    setText('program-today-day', st.doneToday ? 'Day ' + st.done + ' of ' + st.total + ' done. See you tomorrow.' : 'Day ' + st.day + ' of ' + st.total + ': ' + p.days[st.day - 1][0]);
  }

  /* ---------- Organisations: join code, anonymous weekly pulse, support line ---------- */
  // The app only ever sends weekly averages, and only after the person turns sharing on.
  var ORG_API = PUBLIC_URL + '/api/org';
  function orgCall(body) {
    if (typeof fetch !== 'function') return Promise.reject(new Error('offline'));
    return fetch(ORG_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || 'Please try again.'); return j; }, function () { throw new Error('The payment service did not answer. Nothing was charged. Please try again in a moment.'); }); });
  }
  function randomId() {
    var a = new Uint8Array(18);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(a);
    else for (var i = 0; i < a.length; i++) a[i] = Math.floor(Math.random() * 256);
    return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  // A week's averages, from what is already on this phone.
  function weekPulse(week) {
    var ses = state.sessions.filter(function (x) { return weekKey(new Date(x.ts)) === week; });
    var moods = state.moods.filter(function (m) { return weekKey(new Date(m.day + 'T12:00:00')) === week; });
    if (!ses.length && !moods.length) return null;
    var avg = function (a) { return a.length ? Math.round(10 * a.reduce(function (x, y) { return x + y; }, 0) / a.length) / 10 : null; };
    var count = {};
    ses.forEach(function (x) { (x.contexts || [x.context]).forEach(function (c) { if (c) count[c] = (count[c] || 0) + 1; }); });
    var top = Object.keys(count).sort(function (a, b) { return count[b] - count[a]; }).slice(0, 3);
    return { week: week, mood: avg(moods.map(function (m) { return m.mood; })), calmGain: avg(ratedOnly(ses).map(function (x) { return x.gain; })), breaks: ses.length, contexts: top };
  }
  // Sends last week's pulse once, if sharing is on and there is something to share.
  function sendPulse() {
    var o = state.org;
    if (!o || !o.share) return Promise.resolve(false);
    var week = weekKey(new Date(now().getTime() - 7 * 86400000));
    if (o.sentWeek === week) return Promise.resolve(false);
    var p = weekPulse(week);
    if (!p) return Promise.resolve(false);
    if (!o.pass) return Promise.resolve(false); // joined before 2.3: the person joins again in Me
    p.action = 'pulse'; p.code = o.code; p.member = o.member; p.pass = o.pass;
    return orgCall(p).then(function () { state.org.sentWeek = week; save(); return true; }).catch(function () { return false; });
  }
  function joinOrg(code) {
    code = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length < 6) { setText('org-status', 'Add the join code from your organisation.'); return Promise.resolve(false); }
    setText('org-status', 'Checking the code...');
    return orgCall({ action: 'join', code: code }).then(function (j) {
      state.org = { code: j.joinCode, name: j.name, kind: j.kind, supportName: j.supportName || null, supportPhone: j.supportPhone || null, share: false,
        member: j.memberId || randomId(), pass: j.memberPass || null, sentWeek: null };
      save();
      renderOrg();
      setText('org-status', 'You joined ' + j.name + '.');
      return true;
    }).catch(function (e) { setText('org-status', e.message === 'offline' ? 'Connect to the internet to join.' : e.message); return false; });
  }
  function toggleOrgShare() {
    if (!state.org) return;
    state.org.share = !state.org.share;
    save();
    renderOrg();
    if (state.org.share) sendPulse();
  }
  function leaveOrg() { state.org = null; save(); renderOrg(); setText('org-status', 'You left the organisation.'); }
  function renderOrg() {
    var o = state.org;
    if (!$('org-card')) return;
    $('org-join').hidden = !!o;
    $('org-joined').hidden = !o;
    if (o) {
      setText('org-name', o.name);
      setText('org-share', 'Share an anonymous weekly pulse: ' + (o.share ? 'on' : 'off'));
      $('org-share').setAttribute('aria-pressed', String(!!o.share));
    }
    var sos = $('sos-org');
    sos.hidden = !(o && o.supportPhone);
    if (o && o.supportPhone) {
      sos.href = 'tel:' + o.supportPhone.replace(/\s/g, '');
      setText('sos-org', 'Call ' + (o.supportName || o.name) + ' (' + o.supportPhone + ')');
    }
  }

  /* ---------- Real services: book online, or in person in your city ---------- */
  // The list lives in www/partners.js (checked on official sites). Location is used only on
  // this phone to sort nearby places; it is never sent anywhere.
  var partnerFilter = 'all';
  var inPerson = { city: null, here: null };
  function partners() { return window.LoosenUpPartners || { online: [], offline: [] }; }
  function mk(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function partnerMatches(p, f) {
    if (f === 'free') return /^Free/.test(p.price);
    if (f === 'therapy') return /Counselling|Psychology|helpline/i.test(p.type) && !/^AI/.test(p.type);
    if (f === 'psychiatry') return /psychiatry/i.test(p.type);
    if (f === 'hindi') return (p.languages || []).indexOf('Hindi') !== -1;
    return true;
  }
  function partnerCard(p) {
    var c = mk('article', 'partner');
    var head = mk('div', 'partner-head');
    var nm = mk('strong', null, p.name); nm.setAttribute('data-no-tr', '');
    head.appendChild(nm);
    head.appendChild(mk('span', 'partner-type', p.type));
    c.appendChild(head);
    c.appendChild(mk('p', 'partner-desc', p.desc));
    var meta = mk('p', 'partner-meta');
    meta.appendChild(mk('span', 'partner-price', p.price));
    if (p.modes && p.modes.length) meta.appendChild(mk('span', null, p.modes.map(function (m) { return m.charAt(0).toUpperCase() + m.slice(1); }).join(' · ')));
    c.appendChild(meta);
    if (p.languages && p.languages.length) c.appendChild(mk('p', 'fine', p.languages.join(', ')));
    if (p.rating) { var r = mk('p', 'fine partner-rating', p.rating); r.setAttribute('data-no-tr', ''); c.appendChild(r); }
    var a = mk('a', 'btn btn-soft', /^Free/.test(p.price) && /helpline/i.test(p.type) ? 'Open their site' : 'Book on their site');
    a.href = p.url; a.target = '_blank'; a.rel = 'noopener';
    c.appendChild(a);
    return c;
  }

  // Talk to someone: three quick taps (when, how, language and budget), then the three best fits.
  var matchPick = { when: 'now', how: 'phone', lang: 'any', budget: 'free' };
  function lowestPrice(p) {
    if (/^Free/.test(p.price)) return 0;
    var m = /₹\s?([\d,]+)/.exec(p.price || '');
    return m ? +m[1].replace(/,/g, '') : null;
  }
  function matchServices(pick) {
    pick = pick || matchPick;
    var all = partners().online.filter(function (p) { return !/^AI/.test(p.type); });
    var fits = function (p, strictHow) {
      var price = lowestPrice(p);
      if (pick.budget === 'free' && price !== 0) return false;
      if (pick.budget === 'low' && !(price !== null && price <= 1000)) return false;
      if (pick.lang === 'hindi' && (p.languages || []).indexOf('Hindi') === -1) return false;
      if (strictHow && (p.modes || []).indexOf(pick.how) === -1) return false;
      return true;
    };
    var score = function (p) {
      var sc = 0, open247 = /24x7/.test(p.desc || '');
      if (pick.when === 'now') sc += open247 ? 3 : /helpline/i.test(p.type) ? 1 : 0;
      else sc += /helpline/i.test(p.type) ? 0 : 2;
      if ((p.modes || []).indexOf(pick.how) !== -1) sc += 2;
      if ((p.languages || []).indexOf('Hindi') !== -1) sc += 0.5;
      return sc;
    };
    var strict = all.filter(function (p) { return fits(p, true); });
    var loose = all.filter(function (p) { return strict.indexOf(p) === -1 && fits(p, false); });
    var byScore = function (a, b) { return score(b) - score(a); };
    var top = strict.sort(byScore).slice(0, 3);
    var relaxed = top.length < 3;
    if (relaxed) top = top.concat(loose.sort(byScore).slice(0, 3 - top.length));
    return { list: top, relaxed: relaxed && top.length > strict.length };
  }
  function renderMatch() {
    var box = $('match-list');
    if (!box) return;
    var chips = document.querySelectorAll('[data-match]');
    for (var i = 0; i < chips.length; i++) { var kv = chips[i].getAttribute('data-match').split(':'); chips[i].setAttribute('aria-pressed', String(matchPick[kv[0]] === kv[1])); }
    var m = matchServices();
    box.textContent = '';
    m.list.forEach(function (p) { box.appendChild(partnerCard(p)); });
    setText('match-note', !m.list.length ? 'Nothing fits all of that yet. Try Any price, or call Tele-MANAS on 14416, free and open 24x7.'
      : m.relaxed ? 'Some of these talk in a different way than you picked.' : (matchPick.when === 'now' ? 'Open now, or open 24x7.' : 'Bookable this week.'));
  }
  function openFold(id) {
    var d = $(id);
    if (!d) return;
    d.open = true;
    if (d.scrollIntoView) d.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function renderPartners() {
    var box = $('partner-list');
    if (!box) return;
    box.textContent = '';
    var list = partners().online.filter(function (p) { return partnerMatches(p, partnerFilter); });
    list.forEach(function (p) { box.appendChild(partnerCard(p)); });
    if (!list.length) box.appendChild(mk('p', 'muted', 'Nothing matches that filter yet.'));
    setText('partner-note', 'LoosenUp is not paid by these services. Details were checked on their official sites on ' + partners().checked + '; confirm prices before you book.');
    var chips = document.querySelectorAll('[data-pfilter]');
    for (var i = 0; i < chips.length; i++) chips[i].setAttribute('aria-pressed', String(chips[i].getAttribute('data-pfilter') === partnerFilter));
  }
  function km(a, b) {
    var R = 6371, rad = Math.PI / 180;
    var dLat = (b.lat - a.lat) * rad, dLon = (b.lon - a.lon) * rad;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * R * Math.asin(Math.sqrt(h));
  }
  function cities() { var s = []; partners().offline.forEach(function (o) { if (s.indexOf(o.city) === -1) s.push(o.city); }); return s; }
  function nearestCity(here) {
    var best = null;
    partners().offline.forEach(function (o) { var d = km(here, o); if (!best || d < best.d) best = { city: o.city, d: d }; });
    return best;
  }
  function renderInPerson() {
    var sel = $('inperson-city');
    if (!sel) return;
    if (!sel.options.length) {
      var none = mk('option', null, 'Choose a city'); none.value = ''; sel.appendChild(none);
      cities().forEach(function (c) { var o = mk('option', null, c); o.value = c; sel.appendChild(o); });
    }
    sel.value = inPerson.city || '';
    var box = $('inperson-list');
    box.textContent = '';
    if (!inPerson.city) return;
    var here = inPerson.here;
    var list = partners().offline.filter(function (o) { return o.city === inPerson.city; })
      .map(function (o) { return { o: o, d: here ? km(here, o) : null }; })
      .sort(function (a, b) { return a.d == null ? 0 : a.d - b.d; });
    list.forEach(function (x) {
      var o = x.o, c = mk('article', 'partner');
      var head = mk('div', 'partner-head');
      var nm = mk('strong', null, o.name); nm.setAttribute('data-no-tr', '');
      head.appendChild(nm);
      head.appendChild(mk('span', 'partner-type', o.type));
      c.appendChild(head);
      var ad = mk('p', 'partner-desc', o.address); ad.setAttribute('data-no-tr', ''); c.appendChild(ad);
      var meta = mk('p', 'partner-meta');
      meta.appendChild(mk('span', 'partner-price', o.cost));
      if (x.d != null) meta.appendChild(mk('span', null, (x.d < 10 ? x.d.toFixed(1) : Math.round(x.d)) + ' km away'));
      c.appendChild(meta);
      var row = mk('div', 'partner-actions');
      if (o.phone) { var call = mk('a', 'btn btn-soft', 'Call'); call.href = 'tel:' + o.phone.replace(/[^\d+]/g, ''); row.appendChild(call); }
      var dir = mk('a', 'btn btn-soft', 'Directions');
      dir.href = isIos() ? 'https://maps.apple.com/?daddr=' + o.lat + ',' + o.lon : 'https://www.google.com/maps/dir/?api=1&destination=' + o.lat + ',' + o.lon;
      dir.target = '_blank'; dir.rel = 'noopener'; row.appendChild(dir);
      var site = mk('a', 'btn btn-ghost', 'Website'); site.href = o.url; site.target = '_blank'; site.rel = 'noopener'; row.appendChild(site);
      c.appendChild(row);
      box.appendChild(c);
    });
  }
  function setCity(city) { inPerson.city = city || null; renderInPerson(); }
  function locateInPerson() {
    if (!navigator.geolocation) { setText('inperson-status', 'Location is not available here. Choose a city instead.'); return; }
    setText('inperson-status', 'Finding places near you...');
    navigator.geolocation.getCurrentPosition(function (pos) {
      var here = { lat: pos.coords.latitude, lon: pos.coords.longitude };
      useLocation(here);
    }, function () { setText('inperson-status', 'Location is off. Choose a city instead.'); }, { timeout: 10000, maximumAge: 600000 });
  }
  function useLocation(here) {
    var n = nearestCity(here);
    inPerson.here = here;
    if (n && n.d < 120) { setText('inperson-status', 'Showing ' + n.city + ', nearest first.'); setCity(n.city); }
    else { setText('inperson-status', 'No listed city is close by yet. The map search below finds options near you.'); setCity(null); }
  }


  /* ---------- Emotion meter: what else is there, and how strongly ---------- */
  // Each tap cycles the intensity: a little (1), quite (2), very (3), then off.
  var EMOTIONS = [
    ['angry', 'Angry', '😠', 'cooldown', 'Long breaths out help anger cool.'],
    ['worried', 'Anxious', '😟', 'square', 'A steady square breath settles an anxious mind.'],
    ['sad', 'Sad', '😢', 'kind', 'Kind words help on a sad day.'],
    ['tired', 'Tired', '🥱', 'sigh', 'Two quick sighs can lift low energy.'],
    ['lonely', 'Lonely', '🥺', 'warmth', 'Warm wishes help you feel closer to others.'],
    ['overwhelmed', 'Overwhelmed', '😵‍💫', 'here', 'Here and now brings you back to one thing at a time.'],
    ['frustrated', 'Frustrated', '😤', 'pause', 'Pause before replying helps frustration pass.'],
    ['restless', 'Restless', '😬', 'release', 'Soft release lets tense muscles go.'],
    ['harsh', 'Hard on myself', '😞', 'kind', 'Kind words help when your inner voice is harsh.'],
    ['flat', 'Flat', '😑', 'lift', 'A gentle lift wakes the body a little.'],
    ['racing', 'Mind racing', '🌀', 'tomorrow', 'Writing tomorrow down helps a busy mind rest.'],
    ['calm', 'Calm', '😌', null], ['happy', 'Happy', '😄', null], ['grateful', 'Grateful', '🙏', null],
    ['hopeful', 'Hopeful', '🌤️', null], ['loved', 'Loved', '🥰', null], ['energetic', 'Energetic', '⚡', null]
  ];
  var EMO_LEVEL = [null, 'a little', 'quite', 'very'];
  function todayEmotions() {
    var dk = dayKey(now());
    if (!state.emotions) state.emotions = [];
    for (var i = 0; i < state.emotions.length; i++) if (state.emotions[i].day === dk) return state.emotions[i];
    var e = { day: dk, e: {} };
    state.emotions.push(e);
    if (state.emotions.length > 400) state.emotions = state.emotions.slice(-400);
    return e;
  }
  function setEmotion(key) {
    var t = todayEmotions();
    var lv = ((t.e[key] || 0) + 1) % 4;
    if (lv) t.e[key] = lv; else delete t.e[key];
    save();
    renderEmotions();
    haptic('light');
    return lv;
  }
  function renderEmotions() {
    var box = $('emotions');
    if (!box) return;
    var t = todayEmotions();
    box.textContent = '';
    EMOTIONS.forEach(function (em) {
      var lv = t.e[em[0]] || 0;
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'emo' + (em[3] ? ' hard' : ' good');
      b.setAttribute('data-emotion', em[0]);
      b.setAttribute('data-level', String(lv));
      b.setAttribute('aria-pressed', String(!!lv));
      b.setAttribute('aria-label', em[1] + (lv ? ', ' + EMO_LEVEL[lv] : ''));
      var f = document.createElement('span'); f.className = 'emo-face'; f.setAttribute('aria-hidden', 'true'); f.textContent = em[2];
      var n = document.createElement('span'); n.className = 'emo-name'; n.textContent = em[1];
      var d = document.createElement('span'); d.className = 'emo-dots'; d.setAttribute('aria-hidden', 'true');
      for (var k = 1; k <= 3; k++) { var i = document.createElement('i'); if (k <= lv) i.className = 'on'; d.appendChild(i); }
      b.appendChild(f); b.appendChild(n); b.appendChild(d);
      box.appendChild(b);
    });
    renderForYou();
  }
  /* ---------- For you: a short plan built around what you feel (www/feelings.js) ---------- */
  // Acknowledge first, settle the body (or lift it gently when energy is low), shift attention or
  // meaning, then end on a small win. Progress is kept for the day, so each step leads to the next.
  var FEEL = window.LoosenUpFeelings || { feelings: {}, byTime: {}, order: [], nightAsRacing: [] };
  var GAME_MIN = { pairs: 2, catch: 1, bloom: 1, pop: 1, sort: 1, sand: 1, stars: 2, stack: 1, kind: 1, rangoli: 2, tiles: 2, chimes: 2, spot: 1, count: 1, lantern: 1, pond: 1, mandala: 1 };
  var EMO_BY_KEY = {};
  EMOTIONS.forEach(function (em) { EMO_BY_KEY[em[0]] = em; });
  function isNight() { return bucketOf(now().getTime()) === 'Quiet nights'; }
  function strongestIn(t, hard) {
    var best = null;
    FEEL.order.forEach(function (k) {
      var em = EMO_BY_KEY[k];
      if (!em || !!em[3] !== hard) return;
      var lv = t[k] || 0;
      if (lv && (!best || lv > best.lv)) best = { k: k, lv: lv };
    });
    return best && best.k;
  }
  // Crying leads, then the strongest heavy feeling, then the mood, then good feelings to savour.
  function leadFeeling() {
    var m = todayMood();
    if (m === 1) return 'crying';
    var t = todayEmotions().e;
    var hard = strongestIn(t, true);
    if (hard) return isNight() && FEEL.nightAsRacing.indexOf(hard) !== -1 ? 'racing' : hard;
    if (m === 2) return 'sad';
    var good = strongestIn(t, false);
    if (good) return good;
    if (m === 5) return 'happy';
    if (m === 4) return 'calm';
    return m === 3 ? 'okay' : 'unknown';
  }
  function feelPlan() {
    var key = leadFeeling();
    var f = FEEL.feelings[key] || FEEL.feelings.unknown || { hear: [''], close: '', games: [], never: [] };
    var dk = dayKey(now());
    var st = state.feelPlan;
    if (!st || st.day !== dk || st.key !== key) st = state.feelPlan = { day: dk, key: key, alt: false, done: [] };
    var steps = (f.plan ? (st.alt && f.alt ? f.alt : f.plan) : focusPlan() || FEEL.byTime[bucketOf(now().getTime())]) || [];
    // Nothing bright or fast at night.
    if (isNight()) steps = steps.map(function (x) { return x[0] === 'game:catch' ? ['game:bloom', 'Six slow breaths with the ring.'] : x; });
    var next = -1;
    for (var i = 0; i < steps.length; i++) if (st.done.indexOf(steps[i][0]) === -1) { next = i; break; }
    return { key: key, f: f, steps: steps, next: next, alt: st.alt, hasAlt: !!(f.plan && f.alt), hear: f.hear[dayNum(dk) % f.hear.length] };
  }
  function stepInfo(ref) {
    var p = ref.split(':'), id = p[1];
    if (p[0] === 'tech' && TECH[id]) return { name: TECH[id].name, min: id === 'quick' ? 1 : (state.lengthMin || 2), attr: ['data-now', id], go: 'Start' };
    if (p[0] === 'game' && GAMES[id]) return { name: GAMES[id].name, min: GAME_MIN[id] || 1, attr: ['data-game', id], go: 'Play' };
    if (ref === 'more:trace') return { name: 'Trace the square', min: 1, attr: ['data-more', 'trace'], go: 'Play' };
    if (ref === 'more:sleep') return { name: 'Guided sleep', min: 10, attr: ['data-more', 'sleep'], go: 'Start' };
    if (ref === 'step') return { name: 'Small step', min: 1, attr: ['data-feel', 'step'], go: 'I did it' };
    if (ref === 'jar') return { name: 'Good things jar', min: 1, attr: ['data-feel', 'jar'], go: 'Add a good thing' };
    if (ref === 'sos') return { name: 'Talk to someone', min: 1, attr: ['data-feel', 'sos'], go: 'Open support' };
    return null;
  }
  var ACT_ATTRS = ['data-now', 'data-game', 'data-more', 'data-feel'];
  function setAction(btn, info) {
    ACT_ATTRS.forEach(function (a) { btn.removeAttribute(a); });
    if (info) btn.setAttribute(info.attr[0], info.attr[1]);
  }
  function forYou() {
    var p = feelPlan();
    var s = p.next === -1 ? null : p.steps[p.next];
    return { key: p.key, id: s && s[0].indexOf('tech:') === 0 ? s[0].slice(5) : null, step: s && s[0], why: s ? s[1] : p.f.close, hear: p.hear, done: p.next === -1 };
  }
  function renderForYou() {
    if (!$('for-you')) return;
    var p = feelPlan();
    var list = $('for-you-plan');
    list.textContent = '';
    p.steps.forEach(function (x, i) {
      var info = stepInfo(x[0]);
      if (!info) return;
      var li = document.createElement('li');
      var done = state.feelPlan.done.indexOf(x[0]) !== -1;
      li.className = done ? 'done' : i === p.next ? 'now' : '';
      li.textContent = tr(info.name + ', ' + info.min + ' min');
      if (done) li.setAttribute('aria-label', tr(info.name + ', done'));
      list.appendChild(li);
    });
    list.hidden = p.steps.length < 2;
    var btn = $('for-you-btn');
    if (p.next === -1) {
      setText('for-you-hear', p.f.close);
      setText('for-you-name', 'All done for now');
      setText('for-you-why', 'Notice how you feel now. You can check in again below.');
      setAction(btn, { attr: ['data-feel', 'again'] });
      setText('for-you-btn', 'Start again');
    } else {
      var x = p.steps[p.next], info = stepInfo(x[0]);
      setText('for-you-hear', p.hear);
      setText('for-you-name', info.name + ', ' + info.min + ' min');
      setText('for-you-why', x[0] === 'step' ? x[1] + ' ' + currentStep() : x[1]);
      setAction(btn, info);
      setText('for-you-btn', info.go);
    }
    $('for-you-alt').hidden = !p.hasAlt || p.next === -1;
    setText('for-you-alt', p.alt ? 'Back to the first idea' : 'Something else');
    renderGameRow(p);
  }
  // Every game, in the order that suits the feeling, without the ones that tend to work against it.
  var ALL_GAMES = ['pairs', 'pop', 'bloom', 'sort', 'sand', 'stars', 'stack', 'kind', 'rangoli', 'tiles', 'chimes', 'spot', 'count', 'lantern', 'pond', 'mandala', 'catch', 'trace'];
  function gameRank(p) {
    p = p || feelPlan();
    var never = (p.f.never || []).concat(isNight() ? ['catch'] : []);
    var rank = p.steps.filter(function (x) { return /^(game|more):/.test(x[0]); }).map(function (x) { return x[0].split(':')[1]; }).concat(p.f.games || [], ALL_GAMES);
    var out = [];
    rank.forEach(function (id) { if (ALL_GAMES.indexOf(id) !== -1 && never.indexOf(id) === -1 && out.indexOf(id) === -1) out.push(id); });
    return out;
  }
  // Today's games: a swipeable row with the best fit first.
  function renderGameRow(p) {
    var row = document.querySelector('#screen-today .game-row');
    if (!row) return;
    var idOf = function (t) { return t.getAttribute('data-game') || t.getAttribute('data-more'); };
    var rank = gameRank(p);
    var tiles = [].slice.call(row.querySelectorAll('.game-tile'));
    tiles.sort(function (a, b) {
      var ra = rank.indexOf(idOf(a)), rb = rank.indexOf(idOf(b));
      return (ra === -1 ? 99 : ra) - (rb === -1 ? 99 : rb);
    });
    tiles.forEach(function (t) {
      row.appendChild(t);
      t.hidden = rank.indexOf(idOf(t)) === -1;
    });
    row.scrollLeft = 0;
    setText('games-title', p.key === 'unknown' || p.key === 'okay' ? 'Play a calm game' : 'Games for how you feel');
  }
  // After a game: one tap into another that suits the feeling, preferring ones not played yet today.
  var playedGames = [];
  function renderNextGame(id) {
    var b = $('game-next-game');
    if (!b) return null;
    var rank = gameRank().filter(function (g) { return g !== id; });
    var fresh = rank.filter(function (g) { return playedGames.indexOf(g) === -1; });
    var next = fresh[0] || rank[0] || null;
    b.hidden = !next;
    setAction(b, next && { attr: next === 'trace' ? ['data-more', 'trace'] : ['data-game', next] });
    if (next) setText('game-next-game', 'Try ' + (next === 'trace' ? 'Trace the square' : GAMES[next].name));
    return next;
  }
  // Score line plus a thin progress bar. No share hides the bar.
  function gameProgress(text, share) {
    setText('game-score', text);
    var bar = $('game-bar');
    if (!bar) return;
    bar.hidden = share == null;
    if (share != null) $('game-bar-fill').style.width = Math.round(Math.max(0, Math.min(1, share)) * 100) + '%';
  }
  // A finished exercise, game or step moves the plan on.
  function planDone(ref) {
    var p = feelPlan();
    if (!p.steps.some(function (x) { return x[0] === ref; }) || state.feelPlan.done.indexOf(ref) !== -1) return false;
    state.feelPlan.done.push(ref);
    save();
    renderForYou();
    return true;
  }
  // After a step: offer the next one, or the closing line when the plan is complete.
  function renderPlanNext(id, advanced) {
    var b = $(id);
    if (!b) return null;
    var p = feelPlan();
    var n = advanced && p.next !== -1 ? stepInfo(p.steps[p.next][0]) : null;
    b.hidden = !n;
    setAction(b, n);
    if (n) setText(id, 'Next for you: ' + n.name);
    return advanced && p.next === -1 ? p.f.close : null;
  }
  function feelAction(a) {
    if (a === 'step') doStep();
    else if (a === 'jar') openJar();
    else if (a === 'sos') { planDone('sos'); openSupport(); }
    else if (a === 'again') { state.feelPlan.done = []; save(); renderForYou(); }
  }
  function toggleAlt() {
    feelPlan();
    state.feelPlan.alt = !state.feelPlan.alt;
    save();
    renderForYou();
    haptic('light');
  }
  // One tap from a card: straight into the guided exercise, with the optional before rating at the end.
  function startNow(id) {
    if (!TECH[id]) return 'unknown';
    if (id === 'quick') return breatheNow();
    if (TECH[id].kind === 'journal') { startPractice(id); return 'checkin'; }
    closeSheets(true);
    flow = { mode: 'now', before: null, beforeTap: null, context: 'Just a quick lift', contexts: ['Just a quick lift'], technique: id, space: null };
    return beginBreak(id);
  }
  // Last 7 days: how often and how strongly each emotion showed up, with the week before for a trend.
  function emotionStats() {
    var end = dayNum(dayKey(now()));
    var out = {};
    (state.emotions || []).forEach(function (row) {
      var age = end - dayNum(row.day);
      Object.keys(row.e).forEach(function (k) {
        var o = out[k] || (out[k] = { days: 0, sum: 0, prevDays: 0, prevSum: 0 });
        if (age >= 0 && age < 7) { o.days++; o.sum += row.e[k]; }
        else if (age >= 7 && age < 14) { o.prevDays++; o.prevSum += row.e[k]; }
      });
    });
    return EMOTIONS.filter(function (em) { return out[em[0]] && out[em[0]].days; }).map(function (em) {
      var o = out[em[0]];
      var score = o.sum, prev = o.prevSum;
      return { key: em[0], name: em[1], face: em[2], hard: !!em[3], days: o.days, avg: Math.round(10 * o.sum / o.days) / 10,
        score: score, trend: !o.prevDays ? 'new' : score < prev ? 'down' : score > prev ? 'up' : 'same' };
    }).sort(function (a, b) { return b.score - a.score; });
  }
  function renderEmotionStats() {
    var box = $('emo-stats');
    if (!box) return;
    box.textContent = '';
    var st = emotionStats();
    $('emo-empty').hidden = !!st.length;
    var max = Math.max.apply(null, [3].concat(st.map(function (x) { return x.score; })));
    st.forEach(function (x) {
      var row = document.createElement('div');
      row.className = 'emo-row ' + (x.hard ? 'hard' : 'good');
      var l = document.createElement('span'); l.className = 'emo-row-name'; l.textContent = x.face + ' ' + x.name;
      var bar = document.createElement('span'); bar.className = 'emo-bar';
      var fill = document.createElement('i'); fill.style.width = Math.round(100 * x.score / max) + '%'; bar.appendChild(fill);
      var meta = document.createElement('span'); meta.className = 'emo-row-meta';
      var arrow = x.trend === 'down' ? (x.hard ? ' · easing' : ' · less') : x.trend === 'up' ? (x.hard ? ' · rising' : ' · more') : '';
      meta.textContent = plural(x.days, 'day', 'days') + arrow;
      row.appendChild(l); row.appendChild(bar); row.appendChild(meta);
      box.appendChild(row);
    });
  }

  /* ---------- Calm: breathing, games and sounds in one screen ---------- */
  var SEGS = ['breathe', 'games', 'sounds'];
  var calmSeg = 'breathe';
  var BREATH_LIST = ['quick', 'panic', 'sigh', 'breeze', 'wave', 'square', 'cooldown', 'hum', 'nadi', 'night'];
  var MIND_LIST = ['here', 'name', 'release', 'shake', 'eyes', 'chai', 'stretch', 'letitout', 'park', 'tomorrow', 'kind', 'friend', 'savour', 'lift', 'hope', 'reach', 'desk', 'pause', 'warmth'];
  function setSeg(seg, focus) {
    if (SEGS.indexOf(seg) === -1) seg = 'breathe';
    calmSeg = seg;
    var bar = document.querySelector('#screen-play .seg');
    if (!bar) return;
    bar.setAttribute('data-active', seg);
    SEGS.forEach(function (k) {
      var on = k === seg;
      $('seg-' + k).setAttribute('aria-selected', String(on));
      $('seg-' + k).tabIndex = on ? 0 : -1;
      $('panel-' + k).hidden = !on;
    });
    if (focus) $('seg-' + seg).focus();
  }
  function stepSeg(dir) {
    var i = SEGS.indexOf(calmSeg) + dir;
    if (i >= 0 && i < SEGS.length) { setSeg(SEGS[i], true); haptic('light'); }
  }
  function practiceCard(id) {
    var t = TECH[id];
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'practice' + (id === 'quick' || id === 'panic' ? ' featured' : '');
    b.setAttribute('data-practice', id);
    b.style.setProperty('--c', t.color);
    var orb = document.createElement('span'); orb.className = 'practice-orb'; orb.setAttribute('aria-hidden', 'true');
    var body = document.createElement('span'); body.className = 'practice-body';
    var nm = document.createElement('strong'); nm.textContent = t.name;
    var ds = document.createElement('span'); ds.className = 'practice-desc'; ds.textContent = t.desc;
    var meta = document.createElement('span'); meta.className = 'practice-meta';
    if (!isUnlocked(id)) {
      b.disabled = true;
      meta.textContent = 'Opens in ' + plural(TECH[id].unlockAt - breaksDone(), 'more break', 'more breaks');
    } else if (id === 'quick') meta.textContent = '1 min · Always free';
    else meta.textContent = Math.round(t.seconds / 60) + ' min' + (t.space ? ' · ' + SPACES[t.space].name : '');
    body.appendChild(nm); body.appendChild(ds); body.appendChild(meta);
    b.appendChild(orb); b.appendChild(body);
    return b;
  }
  function renderPractice() {
    [['practice-breath', BREATH_LIST], ['practice-mind', MIND_LIST]].forEach(function (g) {
      var box = $(g[0]);
      box.textContent = '';
      g[1].forEach(function (id) { box.appendChild(practiceCard(id)); });
    });
  }
  function startPractice(id) {
    if (!TECH[id] || !isUnlocked(id)) return;
    if (id === 'quick') { startCheckin('quick'); flow.chosen = true; return; }
    startCheckin('guided', TECH[id].space || null);
    flow.technique = id; flow.picked = true; flow.chosen = true; flow.reason = 'You picked this one yourself.';
  }
  function bindCalmGestures() {
    var bar = document.querySelector('#screen-play .seg');
    bar.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight') { e.preventDefault(); stepSeg(1); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); stepSeg(-1); }
    });
    var scr = $('screen-play'), x0 = null, y0 = 0;
    scr.addEventListener('touchstart', function (e) {
      var t = e.target;
      x0 = t.closest && t.closest('input, .seg') ? null : e.touches[0].clientX;
      y0 = e.touches[0].clientY;
    }, { passive: true });
    scr.addEventListener('touchend', function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) stepSeg(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  function renderPlay() {
    renderPractice();
    renderNewTags();
    setSeg(calmSeg);
    var dk = dayKey(now());
    var played = state.games.day === dk ? state.games.count : 0;
    setText('play-note', played ? 'Play as long as you like. There is nothing to rush.' : 'Short, gentle games for a busy mind.');
  }

  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rng() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  function openGame(id, opts) {
    if (!GAMES[id]) return false;
    opts = opts || {};
    stopGame();
    game = { id: id, timers: [], done: false, daily: !!opts.daily };
    if (GAME_SETS[id]) game.set = opts.set != null ? opts.set % GAME_SETS[id] : nextSet(id);
    if (playedGames.indexOf(id) === -1) playedGames.push(id);
    setText('game-title', GAMES[id].name);
    setText('game-help', GAMES[id].help);
    gameProgress('', null);
    $('game-done').hidden = true;
    $('game-keep').hidden = true;
    $('game-plus').hidden = true;
    setText('game-kicker', game.daily ? 'Today\'s game' : 'Play');
    var stage = $('game-stage');
    stage.textContent = '';
    go('game');
    ({ pairs: startPairs, catch: startCatch, bloom: startBloom, pop: startPop, sort: startSort, sand: startSand, stars: startStars, stack: startStack, kind: startKind,
      rangoli: startRangoli, tiles: startTiles, chimes: startChimes, spot: startSpot, count: startCount, lantern: startLantern, pond: startPond, mandala: startMandala })[id](stage);
    return true;
  }

  function stopGame() {
    if (!game) return;
    game.timers.forEach(function (t) { clearInterval(t); clearTimeout(t); });
    if (game.raf && window.cancelAnimationFrame) window.cancelAnimationFrame(game.raf);
    game = null;
  }

  function finishGame(title, text, best) {
    if (!game || game.done) return;
    game.done = true;
    game.timers.forEach(function (t) { clearInterval(t); clearTimeout(t); });
    var dk = dayKey(now());
    if (state.games.day !== dk) state.games = { day: dk, count: 0 };
    var rewarded = state.games.count < DAILY_GAME_REWARDS;
    if (rewarded) { state.games.count++; state.xp += GAME_XP; }
    var nb = [];
    addBadge('playful', nb);
    if (best) best();
    if (!state.gamePlays) state.gamePlays = {};
    state.gamePlays[game.id] = (state.gamePlays[game.id] || 0) + 1;
    if (SHELF_GAMES.every(function (k) { return state.gamePlays[k]; })) addBadge('collector', nb);
    if (GAME_SETS[game.id] && !game.daily) { if (!state.gameLevel) state.gameLevel = {}; state.gameLevel[game.id] = (game.set + 1) % openSets(game.id); }
    var dailyNow = game.daily && game.id === dailyGame().id && markDaily(nb);
    save();
    renderSeedPill();
    setText('game-done-title', title);
    setText('game-done-text', text);
    var close = renderPlanNext('game-plan-next', planDone('game:' + game.id));
    if (close) setText('game-done-text', close);
    renderNextGame(game.id);
    renderGamePlus();
    if (dailyNow) toast('Today\'s game is done. ' + plural(state.daily.days, 'day', 'days') + ' played so far.');
    $('game-done').hidden = false;
    var again = $('game-again');
    if (again && again.focus) again.focus();
  }

  // Calm Pairs: a gentle memory match.
  // Calm Pairs card faces: simple calm symbols (sun, moon, cloud, wave, star, heart).
  var SYMBOL_PATHS = [
    'M20 11a9 9 0 1 1 0 18 9 9 0 0 1 0-18zM20 3v4M20 33v4M3 20h4M33 20h4M8 8l3 3M29 29l3 3M8 32l3-3M29 11l3-3',
    'M25 7a13 13 0 1 0 8 23 11 11 0 0 1-8-23z',
    'M12 29a7 7 0 0 1 0-14 9 9 0 0 1 17-2 7 7 0 0 1 0 16z',
    'M4 17c4-4 8-4 12 0s8 4 12 0 8-4 8-4M4 26c4-4 8-4 12 0s8 4 12 0 8-4 8-4',
    'M20 4l4.7 10 10.8 1.2-8 7.3 2.3 10.6L20 27.6l-9.8 5.5 2.3-10.6-8-7.3 10.8-1.2z',
    'M20 34S6 25 6 15a7 7 0 0 1 14-2 7 7 0 0 1 14 2c0 10-14 19-14 19z'
  ];
  function flowerSvg(color, kind) {
    var s0 = document.createElementNS(SVGNS, 'svg');
    s0.setAttribute('viewBox', '0 0 40 40');
    s0.setAttribute('aria-hidden', 'true');
    var stroke = kind === 0 || kind === 3;
    svg('path', { d: SYMBOL_PATHS[kind || 0], fill: stroke ? (kind === 0 ? color : 'none') : color, stroke: color, 'stroke-width': stroke ? 3 : 1.5, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, s0);
    return s0;
  }
  function startPairs(stage) {
    var deck = shuffle([0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5]).map(function (k) { return { kind: k, open: false, done: false }; });
    game.deck = deck;
    game.moves = 0;
    game.openIdx = [];
    var grid = document.createElement('div');
    grid.className = 'pairs';
    deck.forEach(function (c, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'pcard';
      b.setAttribute('data-card', String(i));
      b.setAttribute('aria-label', 'Card ' + (i + 1) + ', face down');
      b.appendChild(flowerSvg(FLOWERS[c.kind][1], c.kind));
      grid.appendChild(b);
    });
    stage.appendChild(grid);
    updatePairsScore();
  }
  function updatePairsScore() {
    var matched = game.deck.filter(function (c) { return c.done; }).length / 2;
    gameProgress(matched + ' of 6 pairs', matched / 6);
  }
  function flipCard(i) {
    if (!game || game.id !== 'pairs' || game.done) return;
    var c = game.deck[i];
    if (!c || c.open || c.done || game.openIdx.length >= 2) return;
    c.open = true;
    game.openIdx.push(i);
    paintCard(i);
    if (game.openIdx.length === 2) {
      game.moves++;
      var a = game.deck[game.openIdx[0]], b = game.deck[game.openIdx[1]];
      if (a.kind === b.kind) {
        a.done = b.done = true; a.open = b.open = false;
        var pair = game.openIdx; game.openIdx = [];
        pair.forEach(paintCard);
        updatePairsScore();
        if (game.deck.every(function (x) { return x.done; })) {
          var moves = game.moves;
          var prev = state.gameBest.pairs;
          finishGame('All pairs matched', 'You matched 6 pairs in ' + plural(moves, 'move', 'moves') + (prev && moves < prev ? ', your best yet!' : '.'),
            function () { if (!prev || moves < prev) state.gameBest.pairs = moves; });
        }
      } else {
        var g0 = game;
        g0.timers.push(setTimeout(function () {
          if (game !== g0) return;
          g0.openIdx.forEach(function (j) { g0.deck[j].open = false; paintCard(j); });
          g0.openIdx = [];
        }, 900));
      }
    }
  }
  function paintCard(i) {
    var el = document.querySelector('[data-card="' + i + '"]');
    var c = game.deck[i];
    if (!el) return;
    el.setAttribute('data-open', String(c.open));
    el.setAttribute('data-done', String(c.done));
    el.setAttribute('aria-label', 'Card ' + (i + 1) + (c.open || c.done ? ', ' + FLOWERS[c.kind][0] + (c.done ? ', matched' : '') : ', face down'));
  }

  // Sunbeam Catch: tap what drifts by. Nothing is ever dropped or counted against you.
  var CATCH_SECONDS = 45;
  function startCatch(stage) {
    var field = document.createElement('div');
    field.className = 'catch-field';
    field.id = 'catch-field';
    var jar = document.createElement('p');
    jar.className = 'jar';
    jar.id = 'catch-jar';
    field.appendChild(jar);
    stage.appendChild(field);
    game.caught = 0;
    game.left = CATCH_SECONDS;
    game.beams = [];
    updateCatch();
    game.timers.push(setInterval(function () {
      if (!game || game.done) return;
      game.left--;
      updateCatch();
      if (game.left <= 0) endCatch();
    }, 1000));
    game.timers.push(setInterval(spawnBeam, 850));
    spawnBeam();
    var last = 0;
    var step = function (ts) {
      if (!game || game.id !== 'catch' || game.done) return;
      var dt = last ? Math.min(0.05, (ts - last) / 1000) : 0;
      last = ts;
      game.beams.forEach(function (bm) {
        if (bm.caught) return;
        bm.y += bm.v * dt;
        bm.x += Math.sin((ts / 1000) * bm.w) * 0.05;
        bm.el.style.top = bm.y.toFixed(2) + '%';
        bm.el.style.left = bm.x.toFixed(2) + '%';
        if (bm.y > 112) { bm.caught = true; if (bm.el.parentNode) bm.el.parentNode.removeChild(bm.el); }
      });
      game.beams = game.beams.filter(function (bm) { return !bm.caught || bm.el.parentNode; });
      game.raf = window.requestAnimationFrame ? window.requestAnimationFrame(step) : 0;
    };
    if (window.requestAnimationFrame && !prefersReducedMotion()) game.raf = window.requestAnimationFrame(step);
  }
  function updateCatch() {
    gameProgress(plural(game.caught, 'sunbeam', 'sunbeams'), 1 - game.left / CATCH_SECONDS);
    setText('catch-jar', 'In your jar: ' + game.caught + (game.left > 0 ? '  ' + Math.floor(game.left / 60) + ':' + pad(game.left % 60) : ''));
  }
  function spawnBeam() {
    if (!game || game.id !== 'catch' || game.done) return null;
    var field = $('catch-field');
    var petal = rng() < 0.4;
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'beam';
    b.setAttribute('aria-label', petal ? 'Catch a petal' : 'Catch a sunbeam');
    var icon = document.createElementNS(SVGNS, 'svg');
    icon.setAttribute('viewBox', '0 0 40 40');
    if (petal) svg('path', { d: 'M20 6C30 12 30 28 20 34 10 28 10 12 20 6Z', fill: '#FFB088' }, icon);
    else {
      svg('circle', { cx: 20, cy: 20, r: 15, fill: '#FFE29A', opacity: 0.6 }, icon);
      svg('circle', { cx: 20, cy: 20, r: 9, fill: '#FFC857' }, icon);
    }
    b.appendChild(icon);
    var bm = { el: b, x: 10 + rng() * 80, y: prefersReducedMotion() ? 15 + rng() * 70 : -8, v: 9 + rng() * 7, w: 0.6 + rng(), caught: false };
    b.style.left = bm.x + '%';
    b.style.top = bm.y + '%';
    // Caught on touch, so a drifting beam is not missed between finger down and up.
    b.addEventListener('pointerdown', function () { catchBeam(bm); });
    b.addEventListener('click', function () { catchBeam(bm); });
    field.appendChild(b);
    game.beams.push(bm);
    if (prefersReducedMotion()) {
      game.timers.push(setTimeout(function () { if (!bm.caught && b.parentNode) { bm.caught = true; b.parentNode.removeChild(b); } }, 3000));
    }
    return b;
  }
  function catchBeam(bm) {
    if (!game || game.done || bm.caught) return;
    bm.caught = true;
    game.caught++;
    bm.el.classList.add('caught');
    setTimeout(function () { if (bm.el.parentNode) bm.el.parentNode.removeChild(bm.el); }, 450);
    updateCatch();
  }
  function endCatch() {
    var n = game.caught;
    var prev = state.gameBest.catch || 0;
    finishGame('Your jar is glowing', 'You caught ' + plural(n, 'sunbeam', 'sunbeams') + (n > prev && prev > 0 ? ', your brightest jar yet!' : '.'),
      function () { if (n > prev) state.gameBest.catch = n; });
  }

  // Bubble Pop: a sheet of bubbles to pop one by one. No timer and no score, just a small thing finished.
  var POP_COUNT = 30;
  function startPop(stage) {
    var field = document.createElement('div');
    field.className = 'pop-field';
    field.id = 'pop-field';
    game.popped = 0;
    for (var i = 0; i < POP_COUNT; i++) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'bubble';
      b.setAttribute('aria-label', 'Pop a bubble');
      b.setAttribute('data-bubble', String(i));
      (function (el) {
        // Popped on touch, so a quick tap always lands.
        el.addEventListener('pointerdown', function () { popBubble(el); });
        el.addEventListener('click', function () { popBubble(el); });
      })(b);
      field.appendChild(b);
    }
    stage.appendChild(field);
    updatePop();
  }
  function updatePop() { gameProgress(game.popped + ' of ' + POP_COUNT + ' popped', game.popped / POP_COUNT); }
  function popBubble(el) {
    if (!game || game.id !== 'pop' || game.done || el.classList.contains('popped')) return false;
    el.classList.add('popped');
    el.setAttribute('aria-label', 'Popped');
    el.disabled = true;
    game.popped++;
    popSound(game.popped);
    haptic('light');
    updatePop();
    if (game.popped >= POP_COUNT) {
      game.timers.push(setTimeout(function () {
        var prev = state.gameBest.pop || 0;
        finishGame('Every bubble popped', 'All ' + POP_COUNT + ' done. Let your hands rest for a breath and enjoy the quiet.', function () { state.gameBest.pop = prev + 1; });
      }, 350));
    }
    return true;
  }
  // A soft, short pop that rises a little as the sheet fills. Only with chimes on.
  function popSound(n) {
    if (!state.chime) return false;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    try {
      chimeCtx = chimeCtx || new AC();
      var t0 = chimeCtx.currentTime;
      var o = chimeCtx.createOscillator(), g = chimeCtx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(320 + n * 6, t0);
      o.frequency.exponentialRampToValueAtTime(140, t0 + 0.09);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.06, t0 + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.12);
      o.connect(g); g.connect(chimeCtx.destination);
      o.start(t0); o.stop(t0 + 0.14);
      return true;
    } catch (e) { return false; }
  }

  // Breathing Ring: hold to breathe in with the ring, let go to breathe out.
  var BLOOM_IN = 4, BLOOM_OUT = 4, BLOOM_ROUNDS = 6;
  function startBloom(stage) {
    var wrap = document.createElement('div');
    wrap.className = 'bloom-stage';
    var ring = document.createElement('div');
    ring.className = 'bloom-ring';
    var guide = document.createElement('div');
    guide.className = 'bloom-guide';
    guide.id = 'bloom-guide';
    var fl = document.createElementNS(SVGNS, 'svg');
    fl.setAttribute('viewBox', '-100 -100 200 200');
    fl.setAttribute('class', 'bloom-flower');
    fl.id = 'bloom-flower';
    addPetals(fl, 0, 0, 1);
    svg('circle', { r: 40, fill: 'url(#g-sun)' }, fl);
    ring.appendChild(guide);
    ring.appendChild(fl);
    var cue = document.createElement('p');
    cue.className = 'cue';
    cue.id = 'bloom-cue';
    cue.textContent = 'Press and hold to begin';
    var hold = document.createElement('button');
    hold.type = 'button';
    hold.className = 'bloom-hold';
    hold.id = 'bloom-hold';
    hold.setAttribute('aria-pressed', 'false');
    hold.textContent = 'Hold to breathe in';
    var row = document.createElement('div');
    row.className = 'bloom-row';
    row.id = 'bloom-row';
    row.setAttribute('aria-label', 'Flowers bloomed');
    wrap.appendChild(ring); wrap.appendChild(cue); wrap.appendChild(hold); wrap.appendChild(row);
    stage.appendChild(wrap);
    game.holding = false;
    game.started = false;
    game.round = 0;
    game.phaseT = 0;
    game.inSync = 0;
    game.samples = 0;
    var down = function (e) { if (e) e.preventDefault(); setHold(true); };
    var up = function () { setHold(false); };
    hold.addEventListener('pointerdown', down);
    hold.addEventListener('pointerup', up);
    hold.addEventListener('pointerleave', up);
    hold.addEventListener('pointercancel', up);
    hold.addEventListener('keydown', function (e) { if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) { e.preventDefault(); setHold(true); } });
    hold.addEventListener('keyup', function (e) { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); setHold(false); } });
    hold.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    gameProgress('0 of ' + BLOOM_ROUNDS + ' breaths', 0);
  }
  function setHold(on) {
    if (!game || game.id !== 'bloom' || game.done) return;
    game.holding = on;
    var hold = $('bloom-hold');
    hold.setAttribute('aria-pressed', String(on));
    hold.textContent = on ? 'Breathing in...' : 'Hold to breathe in';
    $('bloom-flower').style.transform = on ? 'scale(1)' : 'scale(0.45)';
    $('bloom-flower').style.transitionDuration = on ? BLOOM_IN + 's' : '1.2s';
    if (on && !game.started) {
      game.started = true;
      bloomPhase();
      game.timers.push(setInterval(bloomTick, 100));
    }
  }
  function bloomPhase() {
    var inhale = game.phaseT < BLOOM_IN;
    setText('bloom-cue', inhale ? 'Breathe in' : 'Breathe out');
    var g = $('bloom-guide');
    g.style.transitionDuration = (inhale ? BLOOM_IN : BLOOM_OUT) + 's';
    g.style.transform = inhale ? 'scale(1)' : 'scale(0.5)';
    speak(inhale ? 'Breathe in' : 'Breathe out');
  }
  function bloomTick() {
    if (!game || game.id !== 'bloom' || game.done) return;
    var wasIn = game.phaseT < BLOOM_IN;
    game.phaseT += 0.1;
    var inhale = game.phaseT < BLOOM_IN;
    game.samples++;
    if (inhale === game.holding) game.inSync++;
    if (wasIn && !inhale) bloomPhase();
    if (game.phaseT >= BLOOM_IN + BLOOM_OUT) {
      game.phaseT = 0;
      bloomRound();
      if (game && !game.done) bloomPhase();
    }
  }
  function bloomRound() {
    game.round++;
    var row = $('bloom-row');
    var f = document.createElementNS(SVGNS, 'svg');
    f.setAttribute('viewBox', '0 0 40 40');
    miniFlower(f, 20, 20, 12, FLOWERS[(game.round - 1) % FLOWERS.length][1]);
    row.appendChild(f);
    gameProgress(game.round + ' of ' + BLOOM_ROUNDS + ' breaths', game.round / BLOOM_ROUNDS);
    if (game.round >= BLOOM_ROUNDS) endBloom();
  }
  function endBloom() {
    var pct = game.samples ? Math.round(game.inSync / game.samples * 100) : 0;
    var prev = state.gameBest.bloom || 0;
    finishGame('Six slow breaths', 'You moved with the ring ' + pct + '% of the time. Every breath counted.',
      function () { if (pct > prev) state.gameBest.bloom = pct; });
  }
  // A soft tone that glides from one pitch to another. Only with chimes on.
  function tone(f0, f1, dur, vol) {
    if (!state.chime) return false;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    try {
      chimeCtx = chimeCtx || new AC();
      var t0 = chimeCtx.currentTime;
      var o = chimeCtx.createOscillator(), g = chimeCtx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(f0, t0);
      o.frequency.exponentialRampToValueAtTime(f1, t0 + dur * 0.8);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol || 0.05, t0 + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(chimeCtx.destination);
      o.start(t0); o.stop(t0 + dur + 0.02);
      return true;
    } catch (e) { return false; }
  }
  function mkEl(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function gameButton(cls, text, label) {
    var b = mkEl('button', cls, text);
    b.type = 'button';
    if (label) b.setAttribute('aria-label', label);
    return b;
  }

  // Colour Sort: drag or tap each stone into the bowl of its colour. It ends with everything in its place.
  var SORT_COLOURS = [['Sun', '#FFC857'], ['Sky', '#8CC8F0'], ['Rose', '#F28FA0']];
  var SORT_EACH = 4;
  function startSort(stage) {
    var wrap = mkEl('div', 'sort-stage');
    var tray = mkEl('div', 'sort-tray');
    tray.id = 'sort-tray';
    var kinds = [];
    SORT_COLOURS.forEach(function (c, k) { for (var j = 0; j < SORT_EACH; j++) kinds.push(k); });
    game.stones = shuffle(kinds).map(function (k) { return { kind: k, done: false }; });
    game.picked = -1;
    game.sorted = 0;
    game.stones.forEach(function (s, i) {
      var b = gameButton('stone', null, SORT_COLOURS[s.kind][0] + ' stone');
      b.setAttribute('data-stone', String(i));
      b.setAttribute('aria-pressed', 'false');
      b.style.setProperty('--sc', SORT_COLOURS[s.kind][1]);
      // A little scatter, so the tray looks untidy before you begin.
      b.style.setProperty('--rot', Math.round(rng() * 40 - 20) + 'deg');
      b.style.setProperty('--dy', Math.round(rng() * 12 - 6) + 'px');
      dragStone(b, i);
      tray.appendChild(b);
    });
    var bowls = mkEl('div', 'sort-bowls');
    SORT_COLOURS.forEach(function (c, k) {
      var b = gameButton('sort-bowl', null, c[0] + ' bowl');
      b.setAttribute('data-bowl', String(k));
      b.style.setProperty('--sc', c[1]);
      b.appendChild(mkEl('span', 'bowl-pile'));
      b.appendChild(mkEl('span', 'bowl-name', c[0]));
      b.addEventListener('click', function () { if (game && game.id === 'sort' && game.picked !== -1) sortStone(game.picked, k); });
      bowls.appendChild(b);
    });
    wrap.appendChild(tray);
    wrap.appendChild(bowls);
    stage.appendChild(wrap);
    updateSort();
  }
  function dragStone(b, i) {
    var start = null;
    var reset = function () { start = null; b.classList.remove('dragging'); b.style.transform = ''; };
    b.addEventListener('pointerdown', function (e) {
      if (!game || game.id !== 'sort' || game.done || game.stones[i].done) return;
      start = { x: e.clientX, y: e.clientY, moved: false };
      if (b.setPointerCapture) { try { b.setPointerCapture(e.pointerId); } catch (x) { /* capture is optional */ } }
    });
    b.addEventListener('pointermove', function (e) {
      if (!start) return;
      var dx = e.clientX - start.x, dy = e.clientY - start.y;
      if (!start.moved && Math.abs(dx) + Math.abs(dy) < 8) return;
      start.moved = true;
      b.classList.add('dragging');
      b.style.transform = 'translate(' + dx + 'px, ' + dy + 'px) scale(1.15)';
    });
    b.addEventListener('pointerup', function (e) {
      if (!start) return;
      var moved = start.moved;
      reset();
      if (!moved) return;
      b.setAttribute('data-dragged', '1');
      var k = bowlAt(e.clientX, e.clientY);
      if (k !== null) sortStone(i, k);
    });
    b.addEventListener('pointercancel', reset);
    b.addEventListener('click', function () {
      // The click that follows a drag is not a tap.
      if (b.getAttribute('data-dragged')) { b.removeAttribute('data-dragged'); return; }
      pickStone(i);
    });
  }
  function bowlAt(x, y) {
    var bowls = document.querySelectorAll('.sort-bowl');
    for (var k = 0; k < bowls.length; k++) {
      var r = bowls[k].getBoundingClientRect();
      if (r.width && x >= r.left - 12 && x <= r.right + 12 && y >= r.top - 12 && y <= r.bottom + 12) return k;
    }
    return null;
  }
  function pickStone(i) {
    if (!game || game.id !== 'sort' || game.done || !game.stones[i] || game.stones[i].done) return false;
    game.picked = game.picked === i ? -1 : i;
    paintSort();
    haptic('light');
    return true;
  }
  function sortStone(i, k) {
    if (!game || game.id !== 'sort' || game.done) return false;
    var s = game.stones[i];
    if (!s || s.done) return false;
    var bowl = document.querySelector('.sort-bowl[data-bowl="' + k + '"]');
    if (s.kind !== k) {
      // Not this bowl: it gives a small wobble, and the stone stays in your hand.
      game.picked = i;
      paintSort();
      if (bowl) { bowl.classList.remove('nudge'); void bowl.offsetWidth; bowl.classList.add('nudge'); }
      return false;
    }
    s.done = true;
    game.picked = -1;
    game.sorted++;
    var b = document.querySelector('.stone[data-stone="' + i + '"]');
    if (b) { b.classList.add('placed'); b.disabled = true; b.setAttribute('aria-label', 'Sorted'); }
    if (bowl) { var dot = mkEl('i'); dot.style.background = SORT_COLOURS[k][1]; bowl.querySelector('.bowl-pile').appendChild(dot); }
    tone(440 + game.sorted * 20, 330, 0.2);
    haptic('light');
    paintSort();
    updateSort();
    if (game.sorted >= game.stones.length) {
      game.timers.push(setTimeout(function () {
        var n = (state.gameBest.sort || 0) + 1;
        finishGame('Everything in its place', 'Every stone is in its bowl. Notice how tidy and settled it looks.', function () { state.gameBest.sort = n; });
      }, 400));
    }
    return true;
  }
  function paintSort() {
    var stones = document.querySelectorAll('#sort-tray .stone');
    for (var j = 0; j < stones.length; j++) stones[j].setAttribute('aria-pressed', String(game.picked === j));
    var bowls = document.querySelectorAll('.sort-bowl');
    for (var k = 0; k < bowls.length; k++) bowls[k].classList.toggle('ready', game.picked !== -1);
  }
  function updateSort() { gameProgress(game.sorted + ' of ' + game.stones.length + ' sorted', game.sorted / game.stones.length); }

  // Zen Sand: draw slow lines with a finger, a rake or a pebble. The lines soften away on their own.
  var SAND_LINES = 10, SAND_W = 600, SAND_H = 450, SAND_BASE = '#F1DDB5';
  function startSand(stage) {
    var wrap = mkEl('div', 'sand-stage');
    var cv = mkEl('canvas', 'sand-canvas');
    cv.id = 'sand-canvas';
    cv.width = SAND_W;
    cv.height = SAND_H;
    cv.setAttribute('role', 'img');
    cv.setAttribute('aria-label', 'Sand tray');
    var tools = mkEl('div', 'chips sand-tools');
    tools.setAttribute('role', 'group');
    tools.setAttribute('aria-label', 'Sand tools');
    [['rake', 'Rake'], ['line', 'Finger'], ['stone', 'Pebble']].forEach(function (t) {
      var b = gameButton('chip', t[1]);
      b.setAttribute('data-sand-tool', t[0]);
      b.setAttribute('aria-pressed', String(t[0] === 'rake'));
      b.addEventListener('click', function () { setSandTool(t[0]); });
      tools.appendChild(b);
    });
    var smooth = gameButton('chip', 'Smooth it');
    smooth.id = 'sand-smooth';
    smooth.addEventListener('click', function () { paintSandBase(); haptic('light'); tone(300, 180, 0.5, 0.03); });
    tools.appendChild(smooth);
    wrap.appendChild(cv);
    wrap.appendChild(tools);
    stage.appendChild(wrap);
    game.tool = 'rake';
    game.lines = 0;
    game.stroke = null;
    game.ctx = null;
    try { game.ctx = cv.getContext ? cv.getContext('2d') : null; } catch (e) { game.ctx = null; }
    paintSandBase();
    var at = function (e) {
      var r = cv.getBoundingClientRect();
      return { x: r.width ? (e.clientX - r.left) * SAND_W / r.width : 0, y: r.height ? (e.clientY - r.top) * SAND_H / r.height : 0 };
    };
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      if (cv.setPointerCapture) { try { cv.setPointerCapture(e.pointerId); } catch (x) { /* capture is optional */ } }
      sandBegin(at(e));
    });
    cv.addEventListener('pointermove', function (e) { if (game && game.stroke) sandMove(at(e)); });
    cv.addEventListener('pointerup', function () { sandEnd(); });
    cv.addEventListener('pointercancel', function () { sandEnd(); });
    // The sand settles a little at a time, so old lines fade while you draw new ones.
    if (game.ctx && !prefersReducedMotion()) {
      game.timers.push(setInterval(function () {
        if (!game || game.id !== 'sand' || !game.ctx) return;
        game.ctx.fillStyle = 'rgba(241, 221, 181, 0.035)';
        game.ctx.fillRect(0, 0, SAND_W, SAND_H);
      }, 120));
    }
    updateSand();
  }
  function setSandTool(t) {
    if (!game || game.id !== 'sand') return;
    game.tool = t;
    var bs = document.querySelectorAll('[data-sand-tool]');
    for (var i = 0; i < bs.length; i++) bs[i].setAttribute('aria-pressed', String(bs[i].getAttribute('data-sand-tool') === t));
    haptic('light');
  }
  function paintSandBase() {
    var c = game && game.ctx;
    if (!c) return;
    c.fillStyle = SAND_BASE;
    c.fillRect(0, 0, SAND_W, SAND_H);
    // A fine grain, so it reads as sand rather than paper.
    for (var i = 0; i < 900; i++) {
      c.fillStyle = rng() < 0.5 ? 'rgba(201, 155, 90, 0.18)' : 'rgba(255, 248, 230, 0.5)';
      c.fillRect(rng() * SAND_W, rng() * SAND_H, 2, 2);
    }
  }
  function groove(a, b, offset) {
    var c = game.ctx;
    if (!c) return;
    var dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy) || 1;
    var nx = -dy / len * offset, ny = dx / len * offset;
    c.lineCap = 'round';
    c.strokeStyle = 'rgba(176, 128, 70, 0.55)';
    c.lineWidth = 13;
    c.beginPath(); c.moveTo(a.x + nx, a.y + ny); c.lineTo(b.x + nx, b.y + ny); c.stroke();
    c.strokeStyle = 'rgba(255, 246, 224, 0.85)';
    c.lineWidth = 4;
    c.beginPath(); c.moveTo(a.x + nx - 3, a.y + ny - 3); c.lineTo(b.x + nx - 3, b.y + ny - 3); c.stroke();
  }
  function pebble(p) {
    var c = game.ctx;
    if (!c) return;
    for (var r = 78; r >= 30; r -= 24) {
      c.strokeStyle = 'rgba(176, 128, 70, 0.45)'; c.lineWidth = 10;
      c.beginPath(); c.arc(p.x, p.y, r, 0, Math.PI * 2); c.stroke();
      c.strokeStyle = 'rgba(255, 246, 224, 0.8)'; c.lineWidth = 3.5;
      c.beginPath(); c.arc(p.x - 1.5, p.y - 1.5, r, 0, Math.PI * 2); c.stroke();
    }
    c.fillStyle = '#8E8173';
    c.beginPath(); c.ellipse(p.x, p.y, 20, 16, 0.3, 0, Math.PI * 2); c.fill();
    c.fillStyle = 'rgba(255, 255, 255, 0.35)';
    c.beginPath(); c.ellipse(p.x - 4, p.y - 4, 5, 3, 0.3, 0, Math.PI * 2); c.fill();
  }
  function sandBegin(p) {
    if (!game || game.id !== 'sand' || game.done) return false;
    if (game.tool === 'stone') {
      pebble(p);
      tone(220, 150, 0.6, 0.04);
      haptic('light');
      sandLine();
      return true;
    }
    game.stroke = { last: p, len: 0 };
    return true;
  }
  function sandMove(p) {
    var s = game.stroke;
    if (!s) return;
    var d = Math.hypot(p.x - s.last.x, p.y - s.last.y);
    if (d < 2) return;
    if (game.tool === 'rake') [-26, 0, 26].forEach(function (o) { groove(s.last, p, o); });
    else groove(s.last, p, 0);
    s.len += d;
    s.last = p;
  }
  function sandEnd() {
    if (!game || game.id !== 'sand' || !game.stroke) return false;
    var long = game.stroke.len > 60;
    game.stroke = null;
    if (long) { tone(260, 200, 0.4, 0.025); sandLine(); }
    return long;
  }
  function sandLine() {
    game.lines++;
    updateSand();
    if (game.lines >= SAND_LINES) game.timers.push(setTimeout(endSand, 600));
  }
  // For tests and keyboards: draw one stroke through the given points.
  function sandStroke(points) {
    if (!game || game.id !== 'sand' || !points || !points.length) return false;
    sandBegin(points[0]);
    for (var i = 1; i < points.length; i++) sandMove(points[i]);
    return game.tool === 'stone' ? true : sandEnd();
  }
  function updateSand() { gameProgress(game.lines + ' of ' + SAND_LINES + ' lines', Math.min(1, game.lines / SAND_LINES)); }
  function endSand() {
    if (!game || game.id !== 'sand') return;
    var n = (state.gameBest.sand || 0) + 1;
    finishGame('Smooth and still', 'Ten slow lines in the sand. Let your hands rest, and enjoy the quiet.', function () { state.gameBest.sand = n; });
  }

  // Star Connect: tap the glowing star to join it to the last. Three pictures make a full sky.
  var SKIES = [
    { name: 'The Kite', stars: [[50, 12], [76, 40], [50, 66], [24, 40], [58, 90]], order: [4, 2, 1, 0, 3, 2] },
    { name: 'The Boat', stars: [[18, 64], [82, 64], [68, 82], [32, 82], [50, 64], [50, 16], [76, 54]], order: [0, 1, 2, 3, 0, 4, 5, 6, 4] },
    { name: 'Saptarishi', stars: [[10, 34], [27, 28], [42, 34], [55, 44], [58, 66], [84, 72], [88, 48]], order: [0, 1, 2, 3, 4, 5, 6, 3] }
  ];
  function startStars(stage) {
    var sky = mkEl('div', 'stars-sky');
    sky.id = 'stars-sky';
    var lines = document.createElementNS(SVGNS, 'svg');
    lines.setAttribute('viewBox', '0 0 100 100');
    lines.setAttribute('preserveAspectRatio', 'none');
    lines.setAttribute('class', 'stars-lines');
    lines.setAttribute('aria-hidden', 'true');
    lines.id = 'stars-lines';
    sky.appendChild(lines);
    var label = mkEl('p', 'stars-name');
    label.id = 'stars-name';
    label.setAttribute('aria-live', 'polite');
    sky.appendChild(label);
    stage.appendChild(sky);
    game.sky = 0;
    starsRound();
  }
  function starsRound() {
    var sky = $('stars-sky'), c = SKIES[game.sky];
    var old = sky.querySelectorAll('.star');
    for (var i = 0; i < old.length; i++) sky.removeChild(old[i]);
    $('stars-lines').textContent = '';
    $('stars-name').textContent = '';
    sky.classList.remove('complete');
    game.step = 0;
    c.stars.forEach(function (p, j) {
      var b = gameButton('star', null, 'Star');
      b.setAttribute('data-star', String(j));
      b.style.left = p[0] + '%';
      b.style.top = p[1] + '%';
      b.addEventListener('click', function () { tapStar(j); });
      sky.appendChild(b);
    });
    paintStars();
  }
  function paintStars() {
    var c = SKIES[game.sky], next = c.order[game.step];
    var bs = document.querySelectorAll('#stars-sky .star');
    for (var j = 0; j < bs.length; j++) {
      var on = j === next && game.step < c.order.length;
      bs[j].classList.toggle('next', on);
      bs[j].setAttribute('aria-label', on ? 'Next star' : bs[j].classList.contains('lit') ? 'Joined star' : 'Star');
    }
    var share = (game.sky + game.step / c.order.length) / SKIES.length;
    gameProgress('Sky ' + (game.sky + 1) + ' of ' + SKIES.length, share);
  }
  function tapStar(j) {
    if (!game || game.id !== 'stars' || game.done) return false;
    var c = SKIES[game.sky];
    if (game.step >= c.order.length) return false;
    var b = document.querySelector('#stars-sky .star[data-star="' + j + '"]');
    if (c.order[game.step] !== j) {
      // Not this one yet: the next star twinkles brighter to show the way.
      var nx = document.querySelector('#stars-sky .star.next');
      if (nx) { nx.classList.remove('hint'); void nx.offsetWidth; nx.classList.add('hint'); }
      return false;
    }
    if (game.step > 0) {
      var a = c.stars[c.order[game.step - 1]], p = c.stars[j];
      var ln = svg('line', { x1: a[0], y1: a[1], x2: p[0], y2: p[1], class: 'star-line' }, $('stars-lines'));
      ln.setAttribute('vector-effect', 'non-scaling-stroke');
    }
    if (b) b.classList.add('lit');
    game.step++;
    tone(520 + game.step * 40, 700 + game.step * 40, 0.35, 0.04);
    haptic('light');
    paintStars();
    if (game.step >= c.order.length) {
      $('stars-sky').classList.add('complete');
      setText('stars-name', c.name);
      tone(660, 990, 0.9, 0.05);
      game.timers.push(setTimeout(function () {
        if (!game || game.id !== 'stars') return;
        game.sky++;
        if (game.sky >= SKIES.length) endStars();
        else starsRound();
      }, 1500));
    }
    return true;
  }
  function endStars() {
    if (!game || game.id !== 'stars') return;
    var n = (state.gameBest.stars || 0) + 1;
    finishGame('Your sky is full', 'Three pictures in the stars, joined one calm tap at a time.', function () { state.gameBest.stars = n; });
  }

  // Gentle Stack: a block glides slowly above the tower. Tap to set it down. Every block lands.
  var STACK_COUNT = 12, STACK_MIN = 26, STACK_H = 30;
  var STACK_COLOURS = ['#4FA67C', '#8CC8F0', '#FFC857', '#F28FA0', '#B9A3F0', '#FFB088'];
  function startStack(stage) {
    var field = mkEl('div', 'stack-field');
    field.id = 'stack-field';
    var tower = mkEl('div', 'stack-tower');
    tower.id = 'stack-tower';
    field.appendChild(tower);
    var drop = gameButton('btn btn-sun stack-drop', 'Set it down');
    drop.id = 'stack-drop';
    drop.addEventListener('click', function () { dropBlock(); });
    field.addEventListener('pointerdown', function (e) { e.preventDefault(); dropBlock(); });
    stage.appendChild(field);
    stage.appendChild(drop);
    game.blocks = [{ x: 20, w: 60 }];
    game.just = 0;
    addStackBlock(game.blocks[0], 0, false);
    nextStackBlock();
    var speed = prefersReducedMotion() ? 12 : 20; // percent of the width per second: slow on purpose
    game.timers.push(setInterval(function () {
      var m = game && game.id === 'stack' && game.moving;
      if (!m) return;
      m.x += m.dir * speed * 0.03;
      if (m.x <= 0) { m.x = 0; m.dir = 1; }
      if (m.x >= 100 - m.w) { m.x = 100 - m.w; m.dir = -1; }
      m.el.style.left = m.x.toFixed(2) + '%';
    }, 30));
    updateStack();
  }
  function addStackBlock(b, level, moving) {
    var d = mkEl('div', 'stack-block' + (moving ? ' moving' : ''));
    d.style.left = b.x + '%';
    d.style.width = b.w + '%';
    d.style.bottom = (level * STACK_H) + 'px';
    d.style.background = STACK_COLOURS[level % STACK_COLOURS.length];
    $('stack-tower').appendChild(d);
    return d;
  }
  function nextStackBlock() {
    var last = game.blocks[game.blocks.length - 1], level = game.blocks.length;
    var fromLeft = level % 2 === 1;
    var m = { x: fromLeft ? 0 : 100 - last.w, w: last.w, dir: fromLeft ? 1 : -1 };
    m.el = addStackBlock(m, level, true);
    game.moving = m;
    // Keep the top of the tower in view as it grows.
    $('stack-tower').style.transform = 'translateY(' + (Math.max(0, level - 8) * STACK_H) + 'px)';
  }
  function dropBlock() {
    if (!game || game.id !== 'stack' || game.done || !game.moving) return false;
    var m = game.moving, last = game.blocks[game.blocks.length - 1];
    var x = m.x, w = m.w;
    if (Math.abs(x - last.x) < 3) {
      // Just right: it snaps into line and grows back a little.
      x = last.x;
      w = Math.min(60, last.w + 4);
      x = Math.max(0, Math.min(100 - w, x - 2));
      game.just++;
      m.el.classList.add('just');
      tone(660, 880, 0.35, 0.05);
    } else {
      var lo = Math.max(x, last.x), hi = Math.min(x + w, last.x + last.w);
      var over = hi - lo;
      // A block that slides off the edge still lands, centred on the one below at the smallest size.
      if (over < STACK_MIN) { w = Math.min(STACK_MIN, last.w); x = last.x + (last.w - w) / 2; }
      else { w = over; x = lo; }
      tone(380 + game.blocks.length * 15, 300, 0.25, 0.04);
    }
    m.el.classList.remove('moving');
    m.el.style.left = x + '%';
    m.el.style.width = w + '%';
    game.blocks.push({ x: x, w: w });
    game.moving = null;
    haptic('light');
    updateStack();
    if (game.blocks.length - 1 >= STACK_COUNT) {
      game.timers.push(setTimeout(function () {
        var just = game.just, prev = state.gameBest.stack || 0;
        finishGame('A steady tower', 'Twelve blocks, set down at your own pace. Take a slow breath and enjoy it.', function () { if (just > prev) state.gameBest.stack = just; });
      }, 500));
    } else nextStackBlock();
    return true;
  }
  function updateStack() {
    var n = game.blocks.length - 1;
    gameProgress(n + ' of ' + STACK_COUNT + ' blocks', n / STACK_COUNT);
  }

  // Kind Notes: tap three kind words for yourself. They gather into a note you can keep.
  var KIND_WORDS = [
    'I am doing my best.', 'This is hard, and I am handling it.', 'I can go gently today.', 'I deserve rest.',
    'Small steps still count.', 'I am allowed to learn as I go.', 'My feelings make sense.', 'I can be patient with myself.',
    'I have got through hard days before.', 'I am enough as I am.', 'It is okay to ask for help.', 'I can start again, any time.',
    'I am getting stronger, a little each day.', 'I can be my own good friend.', 'Today counts, even the quiet parts.', 'I am worth being kind to.'
  ];
  var KIND_PICK = 3, KIND_SHOWN = 6;
  function startKind(stage) {
    var note = mkEl('div', 'kind-note');
    note.id = 'kind-note';
    note.appendChild(mkEl('p', 'kind-note-head', 'A note to me'));
    var lines = mkEl('ol', 'kind-lines');
    lines.id = 'kind-lines';
    for (var i = 0; i < KIND_PICK; i++) lines.appendChild(mkEl('li', 'kind-line'));
    note.appendChild(lines);
    var cloud = mkEl('div', 'kind-cloud');
    cloud.id = 'kind-cloud';
    var other = gameButton('btn btn-ghost btn-small', 'Other words');
    other.id = 'kind-other';
    other.addEventListener('click', function () { kindWords(); haptic('light'); });
    stage.appendChild(note);
    stage.appendChild(cloud);
    stage.appendChild(other);
    game.kept = [];
    kindWords();
    updateKind();
  }
  // Fills the cloud with words not yet chosen.
  function kindWords() {
    if (!game || game.id !== 'kind' || game.done) return;
    var cloud = $('kind-cloud');
    cloud.textContent = '';
    var pool = shuffle(KIND_WORDS.filter(function (w) { return game.kept.indexOf(w) === -1; })).slice(0, KIND_SHOWN);
    pool.forEach(function (w, i) {
      var b = gameButton('kind-word', w);
      b.setAttribute('data-kind-word', String(KIND_WORDS.indexOf(w)));
      b.style.animationDelay = (-(i * 0.7)).toFixed(1) + 's';
      b.addEventListener('click', function () { pickKind(b); });
      cloud.appendChild(b);
    });
  }
  function pickKind(b) {
    if (typeof b === 'number') b = document.querySelectorAll('#kind-cloud .kind-word:not([disabled])')[b];
    if (!b || !game || game.id !== 'kind' || game.done || b.disabled || game.kept.length >= KIND_PICK) return false;
    var w = KIND_WORDS[+b.getAttribute('data-kind-word')];
    game.kept.push(w);
    b.disabled = true;
    b.classList.add('kept');
    var li = document.querySelectorAll('#kind-lines .kind-line')[game.kept.length - 1];
    if (li) { li.textContent = w; li.classList.add('filled'); }
    tone(500 + game.kept.length * 90, 620 + game.kept.length * 90, 0.5, 0.04);
    haptic('light');
    updateKind();
    if (game.kept.length >= KIND_PICK) {
      $('kind-other').hidden = true;
      $('kind-cloud').hidden = true;
      game.timers.push(setTimeout(function () {
        var n = (state.gameBest.kind || 0) + 1;
        finishGame('A kind note, from you', 'Read it slowly, once, as if a good friend wrote it to you.', function () { state.gameBest.kind = n; });
        var keep = $('game-keep');
        if (keep) keep.hidden = false;
      }, 600));
    }
    return true;
  }
  function updateKind() { gameProgress(game.kept.length + ' of ' + KIND_PICK + ' chosen', game.kept.length / KIND_PICK); }
  // Keeps the finished note in the Good things jar.
  function keepKindNote() {
    if (!game || game.id !== 'kind' || game.kept.length < KIND_PICK || game.keptInJar) return false;
    game.keptInJar = true;
    state.goodThings.push({ day: dayKey(now()), text: game.kept.join(' ').slice(0, 160) });
    if (state.goodThings.length > 200) state.goodThings = state.goodThings.slice(-200);
    save();
    renderJar();
    $('game-keep').hidden = true;
    toast('Saved in your jar.');
    return true;
  }

  /* ---------- More calm games: Rangoli Colours, Picture Tiles, Wind Chimes, Spot the Odd One, Calm Count,
     Sky Lanterns, Ripple Pond and Mirror Mandala. Nothing is timed against you and every round ends kindly. ---------- */

  // Three games come with several designs. Two of each are free; LoosenUp Plus opens the rest.
  // Today's game can be any design, so everyone gets to try the Plus ones now and then.
  var GAME_SETS = { rangoli: 6, tiles: 6, chimes: 6 };
  var GAME_FREE_SETS = 2;
  var SET_WORDS = { rangoli: ['design', 'designs'], tiles: ['picture', 'pictures'], chimes: ['tune', 'tunes'] };
  function openSets(id) { return plusRequired() ? GAME_FREE_SETS : GAME_SETS[id]; }
  function nextSet(id) { return ((state.gameLevel || {})[id] || 0) % openSets(id); }
  function setLabel(id, n) { return SET_WORDS[id][0].charAt(0).toUpperCase() + SET_WORDS[id][0].slice(1) + ' ' + (n + 1) + ' of ' + GAME_SETS[id]; }
  function renderGamePlus() {
    var b = $('game-plus');
    if (!b || !game) return;
    var id = game.id, show = !!GAME_SETS[id] && plusRequired();
    b.hidden = !show;
    if (show) setText('game-plus', (GAME_SETS[id] - GAME_FREE_SETS) + ' more ' + SET_WORDS[id][1] + ' with LoosenUp Plus');
  }
  function openGamePlus() {
    openShop('More rangoli designs, picture puzzles and chime tunes are part of LoosenUp Plus. Every game stays free to play.');
  }

  // Today's game: the same one for everyone each day, so it can be shared and talked about.
  var DAILY_GAMES = ['rangoli', 'tiles', 'chimes', 'count', 'lantern', 'spot', 'mandala', 'pond', 'stars', 'sort', 'pairs', 'stack', 'kind', 'sand'];
  function dailyGame() {
    var d = dayNum(dayKey(now()));
    var id = DAILY_GAMES[d % DAILY_GAMES.length];
    var set = GAME_SETS[id] ? Math.floor(d / DAILY_GAMES.length) % GAME_SETS[id] : null;
    return { id: id, set: set, plusTaste: set != null && set >= GAME_FREE_SETS && plusRequired() };
  }
  function dailyDone() { return !!state.daily && state.daily.day === dayKey(now()); }
  function openDaily() {
    var d = dailyGame();
    openGame(d.id, { daily: true, set: d.set });
    return d.id;
  }
  // A running count of days played. Like the weekly goal, a quiet day never takes anything away.
  function markDaily(nb) {
    var dk = dayKey(now()), dl = state.daily || (state.daily = { day: null, days: 0 });
    if (dl.day === dk) return false;
    dl.day = dk;
    dl.days = (dl.days || 0) + 1;
    if (dl.days >= 7) addBadge('daily7', nb);
    return true;
  }
  function renderDaily() {
    var card = $('daily-game');
    if (!card) return;
    var d = dailyGame(), done = dailyDone(), days = (state.daily || {}).days || 0;
    setText('daily-name', GAMES[d.id].name + (d.set != null ? ', ' + SET_WORDS[d.id][0] + ' ' + (d.set + 1) : ''));
    setText('daily-sub', done ? 'Done for today. A new one comes tomorrow.' : d.plusTaste ? 'A Plus ' + SET_WORDS[d.id][0] + ', free for you today.' : GAMES[d.id].help);
    setText('daily-streak', days ? plural(days, 'day', 'days') + ' played so far' : 'A new game every day');
    setText('daily-play', done ? 'Play again' : 'Play');
    card.classList.toggle('done', done);
    var ic = $('daily-ic'), src = document.querySelector('#screen-today .game-tile[data-game="' + d.id + '"] .gt-ic');
    if (ic && src && ic.getAttribute('data-for') !== d.id) { ic.innerHTML = src.innerHTML; ic.setAttribute('data-for', d.id); }
  }

  // Your game shelf (Progress): every game, how often you played it, and which ones are still new to you.
  var SHELF_GAMES = ['pairs', 'pop', 'bloom', 'sort', 'sand', 'stars', 'stack', 'kind', 'catch', 'rangoli', 'tiles', 'chimes', 'spot', 'count', 'lantern', 'pond', 'mandala'];
  function renderShelf() {
    var grid = $('shelf-grid');
    if (!grid) return;
    var plays = state.gamePlays || {}, played = 0;
    grid.textContent = '';
    SHELF_GAMES.forEach(function (id) {
      var n = plays[id] || 0;
      if (n) played++;
      var b = gameButton('shelf-item' + (n ? '' : ' fresh'));
      b.setAttribute('data-game', id);
      b.appendChild(mkEl('strong', null, GAMES[id].name));
      b.appendChild(mkEl('span', null, n ? (n === 1 ? 'Played once' : 'Played ' + n + ' times') : 'New'));
      grid.appendChild(b);
    });
    setText('shelf-count', played + ' of ' + SHELF_GAMES.length + ' games played');
    var bar = $('shelf-bar-fill');
    if (bar) bar.style.width = Math.round(played / SHELF_GAMES.length * 100) + '%';
  }
  // A small "New" tag on games you have not played yet (in Calm, so Today stays short).
  function renderNewTags() {
    var plays = state.gamePlays || {};
    var cards = document.querySelectorAll('#panel-games .game-card[data-game]');
    for (var i = 0; i < cards.length; i++) {
      var id = cards[i].getAttribute('data-game'), tag = cards[i].querySelector('.new-tag');
      if (!plays[id] && !tag) { tag = mkEl('em', 'new-tag', 'New'); cards[i].appendChild(tag); if (isHindi()) translateDom(tag); }
      else if (plays[id] && tag) tag.parentNode.removeChild(tag);
    }
  }

  // Rangoli Colours: tap a ring of the pattern to fill all of it with the chosen colour.
  // A design is a list of rings: [shape, count, radius, size, turn]. Shapes: petal, dot, leaf, diamond, centre.
  var RANGOLI_COLOURS = [['Marigold', '#F2A72B'], ['Kumkum', '#D9465A'], ['Rose', '#F28FA0'], ['Leaf', '#4FA67C'], ['Sky', '#6FB3E0'], ['Lilac', '#B9A3F0'], ['Rice', '#FFF8EC']];
  var RANGOLI = [
    [['centre', 1, 0, 7, 0], ['petal', 8, 16, 9, 0], ['dot', 8, 27, 3.2, 22.5], ['petal', 16, 36, 7, 0], ['dot', 16, 45, 2.6, 11.25]],
    [['centre', 1, 0, 6, 0], ['diamond', 6, 14, 7, 0], ['petal', 12, 26, 8, 15], ['leaf', 12, 38, 7, 0], ['dot', 24, 46, 2.2, 7.5]],
    [['centre', 1, 0, 8, 0], ['dot', 10, 14, 3.4, 0], ['petal', 10, 25, 10, 18], ['diamond', 10, 37, 6, 0], ['petal', 20, 45, 5, 9]],
    [['centre', 1, 0, 5, 0], ['leaf', 8, 13, 7, 0], ['petal', 8, 24, 9, 22.5], ['dot', 16, 33, 3, 0], ['leaf', 16, 42, 6, 11.25], ['dot', 32, 48, 1.6, 0]],
    [['centre', 1, 0, 9, 0], ['petal', 12, 20, 9, 0], ['diamond', 12, 32, 6, 15], ['petal', 24, 42, 5.5, 0]],
    [['centre', 1, 0, 6, 0], ['diamond', 4, 13, 8, 45], ['petal', 8, 22, 8, 0], ['dot', 8, 31, 3.4, 22.5], ['leaf', 16, 38, 6.5, 0], ['diamond', 16, 46, 3.2, 11.25]]
  ];
  function rangoliShape(kind, a, r, s) {
    var c = Math.cos(a), sn = Math.sin(a), px = -sn, py = c;
    var P = function (d, w) { return (50 + c * d + px * w).toFixed(2) + ' ' + (50 + sn * d + py * w).toFixed(2); };
    if (kind === 'petal') return 'M' + P(r - s, 0) + ' Q' + P(r, s * 0.75) + ' ' + P(r + s, 0) + ' Q' + P(r, -s * 0.75) + ' ' + P(r - s, 0) + 'Z';
    if (kind === 'leaf') return 'M' + P(r - s, 0) + ' C' + P(r - s * 0.2, s * 0.9) + ' ' + P(r + s * 0.6, s * 0.4) + ' ' + P(r + s, 0) + ' C' + P(r + s * 0.6, -s * 0.4) + ' ' + P(r - s * 0.2, -s * 0.9) + ' ' + P(r - s, 0) + 'Z';
    if (kind === 'diamond') return 'M' + P(r - s, 0) + ' L' + P(r, s * 0.6) + ' L' + P(r + s, 0) + ' L' + P(r, -s * 0.6) + 'Z';
    return null;
  }
  function startRangoli(stage) {
    var design = RANGOLI[game.set || 0];
    var wrap = mkEl('div', 'rangoli-stage');
    var art = document.createElementNS(SVGNS, 'svg');
    art.setAttribute('viewBox', '0 0 100 100');
    art.setAttribute('class', 'rangoli-art');
    art.id = 'rangoli-art';
    art.setAttribute('role', 'group');
    art.setAttribute('aria-label', 'Rangoli');
    svg('circle', { cx: 50, cy: 50, r: 49, class: 'rangoli-floor' }, art);
    game.rings = design.map(function () { return null; });
    game.colour = 0;
    design.forEach(function (ring, ri) {
      var g = svg('g', { class: 'rangoli-ring', 'data-ring': ri, tabindex: '0', role: 'button', 'aria-label': 'Ring ' + (ri + 1) }, art);
      for (var k = 0; k < ring[1]; k++) {
        var a = (ring[4] + k * 360 / ring[1]) * Math.PI / 180;
        if (ring[0] === 'centre') svg('circle', { cx: 50, cy: 50, r: ring[3] }, g);
        else if (ring[0] === 'dot') svg('circle', { cx: (50 + Math.cos(a) * ring[2]).toFixed(2), cy: (50 + Math.sin(a) * ring[2]).toFixed(2), r: ring[3] }, g);
        else svg('path', { d: rangoliShape(ring[0], a, ring[2], ring[3]) }, g);
      }
      g.addEventListener('click', function () { colourRing(ri); });
      g.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); colourRing(ri); } });
    });
    var pal = mkEl('div', 'rangoli-palette');
    pal.setAttribute('role', 'group');
    pal.setAttribute('aria-label', 'Colours');
    RANGOLI_COLOURS.forEach(function (c, i) {
      var b = gameButton('swatch', null, c[0]);
      b.style.setProperty('--sw', c[1]);
      b.setAttribute('data-colour', String(i));
      b.setAttribute('aria-pressed', String(i === 0));
      b.addEventListener('click', function () { pickColour(i); });
      pal.appendChild(b);
    });
    wrap.appendChild(art);
    wrap.appendChild(pal);
    stage.appendChild(wrap);
    setText('game-help', setLabel('rangoli', game.set) + '. ' + GAMES.rangoli.help);
    updateRangoli();
  }
  function pickColour(i) {
    if (!game || game.id !== 'rangoli') return false;
    game.colour = i;
    var sw = document.querySelectorAll('.rangoli-palette .swatch');
    for (var k = 0; k < sw.length; k++) sw[k].setAttribute('aria-pressed', String(k === i));
    haptic('light');
    return true;
  }
  function colourRing(ri) {
    if (!game || game.id !== 'rangoli' || game.done) return false;
    var g = document.querySelector('#rangoli-art [data-ring="' + ri + '"]');
    if (!g) return false;
    var first = game.rings[ri] == null;
    game.rings[ri] = game.colour;
    g.style.fill = RANGOLI_COLOURS[game.colour][1];
    g.classList.add('filled');
    tone(440 + ri * 70, 560 + ri * 70, 0.4, 0.04);
    haptic('light');
    updateRangoli();
    if (first && game.rings.every(function (x) { return x != null; })) {
      game.timers.push(setTimeout(function () {
        $('rangoli-art').classList.add('complete');
        finishGame('Your rangoli is ready', 'Every ring has its colour. Take a slow breath and enjoy what you made.');
      }, 700));
    }
    return true;
  }
  function updateRangoli() {
    var n = game.rings.filter(function (x) { return x != null; }).length;
    gameProgress(n + ' of ' + game.rings.length + ' rings', n / game.rings.length);
  }

  // Picture Tiles: tap two tiles to swap them until the picture is whole. Peek shows the finished picture.
  // Pictures are simple layers drawn in a 90 by 90 box: [shape, colour, ...numbers].
  var TILE_PICS = [
    { name: 'Sea at sunset', layers: [['rect', '#FFB088', 0, 0, 90, 30], ['rect', '#FFC857', 0, 30, 90, 18], ['circle', '#FFF1C9', 45, 48, 14], ['rect', '#4FA9C8', 0, 48, 90, 22], ['rect', '#2F7FA6', 0, 70, 90, 20], ['rect', '#FFE9A8', 30, 54, 30, 2], ['rect', '#FFE9A8', 36, 62, 18, 2], ['path', '#24557A', 'M8 80 L22 74 L36 80 Z'], ['line', '#24557A', 'M8 14 q3 -3 6 0 q3 -3 6 0'], ['line', '#24557A', 'M44 22 q3 -3 6 0 q3 -3 6 0'], ['ellipse', '#FFE3D3', 74, 12, 10, 3.5]] },
    { name: 'Hills at dawn', layers: [['rect', '#DCEFFF', 0, 0, 90, 90], ['circle', '#FFC857', 66, 26, 10], ['path', '#9ED3C4', 'M0 60 Q20 30 45 55 T90 45 V90 H0 Z'], ['path', '#4FA67C', 'M0 75 Q30 50 60 70 T90 66 V90 H0 Z'], ['path', '#2E7D5B', 'M0 86 Q40 72 90 84 V90 H0 Z'], ['path', '#FFFFFF', 'M14 20 q6 -6 12 0 q6 -4 10 2 H14 Z'], ['line', '#4A5A63', 'M38 12 q3 -3 6 0 q3 -3 6 0']] },
    { name: 'Lotus pond', layers: [['rect', '#BFE3FF', 0, 0, 90, 90], ['rect', '#7CC0EE', 0, 40, 90, 50], ['ellipse', '#4FA67C', 22, 70, 14, 5], ['ellipse', '#4FA67C', 66, 78, 12, 4], ['path', '#F28FA0', 'M45 58 Q38 44 45 34 Q52 44 45 58 Z'], ['path', '#F7A8B6', 'M45 58 Q30 50 32 40 Q42 46 45 58 Z'], ['path', '#F7A8B6', 'M45 58 Q60 50 58 40 Q48 46 45 58 Z'], ['ellipse', '#3E8E6A', 45, 60, 16, 4], ['ellipse', '#FFFFFF', 14, 14, 9, 3.5], ['line', '#4A5A63', 'M40 18 q3 -3 6 0 q3 -3 6 0'], ['ellipse', '#FFFFFF', 76, 24, 8, 3], ['ellipse', '#4FA67C', 12, 50, 7, 2.5]] },
    { name: 'Kites in the sky', layers: [['rect', '#8CC8F0', 0, 0, 90, 90], ['path', '#FFFFFF', 'M10 70 q8 -8 16 0 q8 -6 14 2 H10 Z'], ['path', '#F2A72B', 'M24 10 L34 22 L24 34 L14 22 Z'], ['path', '#D9465A', 'M62 28 L72 40 L62 52 L52 40 Z'], ['path', '#B9A3F0', 'M44 56 L52 66 L44 76 L36 66 Z'], ['path', 'none', 'M24 34 Q30 50 22 64'], ['path', '#FFFFFF', 'M58 78 q8 -8 16 0 q8 -6 14 2 H58 Z'], ['path', '#4FA67C', 'M76 6 L82 13 L76 20 L70 13 Z']] },
    { name: 'Night village', layers: [['rect', '#2B3A67', 0, 0, 90, 90], ['circle', '#FFF1C9', 70, 18, 8], ['circle', '#2B3A67', 74, 15, 7], ['circle', '#FFE9A8', 16, 14, 1.4], ['circle', '#FFE9A8', 40, 24, 1.2], ['circle', '#FFE9A8', 52, 10, 1.4], ['rect', '#3B4E85', 0, 60, 90, 30], ['rect', '#C98B5A', 12, 50, 20, 18], ['path', '#8E5A3C', 'M8 52 L22 40 L36 52 Z'], ['rect', '#C98B5A', 54, 46, 24, 22], ['path', '#8E5A3C', 'M50 48 L66 34 L82 48 Z'], ['rect', '#FFC857', 19, 56, 6, 6], ['rect', '#FFC857', 62, 54, 7, 7]] },
    { name: 'Boat on the backwaters', layers: [['rect', '#FFE3D3', 0, 0, 90, 46], ['circle', '#FFB088', 20, 30, 9], ['rect', '#9ED3C4', 0, 46, 90, 44], ['path', '#4FA67C', 'M60 46 L64 14 L66 46 Z'], ['path', '#2E7D5B', 'M64 16 q-12 -2 -18 6 q10 -2 18 -4 q8 -6 18 -2 q-10 -4 -18 0 Z'], ['path', '#8E5A3C', 'M26 62 Q45 72 64 62 Z'], ['path', '#C98B5A', 'M34 62 Q45 52 56 62 Z'], ['rect', '#6FB3E0', 10, 76, 30, 2], ['rect', '#6FB3E0', 50, 82, 30, 2], ['line', '#8E5A3C', 'M38 12 q3 -3 6 0 q3 -3 6 0'], ['rect', '#FFFFFF', 4, 52, 16, 1.5]] }
  ];
  function tilePicture(pic, box) {
    var s0 = document.createElementNS(SVGNS, 'svg');
    s0.setAttribute('viewBox', box);
    s0.setAttribute('aria-hidden', 'true');
    s0.setAttribute('preserveAspectRatio', 'none');
    pic.layers.forEach(function (l) {
      if (l[0] === 'rect') svg('rect', { x: l[2], y: l[3], width: l[4], height: l[5], fill: l[1] }, s0);
      else if (l[0] === 'circle') svg('circle', { cx: l[2], cy: l[3], r: l[4], fill: l[1] }, s0);
      else if (l[0] === 'ellipse') svg('ellipse', { cx: l[2], cy: l[3], rx: l[4], ry: l[5], fill: l[1] }, s0);
      else if (l[0] === 'line') svg('path', { d: l[2], fill: 'none', stroke: l[1], 'stroke-width': 1.4, 'stroke-linecap': 'round' }, s0);
      else svg('path', { d: l[2], fill: l[1], stroke: l[1] === 'none' ? '#FFFFFF' : 'none', 'stroke-width': 1 }, s0);
    });
    // Soft light from the left and shade towards the bottom, so no two tiles look the same.
    var n = ++tileShadeN, defs = svg('defs', {}, s0);
    var lx = svg('linearGradient', { id: 'tl' + n, gradientUnits: 'userSpaceOnUse', x1: 0, y1: 0, x2: 90, y2: 0 }, defs);
    svg('stop', { offset: 0, 'stop-color': '#FFFFFF', 'stop-opacity': 0.5 }, lx);
    svg('stop', { offset: 1, 'stop-color': '#FFFFFF', 'stop-opacity': 0 }, lx);
    var ly = svg('linearGradient', { id: 'ts' + n, gradientUnits: 'userSpaceOnUse', x1: 0, y1: 0, x2: 0, y2: 90 }, defs);
    svg('stop', { offset: 0, 'stop-color': '#10233A', 'stop-opacity': 0 }, ly);
    svg('stop', { offset: 1, 'stop-color': '#10233A', 'stop-opacity': 0.42 }, ly);
    svg('rect', { x: 0, y: 0, width: 90, height: 90, fill: 'url(#tl' + n + ')' }, s0);
    svg('rect', { x: 0, y: 0, width: 90, height: 90, fill: 'url(#ts' + n + ')' }, s0);
    return s0;
  }
  var tileShadeN = 0;
  function startTiles(stage) {
    var pic = TILE_PICS[game.set || 0];
    var grid = mkEl('div', 'tiles-grid');
    grid.id = 'tiles-grid';
    var order;
    // Shuffle until at least six tiles are away from home, so there is something to do.
    do { order = shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8]); } while (order.filter(function (p, i) { return p !== i; }).length < 6);
    game.order = order;
    game.pick = null;
    game.moves = 0;
    for (var i = 0; i < 9; i++) {
      var b = gameButton('tile', null);
      b.setAttribute('data-tile', String(i));
      b.addEventListener('click', (function (k) { return function () { tapTile(k); }; })(i));
      grid.appendChild(b);
    }
    var peek = gameButton('btn btn-ghost btn-small', 'Peek at the picture');
    peek.id = 'tiles-peek';
    peek.addEventListener('click', function () { peekTiles(); });
    stage.appendChild(grid);
    stage.appendChild(peek);
    setText('game-help', setLabel('tiles', game.set) + ': ' + pic.name + '. ' + GAMES.tiles.help);
    paintTiles();
  }
  function paintTiles() {
    var pic = TILE_PICS[game.set || 0];
    var tiles = document.querySelectorAll('#tiles-grid .tile');
    for (var i = 0; i < tiles.length; i++) {
      var p = game.order[i];
      tiles[i].textContent = '';
      tiles[i].appendChild(tilePicture(pic, (p % 3) * 30 + ' ' + Math.floor(p / 3) * 30 + ' 30 30'));
      tiles[i].classList.toggle('home', p === i);
      tiles[i].setAttribute('aria-pressed', String(game.pick === i));
      tiles[i].setAttribute('aria-label', 'Tile ' + (i + 1) + (p === i ? ', in place' : ''));
    }
    var n = game.order.filter(function (q, j) { return q === j; }).length;
    gameProgress(n + ' of 9 in place', n / 9);
  }
  function tapTile(i) {
    if (!game || game.id !== 'tiles' || game.done) return false;
    if (game.pick === null) { game.pick = i; haptic('light'); paintTiles(); return true; }
    if (game.pick === i) { game.pick = null; paintTiles(); return true; }
    var a = game.pick, t = game.order[a];
    game.order[a] = game.order[i];
    game.order[i] = t;
    game.pick = null;
    game.moves++;
    var home = (game.order[a] === a ? 1 : 0) + (game.order[i] === i ? 1 : 0);
    tone(home ? 600 : 420, home ? 760 : 380, 0.3, 0.04);
    haptic('light');
    paintTiles();
    if (game.order.every(function (q, j) { return q === j; })) {
      $('tiles-grid').classList.add('whole');
      $('tiles-peek').hidden = true;
      var moves = game.moves;
      game.timers.push(setTimeout(function () {
        finishGame('The picture is whole', 'Put together in ' + plural(moves, 'swap', 'swaps') + ', at your own pace. Look at it for a breath or two.');
      }, 600));
    }
    return true;
  }
  function peekTiles() {
    if (!game || game.id !== 'tiles' || game.done) return false;
    var grid = $('tiles-grid');
    grid.classList.add('peek');
    var over = mkEl('div', 'tiles-peek-pic');
    over.appendChild(tilePicture(TILE_PICS[game.set || 0], '0 0 90 90'));
    grid.appendChild(over);
    game.timers.push(setTimeout(function () { if (over.parentNode) over.parentNode.removeChild(over); grid.classList.remove('peek'); }, 1800));
    return true;
  }
  function solveTiles() {
    if (!game || game.id !== 'tiles') return;
    game.pick = null;
    for (var i = 0; i < 9; i++) {
      if (game.done) return;
      if (game.order[i] === i) continue;
      tapTile(i);
      tapTile(game.order.indexOf(i));
    }
  }

  // Wind Chimes: the chimes play a short tune; tap it back. Each round adds a note. A slip just plays it again.
  var CHIME_NOTES = [[523, '#F2A72B'], [587, '#F28FA0'], [659, '#B9A3F0'], [784, '#6FB3E0'], [880, '#4FA67C']];
  var CHIME_TUNES = [[0, 2, 4, 2, 0], [4, 3, 2, 1, 0], [0, 1, 2, 4, 3], [2, 0, 3, 1, 4], [0, 4, 3, 4, 2], [1, 3, 2, 0, 2]];
  var CHIME_ROUNDS = [3, 4, 5];
  function startChimes(stage) {
    var row = mkEl('div', 'chimes');
    row.id = 'chimes';
    CHIME_NOTES.forEach(function (n, i) {
      var b = gameButton('chime', null, 'Chime ' + (i + 1));
      b.setAttribute('data-chime', String(i));
      b.style.setProperty('--ch', n[1]);
      b.style.setProperty('--len', (150 - i * 18) + 'px');
      b.addEventListener('click', function () { tapChime(i); });
      row.appendChild(b);
    });
    var say = mkEl('p', 'chimes-say');
    say.id = 'chimes-say';
    say.setAttribute('aria-live', 'polite');
    var again = gameButton('btn btn-ghost btn-small', 'Hear it again');
    again.id = 'chimes-again';
    again.addEventListener('click', function () { playTune(); });
    stage.appendChild(row);
    stage.appendChild(say);
    stage.appendChild(again);
    game.tune = CHIME_TUNES[game.set || 0];
    game.round = 0;
    game.input = [];
    setText('game-help', setLabel('chimes', game.set) + '. ' + GAMES.chimes.help);
    game.timers.push(setTimeout(playTune, 600));
    updateChimes();
  }
  function ringChime(i, quiet) {
    var b = document.querySelector('#chimes [data-chime="' + i + '"]');
    if (b) { b.classList.remove('ring'); void b.offsetWidth; b.classList.add('ring'); }
    if (!quiet) tone(CHIME_NOTES[i][0], CHIME_NOTES[i][0] * 1.002, 1.1, 0.06);
  }
  function playTune() {
    if (!game || game.id !== 'chimes' || game.done) return false;
    var len = CHIME_ROUNDS[game.round];
    game.input = [];
    game.listening = true;
    setText('chimes-say', 'Listen...');
    for (var k = 0; k < len; k++) {
      game.timers.push(setTimeout((function (n) { return function () { if (game && game.id === 'chimes' && game.listening) ringChime(game.tune[n]); }; })(k), k * 650));
    }
    game.timers.push(setTimeout(function () { if (game && game.id === 'chimes' && game.listening) { game.listening = false; setText('chimes-say', 'Your turn. Tap the tune.'); } }, len * 650));
    return true;
  }
  function tapChime(i) {
    if (!game || game.id !== 'chimes' || game.done) return false;
    game.listening = false; // tapping during the tune means you have it already
    ringChime(i);
    haptic('light');
    var len = CHIME_ROUNDS[game.round], want = game.tune[game.input.length];
    if (i !== want) {
      game.input = [];
      setText('chimes-say', 'Close. Listen once more.');
      game.timers.push(setTimeout(playTune, 1100));
      return false;
    }
    game.input.push(i);
    if (game.input.length < len) return true;
    game.round++;
    game.input = [];
    updateChimes();
    if (game.round >= CHIME_ROUNDS.length) {
      setText('chimes-say', 'The whole tune.');
      game.timers.push(setTimeout(function () {
        finishGame('A tune of your own', 'You played the whole tune. Hum it once more, slowly, if you like.');
      }, 900));
    } else {
      setText('chimes-say', 'Lovely. One more note this time.');
      game.timers.push(setTimeout(playTune, 1300));
    }
    return true;
  }
  function updateChimes() { gameProgress('Round ' + Math.min(game.round + 1, CHIME_ROUNDS.length) + ' of ' + CHIME_ROUNDS.length, game.round / CHIME_ROUNDS.length); }
  function endChimes() {
    while (game && game.id === 'chimes' && game.round < CHIME_ROUNDS.length) tapChime(game.tune[game.input.length]);
  }

  // Spot the Odd One: one shape is a little different. Find it, round by round. Tapping another shape just fades it.
  var SPOT_ROUNDS = 8;
  var SPOT_SHAPES = [
    'M20 6a14 14 0 1 1 0 28 14 14 0 0 1 0-28z',
    'M20 34S6 25 6 15a7 7 0 0 1 14-2 7 7 0 0 1 14 2c0 10-14 19-14 19z',
    'M20 4l4.7 10 10.8 1.2-8 7.3 2.3 10.6L20 27.6l-9.8 5.5 2.3-10.6-8-7.3 10.8-1.2z',
    'M20 4C28 14 32 20 32 25a12 12 0 0 1-24 0c0-5 4-11 12-21z',
    'M8 32C8 16 18 6 34 6c0 16-10 26-26 26z'
  ];
  var SPOT_HUES = [36, 350, 200, 150, 265];
  function startSpot(stage) {
    var grid = mkEl('div', 'spot-grid');
    grid.id = 'spot-grid';
    stage.appendChild(grid);
    game.round = 0;
    spotRound();
  }
  function spotRound() {
    var r = game.round, side = r < 2 ? 3 : r < 5 ? 4 : 5, n = side * side;
    var grid = $('spot-grid');
    grid.textContent = '';
    grid.style.setProperty('--side', side);
    game.odd = Math.floor(rng() * n);
    var shape = r % SPOT_SHAPES.length, hue = SPOT_HUES[(r * 2) % SPOT_HUES.length];
    var way = ['light', 'turn', 'size'][r % 3];
    var step = Math.max(8, 20 - r * 1.6);
    for (var i = 0; i < n; i++) {
      var b = gameButton('spot', null, 'Shape ' + (i + 1));
      b.setAttribute('data-spot', String(i));
      var s0 = document.createElementNS(SVGNS, 'svg');
      s0.setAttribute('viewBox', '0 0 40 40');
      s0.setAttribute('aria-hidden', 'true');
      var odd = i === game.odd;
      var light = 62 - (odd && way === 'light' ? step : 0);
      var p = svg('path', { d: SPOT_SHAPES[shape], fill: 'hsl(' + hue + ', 62%, ' + light + '%)' }, s0);
      if (odd && way === 'turn') p.setAttribute('transform', 'rotate(' + (step * 2.2).toFixed(0) + ' 20 20)');
      if (odd && way === 'size') p.setAttribute('transform', 'translate(20 20) scale(' + (1 - step / 70).toFixed(2) + ') translate(-20 -20)');
      b.appendChild(s0);
      b.addEventListener('click', (function (k) { return function () { tapSpot(k); }; })(i));
      grid.appendChild(b);
    }
    gameProgress('Round ' + (r + 1) + ' of ' + SPOT_ROUNDS, r / SPOT_ROUNDS);
  }
  function tapSpot(i) {
    if (!game || game.id !== 'spot' || game.done) return false;
    var b = document.querySelector('#spot-grid [data-spot="' + i + '"]');
    if (i !== game.odd) {
      if (b) { b.classList.add('faded'); b.disabled = true; }
      haptic('light');
      return false;
    }
    if (b) b.classList.add('found');
    tone(520 + game.round * 40, 700 + game.round * 40, 0.35, 0.05);
    haptic('light');
    game.round++;
    if (game.round >= SPOT_ROUNDS) {
      gameProgress('Round ' + SPOT_ROUNDS + ' of ' + SPOT_ROUNDS, 1);
      game.timers.push(setTimeout(function () {
        finishGame('Well spotted', 'Eight rounds of quiet focus. Notice how your mind feels now.');
      }, 600));
    } else game.timers.push(setTimeout(function () { if (game && game.id === 'spot' && !game.done) spotRound(); }, 550));
    return true;
  }
  function endSpot() {
    while (game && game.id === 'spot' && game.round < SPOT_ROUNDS) { tapSpot(game.odd); if (game.round < SPOT_ROUNDS) spotRound(); }
  }

  // Calm Count: tap the numbers in order. Another number just wobbles, and you carry on.
  var COUNT_TO = 16;
  function startCount(stage) {
    var grid = mkEl('div', 'count-grid');
    grid.id = 'count-grid';
    var nums = [];
    for (var i = 1; i <= COUNT_TO; i++) nums.push(i);
    shuffle(nums).forEach(function (n, j) {
      var b = gameButton('count-num', String(n));
      b.setAttribute('data-num', String(n));
      b.style.setProperty('--tint', ['#FFF0C4', '#DCEFFF', '#FFE3EA', '#E2F3E8'][j % 4]);
      b.addEventListener('click', function () { tapCount(n); });
      grid.appendChild(b);
    });
    stage.appendChild(grid);
    game.next = 1;
    game.started = Date.now();
    updateCount();
  }
  function tapCount(n) {
    if (!game || game.id !== 'count' || game.done) return false;
    var b = document.querySelector('#count-grid [data-num="' + n + '"]');
    if (n !== game.next) {
      if (b) { b.classList.remove('wobble'); void b.offsetWidth; b.classList.add('wobble'); }
      return false;
    }
    if (b) { b.classList.add('found'); b.disabled = true; }
    tone(330 + n * 22, 340 + n * 22, 0.25, 0.04);
    haptic('light');
    game.next++;
    updateCount();
    if (game.next > COUNT_TO) {
      var secs = Math.max(1, Math.round((Date.now() - game.started) / 1000)), prev = (state.gameBest || {}).count || 0;
      game.timers.push(setTimeout(function () {
        finishGame('All sixteen, in order', 'You found every number in ' + plural(secs, 'second', 'seconds') + (prev && secs < prev ? ', your quickest yet.' : '.') + ' Let your eyes rest for a breath.',
          function () { if (!prev || secs < prev) state.gameBest.count = secs; });
      }, 400));
    }
    return true;
  }
  function updateCount() {
    var found = game.next - 1;
    gameProgress(found < COUNT_TO ? 'Find ' + game.next : COUNT_TO + ' of ' + COUNT_TO + ' found', found / COUNT_TO);
  }

  // Sky Lanterns: press and hold a lantern while you breathe in. When it is fully lit, it floats away.
  var LANTERN_WORDS = ['Rush', 'Noise', 'That email', 'Overthinking', 'Hurry', 'Tiredness', 'Clutter', 'Doubt', 'Old hurt', 'Too much to do', 'Scrolling', 'Hard words'];
  var LANTERN_COUNT = 6, LANTERN_MS = 3000;
  function startLantern(stage) {
    var sky = mkEl('div', 'lantern-sky');
    sky.id = 'lantern-sky';
    var words = shuffle(LANTERN_WORDS.slice()).slice(0, LANTERN_COUNT);
    game.lit = 0;
    game.held = {};
    words.forEach(function (w, i) {
      var b = gameButton('lantern', null, 'Lantern: ' + w);
      b.setAttribute('data-lantern', String(i));
      // Two staggered rows of three, so each lantern has room on a small phone.
      b.style.left = [18, 50, 82][i % 3] + '%';
      b.style.bottom = (i < 3 ? 22 : 128) + 'px';
      b.style.setProperty('--glow', '0');
      b.appendChild(mkEl('span', 'lantern-word', w));
      var start = function (e) { if (e) e.preventDefault(); holdLantern(i); };
      var stop = function () { letLantern(i); };
      b.addEventListener('pointerdown', start);
      b.addEventListener('pointerup', stop);
      b.addEventListener('pointerleave', stop);
      b.addEventListener('pointercancel', stop);
      b.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && !e.repeat) start(e); });
      b.addEventListener('keyup', function (e) { if (e.key === 'Enter' || e.key === ' ') stop(); });
      sky.appendChild(b);
    });
    stage.appendChild(sky);
    game.timers.push(setInterval(lanternTick, 50));
    updateLantern();
  }
  function holdLantern(i) {
    if (!game || game.id !== 'lantern' || game.done) return false;
    var h = game.held[i] || (game.held[i] = { glow: 0, holding: false, gone: false });
    if (h.gone) return false;
    h.holding = true;
    return true;
  }
  function letLantern(i) {
    var h = game && game.id === 'lantern' && game.held[i];
    if (h) h.holding = false;
  }
  function lanternTick() {
    if (!game || game.id !== 'lantern' || game.done) return;
    Object.keys(game.held).forEach(function (k) {
      var h = game.held[k];
      if (h.gone) return;
      h.glow = Math.max(0, Math.min(1, h.glow + (h.holding ? 50 / LANTERN_MS : -50 / 1200)));
      var b = document.querySelector('#lantern-sky [data-lantern="' + k + '"]');
      if (b) b.style.setProperty('--glow', h.glow.toFixed(2));
      if (h.glow >= 1) releaseLantern(+k);
    });
  }
  // Fully lit: up it goes.
  function releaseLantern(i) {
    if (!game || game.id !== 'lantern' || game.done) return false;
    var h = game.held[i] || (game.held[i] = { glow: 1, holding: false, gone: false });
    if (h.gone) return false;
    h.gone = true;
    h.holding = false;
    var b = document.querySelector('#lantern-sky [data-lantern="' + i + '"]');
    if (b) { b.classList.add('away'); b.disabled = true; b.style.setProperty('--glow', '1'); }
    tone(392, 523, 1.2, 0.05);
    haptic('light');
    game.lit++;
    updateLantern();
    if (game.lit >= LANTERN_COUNT) {
      game.timers.push(setTimeout(function () {
        finishGame('The sky holds them now', 'Six lanterns, six slow breaths. Let your shoulders drop as you watch them go.');
      }, 1200));
    }
    return true;
  }
  function updateLantern() { gameProgress(game.lit + ' of ' + LANTERN_COUNT + ' released', game.lit / LANTERN_COUNT); }
  function endLantern() { for (var i = 0; i < LANTERN_COUNT; i++) releaseLantern(i); }

  // Ripple Pond: tap the water. Rings spread out and fade; the fish drift by.
  var POND_TAPS = 15;
  function startPond(stage) {
    var pond = mkEl('div', 'pond');
    pond.id = 'pond';
    pond.setAttribute('role', 'button');
    pond.setAttribute('tabindex', '0');
    pond.setAttribute('aria-label', 'Pond. Tap the water.');
    [['#F2A72B', 0], ['#FFFFFF', 1], ['#D9465A', 2]].forEach(function (f) {
      var fish = document.createElementNS(SVGNS, 'svg');
      fish.setAttribute('viewBox', '0 0 40 20');
      fish.setAttribute('class', 'koi koi-' + f[1]);
      fish.setAttribute('aria-hidden', 'true');
      svg('path', { d: 'M4 10 Q14 2 26 10 Q14 18 4 10 Z', fill: f[0] }, fish);
      svg('path', { d: 'M26 10 L36 4 L34 10 L36 16 Z', fill: f[0] }, fish);
      pond.appendChild(fish);
    });
    pond.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      var r = pond.getBoundingClientRect();
      rippleAt(r.width ? (e.clientX - r.left) / r.width * 100 : 50, r.height ? (e.clientY - r.top) / r.height * 100 : 50);
    });
    pond.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); rippleAt(20 + rng() * 60, 20 + rng() * 60); } });
    stage.appendChild(pond);
    game.ripples = 0;
    updatePond();
  }
  function rippleAt(x, y) {
    if (!game || game.id !== 'pond' || game.done) return false;
    var pond = $('pond');
    for (var k = 0; k < 3; k++) {
      var r = mkEl('i', 'ripple');
      r.style.left = x + '%';
      r.style.top = y + '%';
      r.style.animationDelay = (k * 0.35) + 's';
      pond.appendChild(r);
      game.timers.push(setTimeout((function (el) { return function () { if (el.parentNode) el.parentNode.removeChild(el); }; })(r), 3200));
    }
    if (game.ripples % 4 === 3) {
      var pad = mkEl('i', 'lily');
      pad.style.left = x + '%';
      pad.style.top = y + '%';
      pond.appendChild(pad);
    }
    tone(700 - y * 3, 500 - y * 2, 0.6, 0.04);
    haptic('light');
    game.ripples++;
    updatePond();
    if (game.ripples >= POND_TAPS) {
      game.timers.push(setTimeout(function () {
        finishGame('Still water', 'Fifteen ripples, each one fading into stillness. Rest your eyes on the water for a moment.');
      }, 1500));
    }
    return true;
  }
  function updatePond() { gameProgress(Math.min(game.ripples, POND_TAPS) + ' of ' + POND_TAPS + ' ripples', game.ripples / POND_TAPS); }
  function endPond() { while (game && game.id === 'pond' && !game.done && game.ripples < POND_TAPS) rippleAt(50, 50); }

  // Mirror Mandala: every line you draw is mirrored around the centre, sixteen times.
  var MANDALA_SIZE = 360, MANDALA_LINES = 8;
  var MANDALA_INKS = [['Marigold', '#F2A72B'], ['Rose', '#F28FA0'], ['Sky', '#6FB3E0'], ['Leaf', '#4FA67C'], ['Lilac', '#B9A3F0'], ['Moon', '#FFF8EC']];
  function startMandala(stage) {
    var wrap = mkEl('div', 'mandala-stage');
    var cv = mkEl('canvas', 'mandala-canvas');
    cv.id = 'mandala-canvas';
    cv.width = MANDALA_SIZE;
    cv.height = MANDALA_SIZE;
    cv.setAttribute('role', 'img');
    cv.setAttribute('aria-label', 'Mandala');
    var inks = mkEl('div', 'rangoli-palette');
    inks.setAttribute('role', 'group');
    inks.setAttribute('aria-label', 'Colours');
    MANDALA_INKS.forEach(function (c, i) {
      var b = gameButton('swatch', null, c[0]);
      b.style.setProperty('--sw', c[1]);
      b.setAttribute('data-ink', String(i));
      b.setAttribute('aria-pressed', String(i === 0));
      b.addEventListener('click', function () {
        game.ink = i;
        var all = inks.querySelectorAll('.swatch');
        for (var k = 0; k < all.length; k++) all[k].setAttribute('aria-pressed', String(k === i));
      });
      inks.appendChild(b);
    });
    var clear = gameButton('btn btn-ghost btn-small', 'Start fresh');
    clear.id = 'mandala-clear';
    clear.addEventListener('click', function () { paintMandalaBase(); });
    wrap.appendChild(cv);
    wrap.appendChild(inks);
    wrap.appendChild(clear);
    stage.appendChild(wrap);
    game.ink = 0;
    game.lines = 0;
    game.stroke = null;
    try { game.ctx = cv.getContext ? cv.getContext('2d') : null; } catch (e) { game.ctx = null; }
    paintMandalaBase();
    var at = function (e) {
      var r = cv.getBoundingClientRect();
      return { x: r.width ? (e.clientX - r.left) * MANDALA_SIZE / r.width : 0, y: r.height ? (e.clientY - r.top) * MANDALA_SIZE / r.height : 0 };
    };
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      if (cv.setPointerCapture) { try { cv.setPointerCapture(e.pointerId); } catch (x) { /* optional */ } }
      game.stroke = [at(e)];
    });
    cv.addEventListener('pointermove', function (e) {
      if (!game || !game.stroke) return;
      var p = at(e), q = game.stroke[game.stroke.length - 1];
      mandalaSegment(q, p);
      game.stroke.push(p);
    });
    var end = function () { if (game && game.stroke) { var s = game.stroke; game.stroke = null; mandalaCount(s); } };
    cv.addEventListener('pointerup', end);
    cv.addEventListener('pointercancel', end);
    updateMandala();
  }
  function paintMandalaBase() {
    var c = game && game.ctx;
    if (!c) return;
    c.fillStyle = '#1E2A4A';
    c.fillRect(0, 0, MANDALA_SIZE, MANDALA_SIZE);
    c.strokeStyle = 'rgba(255,255,255,0.08)';
    c.lineWidth = 1;
    for (var k = 0; k < 8; k++) {
      var a = k * Math.PI / 4;
      c.beginPath();
      c.moveTo(MANDALA_SIZE / 2, MANDALA_SIZE / 2);
      c.lineTo(MANDALA_SIZE / 2 + Math.cos(a) * MANDALA_SIZE, MANDALA_SIZE / 2 + Math.sin(a) * MANDALA_SIZE);
      c.stroke();
    }
  }
  function mandalaSegment(p, q) {
    var c = game && game.ctx;
    if (!c) return;
    var h = MANDALA_SIZE / 2;
    c.strokeStyle = MANDALA_INKS[game.ink][1];
    c.lineWidth = 3;
    c.lineCap = 'round';
    for (var k = 0; k < 8; k++) {
      for (var m = 0; m < 2; m++) {
        c.save();
        c.translate(h, h);
        c.rotate(k * Math.PI / 4);
        if (m) c.scale(1, -1);
        c.beginPath();
        c.moveTo(p.x - h, p.y - h);
        c.lineTo(q.x - h, q.y - h);
        c.stroke();
        c.restore();
      }
    }
  }
  // A line counts once it has some length; taps alone do not.
  function mandalaCount(points) {
    if (!game || game.id !== 'mandala' || game.done) return false;
    var len = 0;
    for (var i = 1; i < points.length; i++) len += Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y);
    if (len < 30) return false;
    game.lines++;
    tone(480 + game.lines * 30, 520 + game.lines * 30, 0.4, 0.035);
    updateMandala();
    if (game.lines >= MANDALA_LINES) {
      game.timers.push(setTimeout(function () {
        finishGame('A mandala of your own', 'Look at it for a few slow breaths. Every line came from you.');
      }, 600));
    }
    return true;
  }
  // Draws a whole line at once (used by tests and the keyboard).
  function mandalaStroke(points) {
    if (!game || game.id !== 'mandala' || game.done || !points || points.length < 1) return false;
    for (var i = 1; i < points.length; i++) mandalaSegment(points[i - 1], points[i]);
    return mandalaCount(points);
  }
  function updateMandala() { gameProgress(Math.min(game.lines, MANDALA_LINES) + ' of ' + MANDALA_LINES + ' lines', game.lines / MANDALA_LINES); }
  function endMandala() {
    var k = 0;
    while (game && game.id === 'mandala' && !game.done && k < MANDALA_LINES) {
      var a = k * 0.4;
      mandalaStroke([{ x: 180 + Math.cos(a) * 30, y: 180 + Math.sin(a) * 30 }, { x: 180 + Math.cos(a) * 140, y: 180 + Math.sin(a + 0.5) * 140 }]);
      k++;
    }
  }

  function endRangoli() { if (game && game.id === 'rangoli') game.rings.forEach(function (c, i) { if (c == null) colourRing(i); }); }
  function endCount() { while (game && game.id === 'count' && game.next <= COUNT_TO) tapCount(game.next); }

  function finishCurrentGame() {
    if (!game) return;
    if (game.id === 'pairs') {
      game.deck.forEach(function (c, i) { c.done = true; c.open = false; paintCard(i); });
      updatePairsScore();
      finishGame('All pairs matched', 'You matched 6 pairs in ' + plural(game.moves, 'move', 'moves') + '.');
    } else if (game.id === 'catch') endCatch();
    else if (game.id === 'pop') { var bs = document.querySelectorAll('#pop-field .bubble'); for (var i = 0; i < bs.length; i++) popBubble(bs[i]); }
    else if (game.id === 'sort') game.stones.forEach(function (st, j) { sortStone(j, st.kind); });
    else if (game.id === 'sand') endSand();
    else if (game.id === 'stars') endStars();
    else if (game.id === 'stack') { while (game && !game.done && game.moving) dropBlock(); }
    else if (game.id === 'kind') { while (game && game.kept.length < KIND_PICK && pickKind(0)) { /* the first free word each time */ } }
    else if (game.id === 'rangoli') endRangoli();
    else if (game.id === 'tiles') solveTiles();
    else if (game.id === 'chimes') endChimes();
    else if (game.id === 'spot') endSpot();
    else if (game.id === 'count') endCount();
    else if (game.id === 'lantern') endLantern();
    else if (game.id === 'pond') endPond();
    else if (game.id === 'mandala') endMandala();
    else endBloom();
  }


  /* ---------- Toolkit: support, safety plan, reframe, sounds, wellbeing, backup ---------- */

  var TOOL_SCREENS = ['support', 'safety', 'reframe', 'wellbeing'];
  function toolXp(points) {
    var dk = dayKey(now());
    if (state.toolXp.day !== dk) state.toolXp = { day: dk, count: 0 };
    if (state.toolXp.count >= 3) return false;
    state.toolXp.count++;
    state.xp += points;
    return true;
  }
  function isIos() {
    var ua = navigator.userAgent || '';
    return /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  }

  // Find support
  var DEFAULT_PROS = HL.safetyPlanText;
  function renderSupport() {
    var links = document.querySelectorAll('[data-near]');
    for (var i = 0; i < links.length; i++) {
      var q = links[i].getAttribute('data-near') + ' near me';
      links[i].setAttribute('href', isIos() ? 'https://maps.apple.com/?q=' + encodeURIComponent(q) : 'https://www.google.com/maps/search/' + encodeURIComponent(q).replace(/%20/g, '+'));
    }
    renderCare(false);
    renderMatch();
    renderPartners();
    renderInPerson();
  }
  function renderCare(editing) {
    var c = state.careTeam;
    $('care-view').hidden = !c || editing;
    $('care-form').hidden = !!c && !editing;
    if (c) {
      setText('care-name', c.name);
      setText('care-role', c.role);
      $('care-call').setAttribute('href', 'tel:' + c.phone);
      $('care-call').hidden = !c.phone;
      var when = c.next ? new Date(c.next) : null;
      setText('care-next', when && !isNaN(when) ? 'Next session: ' + when.toLocaleString(locale(), { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'No session booked yet.');
      if (editing) {
        $('care-name-input').value = c.name; $('care-role-input').value = c.role;
        $('care-phone-input').value = c.phone; $('care-next-input').value = c.next || '';
      }
    }
  }
  function saveCare() {
    var name = ($('care-name-input').value || '').trim().slice(0, 60);
    if (!name) { toast('Add their name first.'); return; }
    var phone = ($('care-phone-input').value || '').replace(/[^\d+]/g, '').replace(/(?!^)\+/g, '');
    state.careTeam = { name: name, role: $('care-role-input').value || 'Therapist', phone: phone, next: $('care-next-input').value || '' };
    save();
    renderCare(false);
    scheduleCareReminder();
    toast('Saved to your care team.');
  }
  function scheduleCareReminder() {
    var LN = nativeNotifications();
    var c = state.careTeam;
    if (!LN || !c || !c.next) return;
    var at = new Date(new Date(c.next).getTime() - 60 * 60 * 1000);
    if (isNaN(at) || at <= now()) return;
    LN.cancel({ notifications: [{ id: 2 }] }).catch(function () {}).then(function () {
      return LN.schedule({ notifications: [{ id: 2, title: tr('Your session is in an hour'), body: tr(c.name + ' at ' + new Date(c.next).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) + '. You are doing something kind for yourself.'), schedule: { at: at } }] });
    }).catch(function () {});
  }
  function copyScript() {
    var t = $('first-call-script').textContent;
    var ok = function () { toast('Copied. Paste it into a message or keep it handy for the call.'); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, function () { toast('Hold to select the text and copy it.'); });
    else toast('Hold to select the text and copy it.');
  }

  // Safety plan
  function renderSafety() {
    var plan = state.safetyPlan || {};
    var fields = document.querySelectorAll('[data-sp]');
    for (var i = 0; i < fields.length; i++) {
      var k = fields[i].getAttribute('data-sp');
      fields[i].value = plan[k] != null ? plan[k] : (k === 'pros' ? DEFAULT_PROS : '');
    }
    setText('sp-saved', state.safetyPlan ? 'Saved on this device.' : 'Nothing is saved until you tap Save.');
  }
  function saveSafety() {
    var plan = {};
    var fields = document.querySelectorAll('[data-sp]');
    for (var i = 0; i < fields.length; i++) plan[fields[i].getAttribute('data-sp')] = (fields[i].value || '').slice(0, 1200);
    plan.updated = now().getTime();
    state.safetyPlan = plan;
    save();
    setText('sp-saved', 'Saved on this device. It is one tap away from SOS.');
    haptic('success');
    toast('Your safety plan is saved.');
  }

  // Reframe a thought: nothing is stored except an optional kinder thought.
  var rf = { step: 1 };
  function startReframe() {
    rf = { step: 1 };
    var areas = document.querySelectorAll('.rf');
    for (var i = 0; i < areas.length; i++) areas[i].value = '';
    $('rf-before').value = '6'; $('rf-after').value = '6';
    setText('rf-before-out', '6'); setText('rf-after-out', '6');
    $('rf-result').hidden = true; $('rf-keep').hidden = true; $('rf-next').hidden = false;
    showRf();
  }
  function showRf() {
    var panes = document.querySelectorAll('[data-rf]');
    for (var i = 0; i < panes.length; i++) panes[i].hidden = +panes[i].getAttribute('data-rf') !== rf.step;
    setText('rf-step', rf.step <= 5 ? 'Step ' + rf.step + ' of 5' : 'Done');
    setText('rf-next', rf.step < 5 ? 'Next' : 'Finish');
  }
  function rfNext() {
    var need = { 1: 'rf-situation', 2: 'rf-thought', 5: 'rf-kinder' }[rf.step];
    if (need && !($(need).value || '').trim()) { toast('Write a few words first. Any words are welcome.'); return; }
    if (rf.step === 5) {
      var b = +$('rf-before').value, a = +$('rf-after').value;
      rf.kinder = ($('rf-kinder').value || '').trim().slice(0, 200);
      state.reframes = (state.reframes || 0) + 1;
      var got = toolXp(3);
      save();
      setText('rf-result', a < b ? 'From ' + b + ' to ' + a + '. That is a real shift, and you made it.'
        : 'Some thoughts take a few tries. You did the work, and that counts.');
      $('rf-result').hidden = false; $('rf-keep').hidden = false; $('rf-next').hidden = true;
      var panes = document.querySelectorAll('[data-rf]');
      for (var i = 0; i < panes.length; i++) panes[i].hidden = true;
      setText('rf-step', 'Done');
      var areas = document.querySelectorAll('.rf');
      for (var j = 0; j < areas.length; j++) areas[j].value = '';
      haptic('success');
      return;
    }
    rf.step++;
    showRf();
  }
  function keepKinder() {
    if (!rf.kinder) return;
    state.goodThings.push({ day: dayKey(now()), text: 'Kinder thought: ' + rf.kinder });
    rf.kinder = '';
    save();
    $('rf-keep').hidden = true;
    toast('Kept in your Good things jar.');
  }
  function onRfInput(e) {
    if (isCrisis(e.target.value)) { e.target.value = ''; openSupport(); }
  }

  // Calm sounds, generated with Web Audio (no files, works offline).
  var audio = null;
  function noiseBuffer(ctx, brown) {
    var len = ctx.sampleRate * 4, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0), last = 0;
    for (var i = 0; i < len; i++) {
      var w = Math.random() * 2 - 1;
      if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w;
    }
    return buf;
  }
  function soundVolume() { return Math.max(0, Math.min(1, +$('sound-volume').value / 100)) * 0.6; }
  function playSound(kind, vol) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { setText('sound-status', 'Sounds are not available on this device.'); return false; }
    stopSound(true);
    var ctx = new AC();
    var src = ctx.createBufferSource();
    src.buffer = noiseBuffer(ctx, kind === 'brown' || kind === 'ocean');
    src.loop = true;
    var out = ctx.createGain();
    out.gain.value = 0;
    var node = src;
    if (kind === 'rain') {
      var hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 500;
      var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 6000;
      node.connect(hp); hp.connect(lp); node = lp;
    } else if (kind === 'breeze') {
      var bp = ctx.createBiquadFilter(); bp.type = 'lowpass'; bp.frequency.value = 900;
      var lfo = ctx.createOscillator(); lfo.frequency.value = 0.07;
      var depth = ctx.createGain(); depth.gain.value = 500;
      lfo.connect(depth); depth.connect(bp.frequency); lfo.start();
      node.connect(bp); node = bp;
    }
    var swell = ctx.createGain(); swell.gain.value = 1;
    if (kind === 'ocean') {
      var wave = ctx.createOscillator(); wave.frequency.value = 0.09;
      var wdepth = ctx.createGain(); wdepth.gain.value = 0.45;
      wave.connect(wdepth); wdepth.connect(swell.gain); wave.start();
    }
    node.connect(swell); swell.connect(out); out.connect(ctx.destination);
    src.start();
    out.gain.linearRampToValueAtTime(vol != null ? vol * 0.6 : soundVolume(), ctx.currentTime + 2.5);
    audio = { ctx: ctx, out: out, kind: kind, timer: null };
    var btns = document.querySelectorAll('[data-sound]');
    for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', String(btns[i].getAttribute('data-sound') === kind));
    setSleepTimer(currentTimer);
    setText('sound-status', 'Playing. Keep LoosenUp open while it plays.');
    return true;
  }
  function stopSound(quick) {
    if (!audio) return;
    var a = audio;
    audio = null;
    clearTimeout(a.timer);
    try {
      a.out.gain.cancelScheduledValues(a.ctx.currentTime);
      a.out.gain.setValueAtTime(a.out.gain.value, a.ctx.currentTime);
      a.out.gain.linearRampToValueAtTime(0, a.ctx.currentTime + (quick ? 0.2 : 3));
      setTimeout(function () { try { a.ctx.close(); } catch (e) { /* already closed */ } }, quick ? 300 : 3200);
    } catch (e) { /* audio already gone */ }
    var btns = document.querySelectorAll('[data-sound]');
    for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', 'false');
    setText('sound-status', 'Stopped. Tap a sound to begin again.');
  }
  function fadeSound(sec) {
    if (!audio) return;
    var a = audio;
    audio = null;
    clearTimeout(a.timer);
    try {
      a.out.gain.cancelScheduledValues(a.ctx.currentTime);
      a.out.gain.setValueAtTime(a.out.gain.value, a.ctx.currentTime);
      a.out.gain.linearRampToValueAtTime(0, a.ctx.currentTime + sec);
      setTimeout(function () { try { a.ctx.close(); } catch (e) { /* already closed */ } }, sec * 1000 + 200);
    } catch (e) { /* audio already gone */ }
  }
  var currentTimer = 0;
  function setSleepTimer(min) {
    currentTimer = min;
    var chips = document.querySelectorAll('[data-timer]');
    for (var i = 0; i < chips.length; i++) chips[i].setAttribute('aria-pressed', String(+chips[i].getAttribute('data-timer') === min));
    if (audio) {
      clearTimeout(audio.timer);
      if (min > 0) audio.timer = setTimeout(function () { stopSound(false); }, min * 60 * 1000);
    }
  }

  // Wellbeing check: WHO-5 Wellbeing Index (0 to 100).
  var WHO5 = ['I have felt cheerful and in good spirits', 'I have felt calm and relaxed', 'I have felt active and full of energy',
    'I woke up feeling fresh and rested', 'My daily life has been filled with things that interest me'];
  var WHO5_SCALE = ['At no time', 'Some of the time', 'Less than half of the time', 'More than half of the time', 'Most of the time', 'All of the time'];
  var wbAnswers = [];
  function renderWellbeing() {
    wbAnswers = [null, null, null, null, null];
    var box = $('wb-items');
    box.textContent = '';
    var legend = document.createElement('p');
    legend.className = 'fine';
    legend.textContent = '0 = at no time, 5 = all of the time';
    box.appendChild(legend);
    WHO5.forEach(function (q, qi) {
      var card = document.createElement('div');
      card.className = 'card wb-item';
      var t = document.createElement('p');
      t.className = 'field-label';
      t.textContent = (qi + 1) + '. ' + q;
      var row = document.createElement('div');
      row.className = 'wb-scale';
      row.setAttribute('role', 'group');
      row.setAttribute('aria-label', q);
      for (var v = 0; v <= 5; v++) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'wb-opt';
        b.setAttribute('data-wb', qi + ':' + v);
        b.setAttribute('aria-pressed', 'false');
        b.setAttribute('aria-label', WHO5_SCALE[v]);
        b.textContent = String(v);
        row.appendChild(b);
      }
      card.appendChild(t); card.appendChild(row);
      box.appendChild(card);
    });
    $('wb-result').hidden = true;
    renderWbTrend();
  }
  function answerWb(qi, v) {
    wbAnswers[qi] = v;
    var btns = document.querySelectorAll('[data-wb^="' + qi + ':"]');
    for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', String(btns[i].getAttribute('data-wb') === qi + ':' + v));
  }
  function wellbeingNote(score) {
    if (score >= 72) return 'Your wellbeing looks bright. Keep the small habits that got you here.';
    if (score >= 52) return 'Steady. Calm breaks and Small steps help keep it that way.';
    if (score > 28) return 'Your wellbeing has been lower than usual. Talking to a professional can really help, and reaching out early makes a difference.';
    return 'These two weeks have been really heavy. Please consider talking to a professional soon. Tele-MANAS (14416) is free and open 24x7.';
  }
  function submitWb() {
    if (wbAnswers.some(function (a) { return a == null; })) { toast('Answer all five. Every answer is welcome.'); return; }
    var score = wbAnswers.reduce(function (x, y) { return x + y; }, 0) * 4;
    var dk = dayKey(now());
    state.wellbeing = state.wellbeing.filter(function (w) { return w.day !== dk; });
    state.wellbeing.push({ day: dk, score: score });
    toolXp(5);
    save();
    setText('wb-score', String(score));
    setText('wb-note', wellbeingNote(score));
    $('wb-support').hidden = score > 50;
    $('wb-result').hidden = false;
    renderWbTrend();
    haptic('success');
    if (score <= 28) openSupport();
  }
  function renderWbTrend() {
    var ul = $('wb-trend');
    ul.textContent = '';
    var list = state.wellbeing.slice(-6).reverse();
    if (!list.length) { var li0 = document.createElement('li'); li0.textContent = 'Your first check will appear here.'; ul.appendChild(li0); return; }
    list.forEach(function (w) {
      var li = document.createElement('li');
      var a = document.createElement('span'); a.textContent = new Date(w.day + 'T12:00:00').toLocaleDateString(locale(), { day: 'numeric', month: 'short' });
      var g = document.createElement('span'); g.className = 'g'; g.textContent = w.score + ' / 100';
      li.appendChild(a); li.appendChild(g); ul.appendChild(li);
    });
  }
  function checkDue() {
    if (breaksDone() < 2) return false;
    var last = state.wellbeing[state.wellbeing.length - 1];
    return !last || daysBetween(last.day, dayKey(now())) >= 14;
  }

  // Backup and restore
  function exportBackup() {
    var data = JSON.stringify({ app: 'LoosenUp', version: VERSION, exportedAt: now().toISOString(), state: state }, null, 2);
    var name = 'loosenup-backup-' + dayKey(now()) + '.json';
    var done = function () { setText('backup-status', 'Backup saved as ' + name + '. Keep it somewhere safe.'); };
    try {
      var file = typeof File === 'function' ? new File([data], name, { type: 'application/json' }) : null;
      if (file && navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
        return navigator.share({ files: [file], title: 'LoosenUp backup' }).then(done, function () {});
      }
      var a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
      a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      done();
    } catch (e) { setText('backup-status', 'Could not create the file on this device.'); }
    return Promise.resolve();
  }
  function restoreBackup(text) {
    var obj;
    try { obj = JSON.parse(text); } catch (e) { setText('backup-status', 'That file is not a LoosenUp backup.'); return false; }
    if (!obj || obj.app !== 'LoosenUp' || !obj.state || typeof obj.state !== 'object' || !Array.isArray(obj.state.sessions)) {
      setText('backup-status', 'That file is not a LoosenUp backup.'); return false;
    }
    try { window.localStorage.setItem(KEY + '.before-restore', JSON.stringify(state)); } catch (e) { /* storage full */ }
    var fresh = freshState();
    for (var k in fresh) if (Object.prototype.hasOwnProperty.call(obj.state, k)) fresh[k] = obj.state[k];
    state = fresh;
    save();
    setText('backup-status', 'Restored. Welcome back' + (state.name ? ', ' + state.name : '') + '.');
    renderSeedPill();
    return true;
  }
  function onImport(e) {
    var f = e.target.files && e.target.files[0];
    if (!f) return;
    var r = new FileReader();
    r.onload = function () { restoreBackup(String(r.result)); e.target.value = ''; };
    r.readAsText(f);
  }

  /* ---------- App lock ---------- */
  // Compact SHA-256 so the PIN is only ever stored as a salted hash.
  function sha256(msg) {
    function rr(n, x) { return (x >>> n) | (x << (32 - n)); }
    var K = [], H = [], primes = 0, cand = 2;
    var isPrime = function (n) { for (var f = 2; f * f <= n; f++) if (n % f === 0) return false; return true; };
    while (primes < 64) { if (isPrime(cand)) { if (primes < 8) H[primes] = (Math.pow(cand, 1 / 2) * 4294967296) | 0; K[primes] = (Math.pow(cand, 1 / 3) * 4294967296) | 0; primes++; } cand++; }
    var bytes = unescape(encodeURIComponent(msg)), l = bytes.length, words = [];
    for (var i = 0; i < l; i++) words[i >> 2] |= bytes.charCodeAt(i) << ((3 - i % 4) * 8);
    words[l >> 2] |= 0x80 << ((3 - l % 4) * 8);
    words[((l + 8) >> 6 << 4) + 15] = l * 8;
    for (var j = 0; j < words.length; j += 16) {
      var w = words.slice(j, j + 16), o = H.slice(0);
      for (var t = 0; t < 64; t++) {
        if (t >= 16) {
          var w15 = w[t - 15] | 0, w2 = w[t - 2] | 0;
          w[t] = ((w[t - 16] | 0) + (rr(7, w15) ^ rr(18, w15) ^ (w15 >>> 3)) + (w[t - 7] | 0) + (rr(17, w2) ^ rr(19, w2) ^ (w2 >>> 10))) | 0;
        }
        var e = H[4], t1 = H[7] + (rr(6, e) ^ rr(11, e) ^ rr(25, e)) + ((e & H[5]) ^ (~e & H[6])) + K[t] + (w[t] | 0);
        var a0 = H[0], t2 = (rr(2, a0) ^ rr(13, a0) ^ rr(22, a0)) + ((a0 & H[1]) ^ (a0 & H[2]) ^ (H[1] & H[2]));
        H = [(t1 + t2) | 0].concat(H); H[4] = (H[4] + t1) | 0; H.pop();
      }
      for (var q = 0; q < 8; q++) H[q] = (H[q] + o[q]) | 0;
    }
    var hex = '';
    for (var z = 0; z < 8; z++) for (var y = 3; y >= 0; y--) { var b = (H[z] >>> (y * 8)) & 255; hex += (b < 16 ? '0' : '') + b.toString(16); }
    return hex;
  }
  function randomSalt() {
    var arr = new Uint8Array(16);
    try { window.crypto.getRandomValues(arr); } catch (e) { for (var i = 0; i < 16; i++) arr[i] = Math.floor(Math.random() * 256); }
    return Array.prototype.map.call(arr, function (x) { return (x < 16 ? '0' : '') + x.toString(16); }).join('');
  }
  function pinHash(pin, salt) { return sha256(salt + ':' + pin); }
  function lockEnabled() { return !!(state.lock && state.lock.enabled && state.lock.hash); }
  var lockFails = 0, lockUntil = 0, hiddenAt = 0;
  function bioPlugin() { return isNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.NativeBiometric; }
  function showLock() {
    if (!lockEnabled()) return;
    $('lock-screen').hidden = false;
    document.body.classList.add('locked');
    $('lock-pin').value = '';
    setText('lock-msg', '');
    $('lock-reset').hidden = true;
    var B = bioPlugin();
    $('lock-bio').hidden = !(B && state.lock.bio);
    if (B && state.lock.bio) tryBio();
  }
  function hideLock() {
    $('lock-screen').hidden = true;
    document.body.classList.remove('locked');
    document.body.classList.remove('lock-sos');
    lockFails = 0;
  }
  function isLocked() { return !$('lock-screen').hidden; }
  function tryUnlock() {
    var pin = ($('lock-pin').value || '').trim();
    if (Date.now() < lockUntil) { setText('lock-msg', 'Take a breath. You can try again in a few seconds.'); return false; }
    if (pinHash(pin, state.lock.salt) === state.lock.hash) { hideLock(); haptic('success'); return true; }
    lockFails++;
    $('lock-pin').value = '';
    if (lockFails >= 5) { lockUntil = Date.now() + 30000; lockFails = 0; setText('lock-msg', 'Too many tries. Pause for 30 seconds, then try again.'); }
    else setText('lock-msg', 'That PIN did not match. Try again.');
    return false;
  }
  function tryBio() {
    var B = bioPlugin();
    if (!B) return;
    B.verifyIdentity({ reason: 'Unlock LoosenUp', title: 'Unlock LoosenUp', subtitle: 'Your notes stay private' })
      .then(function () { hideLock(); haptic('success'); }, function () { setText('lock-msg', 'Use your PIN instead.'); });
  }
  function renderLockCard() {
    var on = lockEnabled();
    setText('lock-status', on ? 'App lock is on. LoosenUp asks for your PIN when it opens.' : 'Keep your notes private with a PIN.');
    setText('lock-toggle', on ? 'Turn off app lock' : 'Set a PIN');
    $('lock-setup').hidden = true;
    $('lock-off-form').hidden = true;
    var B = bioPlugin();
    $('bio-toggle').hidden = !(on && B);
    setText('bio-toggle', 'Use Face ID or fingerprint: ' + (state.lock.bio ? 'on' : 'off'));
    $('bio-toggle').setAttribute('aria-pressed', String(!!state.lock.bio));
  }
  function savePin() {
    var a1 = ($('pin-new').value || '').trim(), a2 = ($('pin-confirm').value || '').trim();
    if (!/^\d{4,6}$/.test(a1)) { toast('Use 4 to 6 digits.'); return false; }
    if (a1 !== a2) { toast('The two PINs did not match.'); return false; }
    var salt = randomSalt();
    state.lock = { enabled: true, salt: salt, hash: pinHash(a1, salt), bio: false };
    save();
    $('pin-new').value = ''; $('pin-confirm').value = '';
    renderLockCard();
    toast('App lock is on.');
    return true;
  }
  function turnOffLock() {
    var pin = ($('pin-current').value || '').trim();
    if (pinHash(pin, state.lock.salt) !== state.lock.hash) { toast('That PIN did not match.'); return false; }
    state.lock = { enabled: false, salt: '', hash: '', bio: false };
    save();
    $('pin-current').value = '';
    renderLockCard();
    toast('App lock is off.');
    return true;
  }


  /* ---------- Language: English and Hindi ---------- */
  // English is written in the page and the code. In Hindi, every rendered English text node
  // and label is swapped for its Hindi version (www/i18n.js). The English original is kept
  // so switching back restores it exactly. Names and anything the user types are left alone.
  var TR_ATTRS = ['placeholder', 'aria-label', 'title', 'alt'];
  var trText = typeof WeakMap === 'function' ? new WeakMap() : null;
  var trAttr = typeof WeakMap === 'function' ? new WeakMap() : null;
  function isHindi() { return state.lang === 'hi' && !!window.LoosenUpI18n && !!trText; }
  function tr(s) { return isHindi() ? window.LoosenUpI18n.tr(s) : s; }
  function locale() { return state.lang === 'hi' ? 'hi-IN' : 'en-GB'; }
  function skipNode(el) { return !el || !!el.closest('script, style, textarea, [data-no-tr]'); }
  function trTextNode(n, hindi) {
    var rec = trText.get(n);
    if (hindi) {
      if (rec && n.data === rec.hi) return;
      if (!/[A-Za-z]/.test(n.data) || skipNode(n.parentElement)) return;
      var hi = window.LoosenUpI18n.tr(n.data);
      if (hi !== n.data) { trText.set(n, { en: n.data, hi: hi }); n.data = hi; }
    } else if (rec && n.data === rec.hi) n.data = rec.en;
  }
  function trElAttrs(el, hindi) {
    if (!el || el.closest('[data-no-tr]')) return;
    var recs = trAttr.get(el) || {};
    for (var i = 0; i < TR_ATTRS.length; i++) {
      var a = TR_ATTRS[i], v = el.getAttribute(a);
      if (v == null) continue;
      var rec = recs[a];
      if (hindi) {
        if (rec && v === rec.hi) continue;
        var hi = window.LoosenUpI18n.tr(v);
        if (hi !== v) { recs[a] = { en: v, hi: hi }; el.setAttribute(a, hi); }
      } else if (rec && v === rec.hi) el.setAttribute(a, rec.en);
    }
    trAttr.set(el, recs);
  }
  function translateDom(root, toEnglish) {
    if (!trText || !window.LoosenUpI18n) return;
    root = root || document.body;
    var hindi = !toEnglish && state.lang === 'hi';
    if (root.nodeType === 3) { trTextNode(root, hindi); return; }
    var w = document.createTreeWalker(root, 4, null, false), n;
    var texts = [];
    while ((n = w.nextNode())) texts.push(n);
    texts.forEach(function (t) { trTextNode(t, hindi); });
    if (root.nodeType === 1) {
      trElAttrs(root, hindi);
      var els = root.querySelectorAll('[' + TR_ATTRS.join('], [') + ']');
      for (var i = 0; i < els.length; i++) trElAttrs(els[i], hindi);
    }
  }
  var trObserver = null;
  function watchDom() {
    if (trObserver || typeof MutationObserver !== 'function') return;
    trObserver = new MutationObserver(function (list) {
      if (!isHindi()) return;
      list.forEach(function (m) {
        if (m.type === 'characterData') trTextNode(m.target, true);
        else if (m.type === 'attributes') trElAttrs(m.target, true);
        else for (var i = 0; i < m.addedNodes.length; i++) translateDom(m.addedNodes[i]);
      });
    });
    trObserver.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: TR_ATTRS });
  }
  function applyLang() {
    var hindi = isHindi();
    document.documentElement.setAttribute('lang', hindi ? 'hi' : 'en');
    var btns = document.querySelectorAll('[data-lang-choice]');
    for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', String(btns[i].getAttribute('data-lang-choice') === (state.lang || 'en')));
    if (hindi) { watchDom(); translateDom(document.body); }
    else translateDom(document.body, true);
  }
  function setLang(l) {
    state.lang = l === 'hi' ? 'hi' : 'en';
    save();
    applyLang();
    if (current) go(current);
    if (state.goldenHour) scheduleGoldenHour();
    toast(state.lang === 'hi' ? 'अब LoosenUp हिन्दी में है।' : 'LoosenUp is now in English.');
  }

  /* ---------- Learn: one-minute lessons ---------- */
  var LESSONS = [
    { id: 'breath', title: 'Why a long breath out helps', min: 1,
      body: ['When your breath out is slower than your breath in, your body gets a quiet signal that it is safe to slow down.',
        'Many people notice their heartbeat ease a little and their shoulders drop after a few long breaths out. That is why Sigh of relief and Cool down stretch the out-breath.',
        'You can use this anywhere: in a meeting, in traffic, before a hard talk. Nobody needs to know.'],
      takeaway: 'Make the out-breath longer than the in-breath.', tryLabel: 'Try Sigh of relief', tryTech: 'sigh' },
    { id: 'anxious', title: 'When you feel anxious: what your body is doing', min: 1,
      body: ['Feeling anxious is your body getting ready to protect you: a faster heart, quick breaths, tight muscles, a busy mind. It is uncomfortable, and it is not harmful.',
        'A sudden wave of panic rises, peaks and passes, usually within minutes. Fighting it tends to make it bigger. Breathing out slowly and feeling the ground under you helps it pass.',
        'If anxious feelings come often, stay for weeks, or stop you doing everyday things, talking to a professional really helps. Tele-MANAS (14416) is free, any time.'],
      takeaway: 'It rises, peaks and passes. Breathe out slowly and let it.', tryLabel: 'Try Ride the wave', tryTech: 'panic' },
    { id: 'thoughts', title: 'Thoughts are guesses, not facts', min: 1,
      body: ['A thought like "I always mess things up" can feel completely true in the moment. It is really a guess your mind makes, often on a tired or heavy day.',
        'Thoughts, feelings and actions move together. When you look at a thought from a little distance, the feeling often softens too.',
        'Ask: what would I tell a dear friend who had this thought? Then try saying it to yourself.'],
      takeaway: 'Notice the thought, then look for a kinder, truer version.', tryLabel: 'Reframe a thought', tryTool: 'reframe' },
    { id: 'steps', title: 'On heavy days, action comes first', min: 1,
      body: ['When energy is low, it is natural to wait until you feel like doing something. Often the feeling follows the action instead.',
        'Tiny actions count: a glass of water, two minutes of daylight, a hello to someone you trust. Each one is a small vote for yourself.',
        'Pick something so small it feels almost too easy. Then notice how you feel afterwards.'],
      takeaway: 'Start tiny. The lift often comes after the step.', tryLabel: 'Take a Small step', tryTool: 'today' },
    { id: 'sleep', title: 'A gentle runway to sleep', min: 1,
      body: ['Sleep comes more easily when the hour before bed slows down. Dim the lights, put the phone face down, and keep the room cool and quiet.',
        'Waking at about the same time each day, even on weekends, helps your body know when to feel sleepy.',
        'If your mind races in bed, write the thoughts down or play a soft sound, then return to slow breathing.'],
      takeaway: 'Same wake time, a softer last hour, and a calm sound if you need it.', tryLabel: 'Play a calm sound', tryTool: 'sounds' },
    { id: 'kindness', title: 'Talk to yourself like a friend', min: 1,
      body: ['Many of us speak to ourselves more harshly than we would ever speak to anyone we love.',
        'Self-kindness is not letting yourself off the hook. It is the steady voice that helps you try again.',
        'Try a hand on your heart and the words: this is a hard moment, I am not alone, may I be kind to myself.'],
      takeaway: 'Use the voice you would use for a dear friend.', tryLabel: 'Try Kind words', tryTech: 'kind' },
    { id: 'work', title: 'Boundaries that protect your energy at work', min: 1,
      body: ['Energy at work comes back in small pieces: a two-minute pause between meetings, one task at a time, a real lunch away from the screen.',
        'Saying "I can do this by Friday" is clearer and kinder than saying yes to everything today.',
        'End the day with a small ritual, like closing the laptop and three slow breaths, so your mind knows work is done.'],
      takeaway: 'Small pauses and clear limits keep you steady through the week.', tryLabel: 'Open the Work space', trySpace: 'work' },
    { id: 'repair', title: 'Repair after a disagreement', min: 1,
      body: ['Disagreements happen in every close relationship. What matters most is the repair afterwards.',
        'Wait until both of you feel calmer. Start with "I felt" rather than "You always". Listen to understand, not to reply.',
        'Owning your part, even a small part, often opens the door for the other person to do the same.'],
      takeaway: 'Calm down first, speak from "I", and repair early.', tryLabel: 'Try Pause before replying', tryTech: 'pause' },
    { id: 'friend', title: 'Supporting a friend who is struggling', min: 1,
      body: ['Listening without fixing is one of the kindest things you can offer. Try: "That sounds really hard. I am here."',
        'If you are worried about them, ask directly: "Are you thinking about ending your life?" Asking does not put the idea in their head, and it can be a huge relief.',
        'If they say yes, stay with them and call Tele-MANAS on 14416 together, or 112 in an emergency.'],
      takeaway: 'Listen, ask directly, and connect them to support.', tryLabel: 'See helplines and support', tryTool: 'support' },
    { id: 'help', title: 'When to talk to a professional', min: 1,
      body: ['Everyone has heavy days. It is a good time to talk to a professional if low moods last more than two weeks, if sleep, eating or work are clearly affected, or if you have thoughts of hurting yourself.',
        'A psychiatrist is a doctor who can assess and prescribe. A psychologist or counsellor offers talk therapy. Tele-MANAS (14416) can help you decide, for free.',
        'Reaching out early is a strength. Many people feel lighter after just the first conversation.'],
      takeaway: 'Two weeks of heavy days is a good reason to reach out.', tryLabel: 'Find support', tryTool: 'support' }
  ];
  var currentLesson = null;
  function renderLearn() {
    var ul = $('lesson-list');
    ul.textContent = '';
    LESSONS.forEach(function (l) {
      var li = document.createElement('li');
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'lesson-item';
      b.setAttribute('data-lesson', l.id);
      var t = document.createElement('strong'); t.textContent = l.title;
      var m = document.createElement('span');
      m.textContent = state.lessonsDone.indexOf(l.id) !== -1 ? 'Read' : l.min + ' min';
      if (state.lessonsDone.indexOf(l.id) !== -1) b.classList.add('done');
      b.appendChild(t); b.appendChild(m); li.appendChild(b); ul.appendChild(li);
    });
  }
  function openLesson(id) {
    var l = LESSONS.filter(function (x) { return x.id === id; })[0];
    if (!l) return;
    currentLesson = l;
    go('lesson');
    setText('lesson-meta', 'Lesson ' + (LESSONS.indexOf(l) + 1) + ' of ' + LESSONS.length);
    setText('lesson-title', l.title);
    var body = $('lesson-body');
    body.textContent = '';
    l.body.forEach(function (para) { var p0 = document.createElement('p'); p0.textContent = para; body.appendChild(p0); });
    setText('lesson-takeaway', l.takeaway);
    setText('lesson-try', l.tryLabel);
    if (state.lessonsDone.indexOf(l.id) === -1) { state.lessonsDone.push(l.id); state.xp += 2; save(); }
    translateDom(document.getElementById('screen-lesson'));
  }
  function tryLesson() {
    var l = currentLesson;
    if (!l) return;
    if (l.tryTech) {
      startCheckin('guided');
      flow.technique = l.tryTech; flow.picked = true; flow.fromLesson = true; flow.reason = 'From your lesson: ' + l.title + '.';
    } else if (l.trySpace) startCheckin('guided', l.trySpace);
    else go(l.tryTool);
  }

  /* ---------- Theme ---------- */
  function resolvedTheme() {
    var t = state.theme || 'auto';
    return t === 'dark' || (t === 'auto' && mm('(prefers-color-scheme: dark)')) ? 'dark' : 'light';
  }
  function applyTheme() {
    var r = resolvedTheme();
    document.documentElement.setAttribute('data-theme', r);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', r === 'dark' ? '#0E1626' : '#EDF7FF');
    try { window.localStorage.setItem('loosenup.theme', state.theme || 'auto'); } catch (e) { /* private mode */ }
    var btns = document.querySelectorAll('[data-theme-choice]');
    for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', String(btns[i].getAttribute('data-theme-choice') === (state.theme || 'auto')));
  }
  function setTheme(t) { state.theme = t; save(); applyTheme(); }

  /* ---------- Live updates (iPhone and Android apps) ---------- */
  // The native apps check our own domain for a newer web bundle, download it in the
  // background (checksum verified) and switch to it the next time LoosenUp opens.
  // Nothing is sent to third parties. If an update fails to start, the plugin rolls back.
  var UPDATE_MANIFEST = PUBLIC_URL + '/updates/latest.json';
  function newerVersion(a, b) {
    var x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (var i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
    return false;
  }
  function liveUpdate() {
    var U = isNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
    if (!U) return Promise.resolve('web');
    try { U.notifyAppReady(); } catch (e) { /* older bundle */ }
    return fetch(UPDATE_MANIFEST + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (m) {
        if (!m || !m.version || !m.url || !newerVersion(m.version, VERSION)) return 'current';
        return U.download({ url: m.url, version: m.version, checksum: m.checksum }).then(function (bundle) {
          return U.next({ id: bundle.id }).then(function () {
            toast('A fresh LoosenUp update is ready. It opens next time you launch the app.');
            return 'queued';
          });
        });
      })
      .catch(function () { return 'offline'; });
  }

  /* ---------- Events ---------- */

  function onClick(e) {
    var el = e.target.closest ? e.target.closest('button, a, [data-context]') : null;
    if (!el) return;
    if (el.disabled) return;
    var id = el.id;
    var ctx = el.getAttribute('data-context');
    var pick = el.getAttribute('data-pick');
    var tab = el.getAttribute('data-tab');
    var plusPlan = el.getAttribute('data-plus-plan');
    if (plusPlan) { buyPlus(plusPlan); return; }
    var focusK = el.getAttribute('data-focus');
    if (focusK) { toggleFocus(focusK); return; }
    var gameId = el.getAttribute('data-game');
    var card = el.getAttribute('data-card');
    var guide = el.getAttribute('data-guide');
    if (guide) { if (guide === 'voice') state.voice = !state.voice; else state.chime = !state.chime; save(); renderGuide(); renderVoiceButtons(); if (guide === 'chime' && state.chime) chime(); haptic('light'); return; }
    var bed = el.getAttribute('data-bed');
    if (bed) { setBed(bed); haptic('light'); return; }
    var beforeV = el.getAttribute('data-before');
    if (beforeV) { tapBefore(+beforeV); return; }
    var lessonId = el.getAttribute('data-lesson');
    if (lessonId) { openLesson(lessonId); return; }
    var themeChoice = el.getAttribute('data-theme-choice');
    if (themeChoice) { setTheme(themeChoice); haptic('light'); return; }
    var pf = el.getAttribute('data-pfilter');
    if (pf) { partnerFilter = pf; renderPartners(); return; }
    var prog = el.getAttribute('data-program');
    if (prog) { openProgram(prog); return; }
    var feel = el.getAttribute('data-feel');
    if (feel) { feelAction(feel); haptic('light'); return; }
    var emotion = el.getAttribute('data-emotion');
    if (emotion) { setEmotion(emotion); return; }
    var dot = el.getAttribute('data-dot');
    if (dot !== null) { tapDot(+dot); return; }
    var seg = el.getAttribute('data-seg');
    if (seg) { setSeg(seg); haptic('light'); return; }
    var nowId = el.getAttribute('data-now');
    if (nowId) { startNow(nowId); haptic('light'); return; }
    var match = el.getAttribute('data-match');
    if (match) { var mp = match.split(':'); matchPick[mp[0]] = mp[1]; renderMatch(); haptic('light'); return; }
    var practice = el.getAttribute('data-practice');
    if (practice) { startPractice(practice); haptic('light'); return; }
    var langChoice = el.getAttribute('data-lang-choice');
    if (langChoice) { setLang(langChoice); haptic('light'); return; }
    var tool = el.getAttribute('data-tool');
    if (tool) { closeSheets(true); go(tool); return; }
    if (el.hasAttribute('data-back')) { go(lastTab || 'today'); return; }
    var wb = el.getAttribute('data-wb');
    if (wb) { var parts = wb.split(':'); answerWb(+parts[0], +parts[1]); haptic('light'); return; }
    var snd = el.getAttribute('data-sound');
    if (snd) { if (audio && audio.kind === snd) stopSound(false); else playSound(snd); haptic('light'); return; }
    var tmr = el.getAttribute('data-timer');
    if (tmr !== null) { setSleepTimer(+tmr); return; }
    var spaceTab = el.getAttribute('data-space-tab');
    var unpick = el.getAttribute('data-unpick');
    if (spaceTab) {
      flow.spaceTab = spaceTab;
      var groups = document.querySelectorAll('[data-group]');
      for (var gi = 0; gi < groups.length; gi++) groups[gi].hidden = groups[gi].getAttribute('data-group') !== spaceTab;
      var ts = document.querySelectorAll('[data-space-tab]');
      for (var ti = 0; ti < ts.length; ti++) ts[ti].setAttribute('aria-selected', String(ts[ti] === el));
      haptic('light');
      return;
    }
    if (unpick) { toggleContext(unpick); return; }
    var spaceId = el.getAttribute('data-space');
    var moodV = el.getAttribute('data-mood');
    if (spaceId) { haptic('medium'); startCheckin('guided', spaceId); return; }
    if (moodV) { haptic('light'); setMood(+moodV); return; }
    if (id === 'sos-alert') { sendSos(e); return; }
    if (gameId) { openGame(gameId); return; }
    if (card !== null) { flipCard(+card); return; }
    if (ctx) {
      toggleContext(ctx);
      return;
    }
    if (pick) {
      if (!isUnlocked(pick)) return;
      flow.technique = pick;
      flow.picked = true;
      var rf = recommendFor(flow.contexts);
      flow.reason = pick === rf.id ? rf.reason : 'Your choice. Enjoy it.';
      renderPick();
      return;
    }
    if (tab) { go(tab); return; }
    switch (id) {
      case 'gift-go':
        if (state.pendingGo) { var pg = state.pendingGo; state.pendingGo = null; save(); go('today'); goTarget(pg); }
        else startCheckin('guided');
        break;
      case 'game-send': if (game) shareBreak('game:' + game.id); break;
      case 'result-send': if (flow && flow.technique) shareBreak('ex:' + flow.technique); break;
      case 'checkin-next':
        flow.before = clampScore($('calm-before').value);
        if (!flow.context) { flow.context = 'Just a quick lift'; flow.contexts = [flow.context]; }
        if (flow.mode === 'quick') beginBreak('quick');
        else { flow.picked = !!(flow.fromLesson || flow.chosen); go('pick'); }
        break;
      case 'checkin-back': go(flow.program ? 'program' : flow.chosen ? 'play' : state.onboarded ? 'today' : 'gift'); break;
      case 'program-start': startProgramDay(); break;
      case 'inperson-locate': locateInPerson(); break;
      case 'org-join-btn': joinOrg($('org-code').value); break;
      case 'org-share': toggleOrgShare(); break;
      case 'org-leave': leaveOrg(); break;
      case 'pick-begin': beginBreak(flow.technique); break;
      case 'pick-quick': beginBreak('quick'); break;
      case 'session-finish': endSession(false); break;
      case 'session-pause': togglePause(); break;
      case 'session-audio': toggleAudioPanel(); break;
      case 'voice-toggle': toggleVoice(); break;
      case 'step-next': if (run && TECH[run.id].steps && run.step < TECH[run.id].steps.length - 1) { run.ready = 0; showStep(run.step + 1); } break;
      case 'after-next': finishAfter(); break;
      case 'result-done': go(state.onboarded ? 'today' : 'welcome'); break;
      case 'still-talk': openSupport(); break;
      case 'welcome-breathe': breatheNow(); break;
      case 'sos-panic': startNow('panic'); break;
      case 'game-back': go(lastTab || 'play'); break;
      case 'game-again': if (game) openGame(game.id); break;
      case 'game-keep': keepKindNote(); break;
      case 'games-all': go('play'); setSeg('games'); break;
      case 'daily-play': openDaily(); break;
      case 'game-plus': openGamePlus(); break;
      case 'start-break': startCheckin('guided'); break;
      case 'breathe-now': breatheNow(); break;
      case 'open-shop': openShop(); break;
      case 'plus-restore-btn': restorePlus(); break;
      case 'plus-cancel': cancelPlus(); break;
      case 'plus-copy-key': if (navigator.clipboard && state.plus) navigator.clipboard.writeText(state.plus.key).then(function () { toast('Plus key copied.'); }); break;
      case 'shop-close': case 'support-close': case 'reset-cancel': closeSheets(); document.body.classList.remove('lock-sos'); break;
      case 'open-support': case 'sos-btn': case 'support-card-sos': openSupport(); break;
      case 'sos-add-trusted': setUpTrusted(); break;
      case 'trusted-edit': renderTrusted(true); break;
      case 'trusted-save': saveTrusted(); break;
      case 'sos-location': state.sosLocation = !state.sosLocation; save(); renderSos(); break;
      case 'sos-breathe': breatheNow(); break;
      case 'safety-yes': openSupport(); break;
      case 'safety-moment': breatheNow(); toast('Help is one tap away in SOS, any time.'); break;
      case 'match-prepare': openFold('prepare-fold'); break;
      case 'match-all': openFold('book-fold'); break;
      case 'safety-no':
        closeSheets();
        setText('mood-done', MOOD_NOTES[1]);
        toast('Thank you. We are glad you are here.');
        break;
      case 'step-done': doStep(); break;
      case 'support-card-step': if ($('steps-card').scrollIntoView) $('steps-card').scrollIntoView({ behavior: 'smooth', block: 'center' }); break;
      case 'step-another': stepOffset++; renderSteps(); break;
      case 'jar-add': openJar(); break;
      case 'care-save': saveCare(); break;
      case 'lesson-back': go('learn'); break;
      case 'lesson-try': tryLesson(); break;
      case 'lock-unlock': tryUnlock(); break;
      case 'lock-bio': tryBio(); break;
      case 'lock-sos': document.body.classList.add('lock-sos'); openSupport(); break;
      case 'lock-forgot': $('lock-reset').hidden = false; break;
      case 'lock-erase':
        try { window.localStorage.removeItem(KEY); } catch (err) { /* nothing stored */ }
        state = freshState(); hideLock(); go('welcome'); toast('A fresh start. You can restore a backup from Me.');
        break;
      case 'lock-toggle':
        if (lockEnabled()) { $('lock-off-form').hidden = false; $('lock-setup').hidden = true; }
        else { $('lock-setup').hidden = false; $('lock-off-form').hidden = true; }
        break;
      case 'pin-save': savePin(); break;
      case 'pin-off': turnOffLock(); break;
      case 'bio-toggle':
        var BP = bioPlugin();
        if (!BP) break;
        BP.isAvailable().then(function (r) {
          if (!r || !r.isAvailable) { toast('Face ID or fingerprint is not set up on this phone.'); return; }
          state.lock.bio = !state.lock.bio; save(); renderLockCard();
        }, function () { toast('Face ID or fingerprint is not available.'); });
        break;
      case 'care-edit': renderCare(true); break;
      case 'copy-script': copyScript(); break;
      case 'sp-save': saveSafety(); break;
      case 'rf-next': rfNext(); break;
      case 'rf-keep': keepKinder(); break;
      case 'sound-stop': stopSound(false); break;
      case 'wb-submit': submitWb(); break;
      case 'backup-export': exportBackup(); break;
      case 'good-save': saveGood(); break;
      case 'for-you-alt': toggleAlt(); break;
      case 'good-close': $('good-text').value = ''; closeSheets(); break;
      case 'golden-save': saveGoldenHour(); break;
      case 'golden-clear': clearGoldenHour(); break;
      case 'sunbeam-share': shareSunbeam(); break;
      case 'install-btn':
        if (installEvt) { installEvt.prompt(); installEvt.userChoice.then(function () { installEvt = null; renderInstall(); }); }
        break;
      case 'reset-btn': openSheet('confirm-sheet'); break;
      case 'reset-confirm':
        stopRun();
        try { window.localStorage.removeItem(KEY); } catch (err) { /* nothing stored */ }
        state = freshState();
        scheduleGoldenHour();
        closeSheets(true);
        $('name-input').value = '';
        go('welcome');
        toast('A fresh start. Welcome back.');
        break;
      default: break;
    }
  }

  function onWelcome(e) {
    e.preventDefault();
    var name = ($('name-input').value || '').trim().replace(/\s+/g, ' ').slice(0, 24);
    state.name = name || 'friend';
    if (!state.onboarded) {
      state.onboarded = true;
      state.createdAt = now().getTime();
    }
    save();
    var slots = document.querySelectorAll('.name-slot');
    for (var i = 0; i < slots.length; i++) slots[i].textContent = state.name;
    go('gift');
  }

  function onJournal() {
    var v = $('letitout-text').value;
    if (run && !run.crisisShown && isCrisis(v)) { run.crisisShown = true; openSupport(); }
    else if (!run && isCrisis(v)) openSupport();
  }

  function init() {
    document.addEventListener('click', onClick);
    $('welcome-form').addEventListener('submit', onWelcome);
    $('letitout-text').addEventListener('input', onJournal);
    $('good-text').addEventListener('input', onGoodInput);
    var rfs = document.querySelectorAll('.rf');
    for (var ri = 0; ri < rfs.length; ri++) rfs[ri].addEventListener('input', onRfInput);
    ['rf-before', 'rf-after'].forEach(function (id) { $(id).addEventListener('input', function () { setText(id + '-out', $(id).value); }); });
    $('sound-volume').addEventListener('input', function () { if (audio) audio.out.gain.setTargetAtTime(soundVolume(), audio.ctx.currentTime, 0.3); });
    $('backup-import').addEventListener('change', onImport);
    applyHelplines();
    $('scrim').addEventListener('click', function () { closeSheets(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('scrim').hidden) closeSheets(); });
    addPetals($('orb-petals'), 0, 0, 1);
    addPetals($('rs-petals'), 180, 132, 0.9, 'rp');
    bindSlider('calm-before');
    bindSlider('calm-after');
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); installEvt = e; if (current === 'me') renderInstall(); });
    window.addEventListener('appinstalled', function () { installEvt = null; toast('LoosenUp is on your home screen.'); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden && current === 'today') renderGoldenBanner(); });
    applyTheme();
    applyLang();
    bindCalmGestures();
    $('inperson-city').addEventListener('change', function () { inPerson.here = null; setText('inperson-status', ''); setCity(this.value); });
    $('lock-pin').addEventListener('keydown', function (e) { if (e.key === 'Enter') tryUnlock(); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) hiddenAt = Date.now();
      else if (lockEnabled() && hiddenAt && Date.now() - hiddenAt > 60000) showLock();
    });
    if (lockEnabled()) showLock();
    try { window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { if ((state.theme || 'auto') === 'auto') applyTheme(); }); } catch (e) { /* older browsers */ }
    renderIosTip();
    go(state.onboarded ? 'today' : 'welcome');
    registerSW();
    if (state.goldenHour) scheduleGoldenHour();
    openFromLink();
    liveUpdate();
    document.addEventListener('visibilitychange', function () { if (!document.hidden) liveUpdate(); });
    sendPulse();
    loadVoiceClips();
    loadPayConfig();
    refreshPlus();
    document.addEventListener('visibilitychange', function () { if (!document.hidden && state.plus && state.plus.key && !isPlus()) refreshPlus(); });
  }

  /* ---------- Hooks for www/more.js (sleep, journal, goal, packs, games) ---------- */
  var AFTER_RENDER = {};
  var core = {
    state: function () { return state; },
    save: save, go: go, current: function () { return current; }, tr: tr, setText: setText, toast: toast,
    register: function (name, fn) { RENDER[name] = fn; },
    onRender: function (name, fn) {
      var base = RENDER[name];
      (AFTER_RENDER[name] = AFTER_RENDER[name] || []).push(fn);
      if (base && !base.wrapped) {
        RENDER[name] = function () { base(); (AFTER_RENDER[name] || []).forEach(function (f) { f(); }); };
        RENDER[name].wrapped = true;
      }
    },
    speak: speak, stopVoice: stopVoice,
    playSound: function (kind, vol) { var ok = playSound(kind, vol); if (audio) clearTimeout(audio.timer); return ok; },
    stopSound: stopSound, fadeSound: fadeSound,
    isCrisis: isCrisis, openSupport: openSupport, startPractice: startPractice, TECH: TECH,
    now: now, dayKey: dayKey, weekKey: weekKey, isNative: isNative, addBadge: function (id) { addBadge(id); save(); },
    planDone: planDone, renderPlanNext: renderPlanNext,
    publicUrl: PUBLIC_URL, weekGoal: weekGoal, isPlus: isPlus, plusRequired: plusRequired, openShop: openShop
  };

  /* ---------- Public API (used by the app shell and the test suite) ---------- */

  window.LoosenUp = {
    version: VERSION,
    state: function () { return JSON.parse(JSON.stringify(state)); },
    setState: function (patch) { for (var k in patch) state[k] = patch[k]; save(); if (current && RENDER[current]) RENDER[current](); renderSeedPill(); },
    setNow: function (d) { nowOverride = d ? new Date(d) : null; },
    setRng: function (fn) { rng = fn || Math.random; },
    currentScreen: function () { return current; },
    go: go,
    recommend: recommend,
    recommendFor: recommendFor,
    newerVersion: newerVersion,
    restoreBackup: restoreBackup,
    setTheme: setTheme,
    chimesPlayed: function () { return chimesPlayed; },
    lessons: LESSONS,
    openLesson: openLesson,
    isLocked: isLocked,
    showLock: showLock,
    setLang: setLang,
    setSeg: setSeg,
    setEmotion: setEmotion,
    emotionStats: emotionStats,
    sessionTick: function () { tick(); },
    run: function () { return run ? JSON.parse(JSON.stringify({ id: run.id, ready: run.ready, phase: run.phase, phaseLeft: run.phaseLeft, round: run.round, rounds: run.rounds, step: run.step, stepLeft: run.stepLeft, dots: run.dots, left: run.left })) : null; },
    joinOrg: joinOrg,
    loadVoiceClips: loadVoiceClips,
    clipFor: clipFor,
    useLocation: useLocation,
    setCity: setCity,
    sendPulse: sendPulse,
    weekPulse: weekPulse,
    programs: PROGRAMS,
    programStatus: programStatus,
    openProgram: openProgram,
    startProgramDay: startProgramDay,
    calmSeg: function () { return calmSeg; },
    startPractice: startPractice,
    tr: tr,
    translateDom: translateDom,
    sha256: sha256,
    resolvedTheme: resolvedTheme,
    wellbeingNote: wellbeingNote,
    checkDue: checkDue,
    playSound: playSound,
    liveUpdate: liveUpdate,
    updateManifest: UPDATE_MANIFEST,
    isUnlocked: isUnlocked,
    completeSession: completeSession,
    beginBreak: beginBreak,
    breatheNow: breatheNow,
    startNow: startNow,
    forYou: forYou,
    weekGoal: weekGoal,
    matchServices: matchServices,
    core: core,
    helplines: HL,
    openShop: function (note) { openShop(note); },
    isPlus: isPlus,
    plusRequired: plusRequired,
    buyPlus: buyPlus,
    restorePlus: restorePlus,
    cancelPlus: cancelPlus,
    refreshPlus: refreshPlus,
    loadPayConfig: loadPayConfig,
    setOpenUrl: function (fn) { openUrl = fn; },
    isCrisis: isCrisis,
    sosHref: sosHref,
    spaces: SPACES,
    dayKey: dayKey,
    weekKey: weekKey,
    prefersReducedMotion: prefersReducedMotion,
    shareSunbeam: shareSunbeam,
    openGame: openGame,
    game: function () { return game; },
    flipCard: flipCard,
    spawnBeam: spawnBeam,
    finishCurrentGame: finishCurrentGame,
    pickStone: pickStone,
    goTarget: goTarget,
    linkTarget: linkTarget,
    shareBreak: shareBreak,
    toggleFocus: toggleFocus,
    openFromLink: openFromLink,
    sortStone: sortStone,
    sandStroke: sandStroke,
    setSandTool: setSandTool,
    tapStar: tapStar,
    dropBlock: dropBlock,
    pickKind: pickKind,
    keepKindNote: keepKindNote,
    openDaily: openDaily,
    dailyGame: dailyGame,
    gameSets: GAME_SETS,
    colourRing: colourRing,
    pickColour: pickColour,
    tapTile: tapTile,
    peekTiles: peekTiles,
    tapChime: tapChime,
    playTune: playTune,
    chimeTunes: CHIME_TUNES,
    tapSpot: tapSpot,
    tapCount: tapCount,
    holdLantern: holdLantern,
    letLantern: letLantern,
    releaseLantern: releaseLantern,
    rippleAt: rippleAt,
    mandalaStroke: mandalaStroke,
    gameRank: function () { return gameRank(); },
    skies: SKIES,
    feelPlan: function () { var p = feelPlan(); return JSON.parse(JSON.stringify({ key: p.key, steps: p.steps, next: p.next, alt: p.alt, hear: p.hear, close: p.f.close })); },
    stepInfo: stepInfo,
    voiceLines: function () {
      var out = [INTRO.breath, INTRO.steps, INTRO.journal, OUTRO, 'Voice guide on.', 'Get ready', 'Breathe in', 'Breathe out'];
      Object.keys(TECH).forEach(function (k) {
        var t = TECH[k];
        out.push(t.desc);
        (t.pattern || []).forEach(function (p) { out.push(p[0]); });
        (t.steps || []).forEach(function (st) { out.push(st); });
      });
      return out.filter(function (x, i) { return out.indexOf(x) === i; });
    },
    techniques: TECH
  };

  // The script is deferred, so the DOM is ready; fall back to DOMContentLoaded if it is not.
  if (document.getElementById('tabbar')) init();
  else document.addEventListener('DOMContentLoaded', init);
})();
